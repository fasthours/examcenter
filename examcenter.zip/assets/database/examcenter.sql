-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 11, 2017 at 03:18 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `examcenter`
--

-- --------------------------------------------------------

--
-- Table structure for table `studentdetails`
--

CREATE TABLE `studentdetails` (
  `studentid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(500) NOT NULL,
  `contactno` bigint(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `enrollmentno` varchar(15) NOT NULL,
  `photo` longblob NOT NULL,
  `password` varchar(30) NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `extra` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentdetails`
--

INSERT INTO `studentdetails` (`studentid`, `name`, `address`, `contactno`, `email`, `enrollmentno`, `photo`, `password`, `date`, `extra`) VALUES
(1, 'Pranali V. More', 'Palghar', 9876543210, 'pranali@gmail.com', '0123456789', 0x73747564656e74312e6a7067, '31998', '2017-03-11 11:33:03', ''),
(2, 'Shrikant K. Gacche', 'Palghar', 7410236589, 'shrikantgacche@gmail.com', '1234567890', 0x73747564656e74312e6a7067, '42968', '2017-03-11 12:30:08', '');

-- --------------------------------------------------------

--
-- Table structure for table `subjectname`
--

CREATE TABLE `subjectname` (
  `subjectid` int(11) NOT NULL,
  `subjectname` varchar(255) NOT NULL,
  `subjectcode` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `extra` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjectname`
--

INSERT INTO `subjectname` (`subjectid`, `subjectname`, `subjectcode`, `date`, `extra`) VALUES
(1, 'Hindi', 'H', '2017-03-11 12:01:03', ''),
(2, 'Hindi', 'H75048', '2017-03-11 12:20:06', ''),
(3, 'Marathi', 'M59849', '2017-03-11 12:31:56', ''),
(4, 'English', 'E16775', '2017-03-11 12:32:26', ''),
(5, 'Gujarati', 'G99235', '2017-03-11 12:32:38', ''),
(6, 'Mathematics', 'M61450', '2017-03-11 12:33:02', ''),
(7, 'History', 'H13723', '2017-03-11 12:33:13', '');

-- --------------------------------------------------------

--
-- Table structure for table `testdetails`
--

CREATE TABLE `testdetails` (
  `testid` int(11) NOT NULL,
  `testname` varchar(255) NOT NULL,
  `subjectname` varchar(255) NOT NULL,
  `totalquestion` bigint(20) NOT NULL,
  `totalmarks` bigint(20) NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `extra` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testdetails`
--

INSERT INTO `testdetails` (`testid`, `testname`, `subjectname`, `totalquestion`, `totalmarks`, `date`, `extra`) VALUES
(1, 'Test1', 'html', 100, 100, '2017-03-11 12:50:33', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `studentdetails`
--
ALTER TABLE `studentdetails`
  ADD PRIMARY KEY (`studentid`);

--
-- Indexes for table `subjectname`
--
ALTER TABLE `subjectname`
  ADD PRIMARY KEY (`subjectid`);

--
-- Indexes for table `testdetails`
--
ALTER TABLE `testdetails`
  ADD PRIMARY KEY (`testid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `studentdetails`
--
ALTER TABLE `studentdetails`
  MODIFY `studentid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `subjectname`
--
ALTER TABLE `subjectname`
  MODIFY `subjectid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `testdetails`
--
ALTER TABLE `testdetails`
  MODIFY `testid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
