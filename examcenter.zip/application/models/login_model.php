<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {

	public function login_valid( $username, $password )
	{
			
		$q = $this->db->where(['username'=>$username, 'password'=>$password])
						->get('login');

		if ( $q->num_rows() )	
		{
			return TRUE;
		}	
		else 
		{
			return FALSE;
		}		
	
	}
}
?>
