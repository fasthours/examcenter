<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Testdetails_model extends CI_Model {

    public function savetestdetails($data)
    
    {

        $this->db->insert('testdetails', $data);
        

    }
    public function test_valid($subname)
    {
        
      $q = $this->db->where(['testname'=>$subname])
              ->get('testdetails');

      if ( $q->num_rows()) 
      {
        return TRUE;
      } 
      else 
      {
        return FALSE;
      }   
    
    }
    
    public function getAllCategories()
    {
    $this->db->select('subjectname');
    $q = $this->db->get('subjectname');

    if ($q->num_rows() > 0)
    {
        foreach($q->result() as $row) 
        {
            $data[] = $row;
        }
        return $data;
    }
}

public function selecttest()    
    {

    $this->db->select('testdetails.*,subjectname.*');
    $this->db->from('subjectname');
    $this->db->join('testdetails', 'testdetails.subjectname = subjectname.subjectid', 'right outer'); 
    $query = $this->db->get();
    return $query;
 
    }
    public function selecttest1($id)    
    {

     $this->db-> where('testid', $id);     
      $query = $this->db->get("testdetails");  
      return $query;
    }
    public function selecttest2()    
    {

    $query= $this->db->get('testdetails');
        return $query;

    }
    public function selecttestbysubject($id)    
    {

     $this->db-> where('subjectname', $id); 
     $this->db-> where('onoff', 'On');     
      $query = $this->db->get("testdetails");  
      return $query;
    }

    public function updatetest($id, $val1,$val2,$val3,$val4,$val5,$val6,$val7)
    {
     $this->db->where('testid', $id);
     $data = array("testname" => $val1,"subjectname" => $val2, "totalquestion" => $val3, "totalmarks" => $val4, "onoff" => $val5, "testduration" => $val6, "date" => $val7);
     $this->db->update('testdetails', $data);
    }

public function did_delete_row($id){
          $this->db-> where('testid', $id);
          $this->db-> delete('testdetails');
          $query = $this->db->get("testdetails");  
          return $query;
    }
    

}

?>


