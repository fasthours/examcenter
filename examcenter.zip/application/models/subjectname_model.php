<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subjectname_model extends CI_Model {

	public function savesubjectname($data)
	
	{

    	$this->db->insert('subjectname', $data);
		

	}
	public function subject_valid($subname)
	{
			
		$q = $this->db->where(['subjectname'=>$subname])
						->get('subjectname');

		if ( $q->num_rows() )	
		{
			return TRUE;
		}	
		else 
		{
			return FALSE;
		}		
	
	}
	public function selectsubject()
        {

    $query= $this->db->get('subjectname');
        return $query;

    }
	public function selectsubject1($id)
        {
     $this->db-> where('subjectid', $id);   	
    $query= $this->db->get('subjectname');
        return $query;

    }
    public function updatesubject($id, $val1, $val2)
	{
     $this->db->where('subjectid', $id);
     $data = array("subjectname" => $val1, "date" => $val2);
     $this->db->update('subjectname', $data);
	}

	public function did_delete_row($id){
		  $this->db-> where('subjectid', $id);
		  $this->db-> delete('subjectname');
		  $query = $this->db->get("subjectname");  
		  return $query;
	}

	
}
?>


