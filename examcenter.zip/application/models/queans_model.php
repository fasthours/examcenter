<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Queans_model extends CI_Model {

	public function savequeans($data)	
	{

    	$this->db->insert('questionans', $data);
		

	}
  public function saveans($data) 
  {

      $this->db->insert('answertable', $data);
    }

	public function selectquestionlimitnumbers($id)    
    {
        $this->db->where('queansid', $id);
        $query= $this->db->get('questionans');
        return $query;

    }
    public function selectquestionbyct($cid,$tid){
       $this->db->where('subjectid', $cid);
        $this->db->where('testid', $tid);
        $query= $this->db->get('questionans');
        return $query;
    }
    public function selectquestion()    
    {
  
    $query= $this->db->get('questionans');
        return $query;

    }
    public function selectquestionlimitminus($currentId,$cid,$tid){
      
//SELECT id from tablename where username = 'user1' AND id < $currentId ORDER BY ID DESC LIMIT 1;
       $this->db->where('testid', $tid);
        $this->db->where('subjectid', $cid);
        $this->db->where('queansid <', $currentId);
        $this->db->order_by("queansid", "DESC");
        $this->db->limit(1);
        $query = $this->db->get('questionans');
         
     
      
      return $query;
    }
    public function selectquestionlimit($id)
    {

      
      $id=$id+1;
     
      $query= $this->db->where('queansid', $id);
      $query= $this->db->get('questionans');
      return $query;

    }
    public function selectquestionlimit1($currentId,$tid,$cid)
    {

  
     $this->db->where('testid', $tid);
    $this->db->where('subjectid', $cid);
    $this->db->where('queansid >', $currentId);
    $this->db->order_by("queansid", "asc");
    $this->db->limit(1);
    $query = $this->db->get('questionans');
     
      return $query;

    }
	public function selectquestion1($id)
    {
        	$query= $this->db->where('queansid', $id);
    			$query =	 $this->db->get('questionans');
       		 return $query;

    }


     public function updateque($id, $val1,$val2,$val3,$val4,$val5,$val6,$val7,$val8,$val9,$val10,$val11,$val12,$val13,$val14,$val15,$val16,$val17)
    {
     $this->db->where('queansid', $id);
     $data = array("subjectid" => $val1,"testid" => $val2, "englishquestion" => $val3, "engoption1" => $val4, "engoption2" => $val5, "engoption3" => $val6,"engoption4" => $val7,"engrightoption" => $val8,"englishtrueans" => $val9,"hindiquestion" => $val10,"hindioption1" => $val11,"hindioption2" => $val12,"hindioption3" => $val13,"hindioption4" => $val14,"hindirightoption" => $val15,"hinditrueans" => $val16,"data" => $val17);
     $this->db->update('questionans', $data);
    }


	public function did_delete_row($id){
          $this->db-> where('queansid', $id);
          $this->db-> delete('questionans');
          $query = $this->db->get("questionans");  
          return $query;
    }

    public function total_count($cid,$tid) {
       /*  $this->db->where('subjectid', $cid);
          $this->db->where('testid', $tid);
       return $this->db->count("questionans");
       */
        $this->db->where('subjectid', $cid);
        $this->db->where('testid', $tid);
        $this->db->from('questionans');

        return $this->db->count_all_results();


    }
    public function get_users($limit, $start) {
      $this->db->limit($limit, $start);
      $query = $this->db->get("questionans");
      if ($query->num_rows() > 0) {
        return $query->result_array();
      }
      return false;
   }
    
	
}
?>


