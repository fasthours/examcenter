<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Studentdetails_model extends CI_Model {

	public function droptable($data){
		$this->load->dbforge();
		$table = $data;
		$this->dbforge->drop_table($table);
	}
  public function student_valid($enroll){
    $q = $this->db->where(['enrollmentno'=>$enroll])
            ->get('studentdetails');

    if ( $q->num_rows() ) 
    {
      return TRUE;
    } 
    else 
    {
      return FALSE;
    }   
  }
	public function savestudentdetails($data)
	{
		$this->load->dbforge();

    	$this->db->insert('studentdetails', $data);

    	$posts_fields=array( 
         
        'questionsid'=>array('type'=>'int'),
         'answer'=>array('type'=>'text'),
          'realans'=>array('type'=>'text'),
           'testid'=>array('type'=>'int'),
            'courseid'=>array('type'=>'int'),
            'starttime'=>array('type'=>'text'),
             'endtime'=>array('type'=>'text'),
            
        		);
       $this->dbforge->add_field('id');
		 $this->dbforge->add_field($posts_fields);
		 $this->dbforge->create_table($data['enrollmentno']);


		 $posts_fields=array(  
       
        'totalmarks'=>array('type'=>'text'),
        'getmarks'=>array('type'=>'text'),
         'avg'=>array('type'=>'text'),
          'testid'=>array('type'=>'int'),
           'courseid'=>array('type'=>'int'),
            'starttime'=>array('type'=>'text'),
             'endtime'=>array('type'=>'text'),
             'teststatus'=>array('type'=>'text'),
             'enrollmentno'=>array('type'=>'text'),
        		);
  $this->dbforge->add_field('id');
		 $this->dbforge->add_field($posts_fields);
		 $this->dbforge->create_table($data['enrollmentno']."_report");
		

	}

	public function selectstudent()  
      {  
         //data is retrive from this query  

      	 $this->db->order_by("studentid", "desc");
      	// $this->db->where('studentdetails');
         $query = $this->db->get("studentdetails");  

         return $query;  
      }   
      public function exammaster_valid($testid,$courseid){
        $q = $this->db->where(['testid'=>$courseid, 'courseid'=>$testid])
            ->get('exammasterreport');

          if ( $q->num_rows() ) 
          {
            return TRUE;
          } 
          else 
          {
            return FALSE;
          }   
      }
   
      public function selectstudentbyid($id){
      	$this->db->where('studentid', $id);
 	    	$query = $this->db->get("studentdetails");  

         return $query;  
      }
       public function selectstudentbyenroll($id){
        $this->db->where('enrollmentno', $id);
        $query = $this->db->get("studentdetails");  

         return $query;  
      }

      public function masterreportcount($enrollmentno,$courseid,$testid){
        $this->db->where('testid', $courseid);
        $this->db->where('courseid', $testid);
        $query = $this->db->get('masterreport');
          return $query;
      }

      public function masterreport(){
       
        //$query = $this->db->get($enroll."_report");
        //return $query->result();  

          $query = $this->db->get('masterreport');
          return $query;
        }
         public function exammasterreport(){
       
        //$query = $this->db->get($enroll."_report");
        //return $query->result();  

          $query = $this->db->get('exammasterreport');
          return $query;
        }

    public function updatestudent($id, $val1,$val2,$val3,$val4,$val5,$val6,$val7,$val9)
	{
     $this->db->where('studentid', $id);
     $data = array("name" => $val1,"address" => $val2, "contactno" => $val3, "email" => $val4, "enrollmentno" => $val5, "date" => $val6,"photo" => $val7,"subjectid" => $val9);
     $this->db->update('studentdetails', $data);
	}

	public function did_delete_row($id){
		  $this->db-> where('studentid', $id);
		  $this->db-> delete('studentdetails');
		  $query = $this->db->get("studentdetails");  
		  return $query;
	}

	
}
?>


