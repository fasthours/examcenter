<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Studentlogin_model extends CI_Model {

	public function login_valid( $username, $password )
	{
			
		$q = $this->db->where(['enrollmentno'=>$username, 'password'=>$password])
						->get('studentdetails');

		if ( $q->num_rows() )	
		{
			return TRUE;
		}	
		else 
		{
			return FALSE;
		}		
	
	}
	public function updatecoursetest($totalmarksstu,$tid, $cid, $username ,$timing)
	{
     $this->db->where('testid', $tid);
     $this->db->where('courseid', $cid);
     $data = array("teststatus" => "testdone" ,"endtime" => $timing);
     $data['getmarks']=$totalmarksstu;
     
     $data['enrollmentno']=$username;
     $this->db->update($username."_report", $data);
	}
	public function insertmasterreport($enroll,$datasave)
	{

		
    	$this->db->insert('masterreport', $datasave);
	}

	public function insertexammasterreport($datasave){
		$this->db->insert('exammasterreport', $datasave);
	}
	public function updateexammaster($testid,$courseid,$totalstudent,$totalastudent,$totalnstudent){
		$this->db->where('testid', $courseid);
	     $this->db->where('courseid', $testid);
	     
	    
	     $data['totalstudent']=$totalstudent;
	     $data['nastudent']=$totalnstudent;
	     $data['astudent']=$totalastudent;

	     $this->db->update("exammasterreport", $data);
	}
	public function updatequestion($tid,$cid,$quid,$username,$ans){
		 $this->db->where('testid', $cid);
	     $this->db->where('courseid', $tid);
	       $this->db->where('questionsid', $quid);
	     $data = array("answer" => $ans);
	     $this->db->update($username, $data);
	}


	public function examcheck($tid,$cid,$username)
	{
			
		$q = $this->db->where(['courseid'=>$cid, 'testid'=>$tid, 'teststatus'=>'testdone'])
						->get($username."_report");

		if ( $q->num_rows()>0 )	
		{
			return TRUE;
		}	
		else 
		{
			return FALSE;
		}		
	
	}

	public function examanscheck($tid,$cid,$username,$quid)
	{
			
		$q = $this->db->where(['courseid'=>$tid, 'testid'=>$cid, 'questionsid'=>$quid])
						->get($username);

		if ( $q->num_rows()>0 )	
		{
			return TRUE;
		}		
		else 
		{
			return FALSE;
		}		
	
	}

	public function getrealans($cid,$tid,$quid)
	{
		 $this->db-> where('queansid', $quid);		 
		 $this->db-> where('subjectid', $cid);		 
		 $this->db-> where('testid', $tid);		 
		 $query = $this->db->get('questionans'); 
		 return $query;
		
	
	}
	public function getrealoption($realoption,$quid)
	{
		 $this->db->where('queansid',$quid);
		 return $this->db->get('questionans')->row()->$realoption;
		
	
	}

	public function savecoursetest($username,$data)	
	{
		 $_table = $username;
		
    	$this->db->insert($_table, $data);
    	
		

	}
	public function getinfo($testid){
		 $this->db->where('testid',$testid);
		 $query = $this->db->get('testdetails');  

         return $query; 
	}
	public function catchans($courseid,$testid,$username){
		$this->db->where('courseid',$courseid);
		$this->db->where('testid',$testid);
		$query = $this->db->get($username);
		return $query;
	}

	public function getquetionans($username){
		// $this->db->order_by("studentid", "desc");
      	
         $query = $this->db->get($username);  

         return $query;  
	}
	public function insertquetion($ins1,$username,$data){
		 $_table = $username;
		$data['realans']=$ins1;
    	$this->db->insert($_table, $data);
	}
	public function savecoursetestreport($totalmarks,$username,$data)	
	{
		 
		 $_tablereport = $username."_report";
		//$this->load->dbforge();
    	$data['totalmarks']=$totalmarks;
    	$this->db->insert($_tablereport, $data);
		

	}


	public function selectexam()
        {

    	$query= $this->db->get('studentdetails');
        return $query;

    }

    	public function selectexam1($id){
		  $this->db-> where('enrollmentno', $id);		 
		  $query = $this->db->get("studentdetails");  
		  return $query;
	}
}
?>
