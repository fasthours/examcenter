<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Testdetails_model extends CI_Model {

	public function savetestdetails($data)
	
	{

    	$this->db->insert('testdetails', $data);
		

	}
	public function getAllCategories()
	{
    $this->db->select('subjectname');
    $q = $this->db->get('subjectname');

    if ($q->num_rows() > 0)
    {
        foreach($q->result() as $row) 
        {
            $data[] = $row;
        }
        return $data;
    }
}

public function selecttest()    
    {

    $this->db->select('testdetails.*,subjectname.*');
    $this->db->from('subjectname');
    $this->db->join('testdetails', 'testdetails.subjectname = subjectname.subjectid', 'right outer'); 
    $query = $this->db->get();
    return $query;
 
    }

    public function updatetest($id, $val1,$val2,$val3,$val4,$val5,$val6,$val7)
    {
     $this->db->where('testid', $id);
     $data = array("testname" => $val1,"subjectname" => $val2, "totalquestion" => $val3, "totalmarks" => $val4, "testdate" => $val5, "testtime" => $val6, "date" => $val7);
     $this->db->update('testdetails', $data);
    }

public function did_delete_row($id){
          $this->db-> where('testid', $id);
          $this->db-> delete('testdetails');
          $query = $this->db->get("testdetails");  
          return $query;
    }
    

}

	
}
?>


