<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Selectcourse_test extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

function __construct() {
		parent::__construct();
		$this->load->helper('url');
	}
	public function index()
	{
		$this->load->model('studentlogin_model');
		 $this->load->database();
		$data['h']=$this->studentlogin_model->selectexam(); 
		$this->load->view('selectcourse_test',$data);

	}
	
	public function login()
	{
       	$username  = $this->input->get_post('enrollmentno');
      // 	echo "<script>alert(".$username.")</script>";
       	$username = str_replace("/", "_", $username);
     	$password  = $this->input->get_post('passwordstud');

   		$this->load->model('studentlogin_model');

		$getboolan=	$this->studentlogin_model->login_valid($username,$password);
		if($getboolan==TRUE)
		{
		$data['coursename']=$this->subjectname_model->selectsubject(); 
			$data['testname']=$this->testdetails_model->selecttest(); 	
		$data['h']=$this->studentlogin_model->selectexam1($username); 
		
		$this->load->view('selectcourse_test',$data);

		}
		elseif($getboolan==FALSE)
		{
			echo "<script>alert('Wrong Username / Password');</script>";
			$this->load->view('welcome_message'); 
		}
	}
	function gettest(){
		$this->load->model('testdetails_model');
		$mysubjectid=$this->input->get_post('subject_id');
		$data['l']=$this->testdetails_model->selecttestbysubject($mysubjectid);
		foreach($data['l']->result() as $row6) {
			echo "<option value='".$row6->testid."'>".$row6->testname."</option>";
		}
	}
	public function savecourstest(){
		 $this->load->helper('date');


		 date_default_timezone_set('Asia/Kolkata');
$idtest= $this->input->get_post('testid');
		 	$data['l']=$this->testdetails_model->selecttest1($idtest);
				foreach($data['l']->result() as $row6) {
					//echo "<option value='".$row6->testid."'>".$row6->testname."</option>";
					$totalmarks = $row6->totalmarks;
				}

			$this->load->model('studentlogin_model');
				 $save = array(
		      	'courseid'  => $this->input->get_post('subjectid'),
		     	'testid'  => $this->input->get_post('testid'),
		     	'starttime' => $this->date=date('d/m/y h:m:s'),
		     	
		     	);	
				 	$enrollmentno = $this->input->get_post('enrollmentno');
				 	$courseid  = $this->input->get_post('subjectid');
		     		$testid  = $this->input->get_post('testid');
				
		         //echo "<script>alert(".$enrollmentno.")</script>";	
              //   $this->db->insert('table_image', $data); 



		$this->load->model('studentlogin_model');

		$getboolan=	$this->studentlogin_model->examcheck($testid, $courseid ,$enrollmentno);
		if($getboolan==FALSE)
		{
			
					 $this->studentlogin_model->savecoursetest($enrollmentno,$save);	
					 $this->studentlogin_model->savecoursetestreport($totalmarks,$enrollmentno,$save);
             	     echo "Data inserted successfully!!!";
 		      		 // echo '<script>window.location.href = "http://localhost/examcenter/index.php/Exam_page/index/'.$enrollmentno.'/'.$courseid.'/'.$testid.'";</script>';
                 //	  echo '<script>window.location.href = "http://localhost/examcenter/index.php/Exam_page/exam_page1/'.$enrollmentno.'/'.$courseid.'/'.$testid.'";</script>';
             	     echo "<script>window.location.href='".base_url('index.php/Exam_page/exam_page1/'.$enrollmentno.'/'.$courseid.'/'.$testid)."'</script>";
                  
		}
		elseif($getboolan==TRUE)
		{
			echo "<script>alert('You Already Done The Exam, Contact 9890676345')</script>";
			$this->load->view('welcome_message'); 
		}


                 
                 // $this->load->view('exam_page',$data); 
                 // $this->load->view('/Exam_page/'.$enrollmentno);
                //  redirect('/exam_page/index/'.$enrollmentno);
	}
	




		
	
}

