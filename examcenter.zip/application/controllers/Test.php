<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
		parent::__construct();
		 $this->load->model('subjectname_model');
		  $this->load->model('testdetails_model');
		$this->load->helper('url');
	}
	public function index()
	{
		
		$this->load->database();
		$data['h']=$this->subjectname_model->selectsubject(); 

		$data['k']=$this->testdetails_model->selecttest(); 

		$this->load->view('tests',$data);
		
	}
	public function testing()
	{
		//		$this->load->database();
		
				$testid =$this->input->get_post('name');
				$data['k']=$this->testdetails_model->selecttest(); 
				foreach ($data['k']->result() as $row)                                   
 				{
 					if($testid==$row->testid)
 					{
 						echo $row->onoff;
 					}
					
				}
							
				
			
		
        		
	}
	public function test_details()
	{
			if($this->input->get_post("submit")=="submit"){

			

			$testname = $this->input->get_post('testname');
			//echo $testname;
					$getboolan=	$this->testdetails_model->test_valid($testname);

					if($getboolan==TRUE)
					{
								echo "<script>alert('This Test Name Is Already In Database')</script>";
								echo "<script>window.location.href='".base_url('index.php/Test')."'</script>";
					}
					elseif($getboolan==FALSE)
					{
						$save = array(
				     	'testname'  => $this->input->get_post('testname'),
				     	'subjectname'  => $this->input->get_post('subjectname'),
				     	'totalquestion'  => $this->input->get_post('totalquestion'),
				     	'totalmarks'  => $this->input->get_post('totalmarks'),
				     //	'testdate'  => $this->input->get_post('testdate'),
				     //	'testtime'  => $this->input->get_post('testtime'),
				     	'testduration'  => $this->input->get_post('tduration'),
				     	'date' =>$this->input->get_post('todaya'),
				     	'onoff'  => $this->input->get_post('optionradio'),
				     	);


	        $this->testdetails_model->savetestdetails($save);
			//echo "Data updated successfully!!!";
	        echo "<script>alert('Data Inserted successfully')</script>";
				echo "<script>window.location.href='".base_url('index.php/Test')."'</script>";	     
					}
			}


			elseif($this->input->get_post("update")=="update"){
				$testid = $this->input->get_post("testidmodel");
				
				$data['test']=$this->testdetails_model->selecttest1($testid);
				$data['k']=$this->testdetails_model->selecttest2();
				$data['h']=$this->subjectname_model->selectsubject(); 
				//echo "<script>alert(".$testid.")</script>";
				$this->load->view('testupdate',$data);
			}
 			//echo "<script>window.location.href='".base_url('index.php/Test')."'</script>";


     
//echo "Data inserted successfully!!!";
   //  	echo '<script>window.location.href = "http://localhost/examcenter/index.php/Test/";</script>';
     //	echo "<script>window.location.href='".base_url('index.php/Test')."'</script>";
     
	}
	public function edittest_details()
	{

		if($this->input->get_post("delete")=="Delete")
		{
				$id = $this->input->get_post('testidmodel');
		
				$this->testdetails_model->did_delete_row($id);
				//echo "<script>alert('".$id."')</script>";
				echo "Data deleted sucessfully";
		}
		elseif($this->input->get_post("update")=="Update")
		{

				$testname =$this->input->get_post('testnamemodel');

				$getboolan=	$this->testdetails_model->test_valid($testname);
				if($getboolan==TRUE)
				{
							echo "<script>alert('This Test Name Is Already In Database')</script>";
				}
				elseif($getboolan==FALSE)
				{
					
					 $val1 = $this->input->get_post('testname');
					 $val2 = $this->input->get_post('subjectname');
					 $val3 = $this->input->get_post('totalquestion');
					 $val4 = $this->input->get_post('totalmarks');
					 $val5 = $this->input->get_post('optionradiomodel');
					 $val6 = $this->input->get_post('tdurationmodel');
					 $val7 = $this->input->get_post('todayamodel');
					
					 $id = $this->input->get_post('testidmodel');
					
					$this->testdetails_model->updatetest( $id , $val1 ,$val2,$val3,$val4,$val5,$val6,$val7);
		//echo "Data updated successfully!!!";
				     echo "<script>alert('Data Updated successfully')</script>";
				}




	//s	echo "Data updated successfully!!!";
		}
     	//echo '<script>window.location.href = "http://localhost/examcenter/index.php/Test/";</script>';
     	echo "<script>window.location.href='".base_url('index.php/Test')."'</script>";
      
	}
	
}
