<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Exam_page extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
function __construct() {
		parent::__construct();
		$this->load->helper('url');
	}

	public function index()
	{
		$this->load->model('studentlogin_model');
		$username = $this->uri->segment(3);
		$courseid = $this->uri->segment(4);
		$testid = $this->uri->segment(5);
	
		//$data['h']=$this->studentlogin_model->selectexam(); 
		$data['enrollmentno']=$username;
		$data['courseid']=$courseid;
		$data['testid']=$testid;	
		$data['m']=$this->queans_model->selectquestionbyct($courseid,$testid);
		$countmyque = 1;
		foreach($data['m']->result() as $row) {
			
				if($countmyque==1){
			//	echo $row->queansid;
				$data['t']=$this->queans_model->selectquestionlimitnumbers($row->queansid); 
				}
				$countmyque++;
			
		}
		$data['ql']=$this->queans_model->selectquestionbyct($courseid,$testid);
		//$data['t']=$this->queans_model->selectquestionlimitnumbers(1); 
		$data['coursename']=$this->subjectname_model->selectsubject1($courseid);
		$dat['courseid']= $this->input->get_post('courseid');
		$data['testname']=$this->testdetails_model->selecttest1($testid);
		$dat['testid']= $this->input->get_post('testeid');
		$data['h']=$this->studentlogin_model->selectexam1($username); 
		$data['endcount']=$this->queans_model->total_count($courseid,$testid);
		$data['getans']=$this->studentlogin_model->getquetionans($username);
		$this->load->view('exam_page',$data);

	}
	public function exam_pageup(){
			$this->load->model('studentlogin_model');
		$username = $this->uri->segment(3);
		$courseid = $this->uri->segment(4);
		$testid = $this->uri->segment(5);
	
		//$data['h']=$this->studentlogin_model->selectexam(); 
		$data['courseid']=$courseid;
		$data['testid']=$testid;	
		$data['m']=$this->queans_model->selectquestionbyct($courseid,$testid);
		$countmyque = 1;
		foreach($data['m']->result() as $row) {
			
				if($countmyque==1){
			//	echo $row->queansid;
				$data['t']=$this->queans_model->selectquestionlimitnumbers($row->queansid); 
				}
				$countmyque++;
			
		}
		$data['ql']=$this->queans_model->selectquestionbyct($courseid,$testid);
		//$data['t']=$this->queans_model->selectquestionlimitnumbers(1); 
		$data['coursename']=$this->subjectname_model->selectsubject1($courseid);
		$dat['courseid']= $this->input->get_post('courseid');
		$data['testname']=$this->testdetails_model->selecttest1($testid);
		$dat['testid']= $this->input->get_post('testeid');
		$data['h']=$this->studentlogin_model->selectexam1($username); 
		$data['endcount']=$this->queans_model->total_count($courseid,$testid);
$data['getans']=$this->studentlogin_model->getquetionans($username);
		$this->load->view("exam_pageup",$data);
	}
	public function exam_page1(){
				$this->load->model('studentlogin_model');
		$username = $this->uri->segment(3);
		$courseid = $this->uri->segment(4);
		$testid = $this->uri->segment(5);
	
		//$data['h']=$this->studentlogin_model->selectexam(); 
		$data['courseid']=$courseid;
		$data['testid']=$testid;	
		$data['username']=$username;
		$data['m']=$this->queans_model->selectquestionbyct($courseid,$testid);
		$countmyque = 1;
		foreach($data['m']->result() as $row) {
			
				if($countmyque==1){
			//	echo $row->queansid;
				$data['t']=$this->queans_model->selectquestionlimitnumbers($row->queansid); 
				}
				$countmyque++;
			
		}
		$data['ql']=$this->queans_model->selectquestionbyct($courseid,$testid);
		//$data['t']=$this->queans_model->selectquestionlimitnumbers(1); 
		$data['coursename']=$this->subjectname_model->selectsubject1($courseid);
		$dat['courseid']= $this->input->get_post('courseid');
		$data['testname']=$this->testdetails_model->selecttest1($testid);
		$dat['testid']= $this->input->get_post('testeid');
		$data['h']=$this->studentlogin_model->selectexam1($username); 
		$data['endcount']=$this->queans_model->total_count($courseid,$testid);
		$data['getans']=$this->studentlogin_model->getquetionans($username);
		$this->load->view("exam_page1",$data);
	}
	
	
	public function getnext(){


					if($this->input->get_post("next")=="next"){

							$courseid= $this->input->get_post('courseid');
							$testid = $this->input->get_post('testid');

							$previousid  = $this->input->get_post('previousid');
							$queansid = $previousid;
							$data['ql']=$this->queans_model->selectquestionbyct($courseid,$testid);
							$data['coursename']=$this->subjectname_model->selectsubject1($courseid);
							
							$data['testname']=$this->testdetails_model->selecttest1($testid);
							$data['t']=$this->queans_model->selectquestionlimit1($previousid,$testid,$courseid);




						/* very imp */

						$data['testid']= $this->input->get_post('testid');
						$data['courseid']= $this->input->get_post('courseid');
						$courseid = $this->input->get_post('courseid');
						$testid=$this->input->get_post('testid');
						$data['endcount']=$this->queans_model->total_count($courseid,$testid);
						$this->load->model('studentlogin_model');
			   			$username  = $this->input->get_post('username');
						$data['h']=$this->studentlogin_model->selectexam1($username); 
						$engoption=$this->input->get_post('engoption');
						$hindioption=$this->input->get_post('hindioption');
						$hinditrueans=$this->input->get_post('hinditrueans');
						$englishtrueans=$this->input->get_post('englishtrueans');
						//echo "<script>alert(".$englishtrueans.")</script>";
						$enroll = $this->input->get_post('enroll');
						/*if($engoption==false){
							if($hinditrueans==false){
								$ans=$hindioption;
							}
							elseif($hindioption==false){
								$ans=$hinditrueans;
							}
							//$ans=$hinditrueans."_".$hindioption;
						}
						elseif($hindioption==false){
							if($englishtrueans==false){
								$ans= $engoption;
							}
							elseif($engoption==false){
								$ans=$englishtrueans;
							}
							//$ans=$engoption."_".$englishtrueans;
						}*/
						if($englishtrueans==true){
							$ans= $englishtrueans;
						}
						if($hindioption==true){
							$ans=$hindioption;
						}
						if($engoption==true){
							$ans=$engoption;
						}
						if($hinditrueans==true){
							$ans=$hinditrueans;
						}

						
						$save1 = array(
				     	'questionsid'  => $queansid,
				     	'answer'  => $ans,
				     	'testid'  => $testid,
				     	'courseid'  => $courseid,
				     	'starttime'  => $this->date=date('d/m/y h:m:s'),		     	
				     	);	

						$this->load->model('studentlogin_model');

						$getboolan=	$this->studentlogin_model->examanscheck($courseid, $testid ,$enroll,$queansid);
						if($getboolan==FALSE)
						{
								$data['realans']=$this->studentlogin_model->getrealans($courseid,$testid,$queansid);
								
                                 
                                 foreach ($data['realans']->result() as $row)  
	                             { 
									 if($row->englishquestion==false){
	                                 	
	                                 	if($row->hindioption1==false){
	                                 		$realoption=$row->hinditrueans;
	                                 	}
	                                 	else{
		                              	  $realans1=$row->hindirightoption;
		                              	   $realoption=$this->studentlogin_model->getrealoption($realans1,$queansid);
		                                }
	                                 	
	                                 }elseif($row->englishquestion!=false){
	                                 	$realans1=$row->engrightoption;
	                                 	$realoption=$this->studentlogin_model->getrealoption($realans1,$queansid);
	                                 }
	                                 if($row->hindiquestion==false && $row->engoption1==false){
	                                 	$realoption=$row->englishtrueans;
	                                 }
                            	 }
								$this->studentlogin_model->insertquetion($realoption,$enroll,$save1);
				                  
						}
						elseif($getboolan==TRUE)
						{
							    $this->studentlogin_model->updatequestion($courseid,$testid,$queansid,$enroll,$ans);
						}


						/* end of very imp */

					}
					else if($this->input->get_post("submittest")=="Finish"){
						$courseid= $this->input->get_post('courseid');
							$testid = $this->input->get_post('testid');

							$previousid  = $this->input->get_post('previousid');
							$queansid = $previousid;
							$data['ql']=$this->queans_model->selectquestionbyct($courseid,$testid);
							$data['coursename']=$this->subjectname_model->selectsubject1($courseid);
							
							$data['testname']=$this->testdetails_model->selecttest1($testid);
							

						
						$data['t']=$this->queans_model->selectquestionlimit($previousid);

						/* very imp */

						$data['testid']= $this->input->get_post('testid');
						$data['courseid']= $this->input->get_post('courseid');
						$courseid = $this->input->get_post('courseid');
						$testid=$this->input->get_post('testid');
						$data['endcount']=$this->queans_model->total_count($courseid,$testid);
						$this->load->model('studentlogin_model');
			   			$username  = $this->input->get_post('username');
						$data['h']=$this->studentlogin_model->selectexam1($username); 
						$engoption=$this->input->get_post('engoption');
						$hindioption=$this->input->get_post('hindioption');
						$hinditrueans=$this->input->get_post('hinditrueans');
						$englishtrueans=$this->input->get_post('englishtrueans');
						//echo "<script>alert(".$englishtrueans.")</script>";
						$enroll = $this->input->get_post('enroll');
						/*if($engoption==false){
							if($hinditrueans==false){
								$ans=$hindioption;
							}
							elseif($hindioption==false){
								$ans=$hinditrueans;
							}
							//$ans=$hinditrueans."_".$hindioption;
						}
						elseif($hindioption==false){
							if($englishtrueans==false){
								$ans= $engoption;
							}
							elseif($engoption==false){
								$ans=$englishtrueans;
							}
							//$ans=$engoption."_".$englishtrueans;
						}*/
						if($englishtrueans==true){
							$ans= $englishtrueans;
						}
						if($hindioption==true){
							$ans=$hindioption;
						}
						if($engoption==true){
							$ans=$engoption;
						}
						if($hinditrueans==true){
							$ans=$hinditrueans;
						}

						
						$save1 = array(
				     	'questionsid'  => $queansid,
				     	'answer'  => $ans,
				     	'testid'  => $testid,
				     	'courseid'  => $courseid,
				     	'starttime'  => $this->date=date('d/m/y h:m:s'),		     	
				     	);	

						$this->load->model('studentlogin_model');

						$getboolan=	$this->studentlogin_model->examanscheck($courseid, $testid ,$enroll,$queansid);
						if($getboolan==FALSE)
						{
								$data['realans']=$this->studentlogin_model->getrealans($courseid,$testid,$queansid);
								
                                 
                                 foreach ($data['realans']->result() as $row)  
	                             { 
									 if($row->hindiquestion==true){
	                                 	
	                                 	if($row->hindioption1==false){
	                                 		$realoption=$row->hinditrueans;
	                                 	}
	                                 	else{
		                              	  $realans1=$row->hindirightoption;
		                              	   $realoption=$this->studentlogin_model->getrealoption($realans1,$queansid);
		                                }
	                                 	
	                                 }elseif($row->englishquestion==true){
	                                 	if($row->engoption1==false){
	                                 		$realoption=$row->hinditrueans;
	                                 	}
	                                 	else{
		                              	 $realans1=$row->engrightoption;
	                                 	$realoption=$this->studentlogin_model->getrealoption($realans1,$queansid);
		                                }

	                                 	
	                                 }
	                                 
                            	 }
								$this->studentlogin_model->insertquetion($realoption,$enroll,$save1);
				                  
						}
						elseif($getboolan==TRUE)
						{
							    $this->studentlogin_model->updatequestion($courseid,$testid,$queansid,$enroll,$ans);
						}


						/* end of very imp */
						echo "<script>alert('You are redirect to home page.. Thank you')</script>";
					
						echo "<script>window.top.location.href='".base_url('index.php/Welcome/index1/'.$testid.'/'.$courseid.'/'.$enroll)."'</script>";					
					}
					else if($this->input->get_post("previous")=="previous"){

						$courseid= $this->input->get_post('courseid');
						$testid = $this->input->get_post('testid');
						$previousid  = $this->input->get_post('previousid');
						$data['ql']=$this->queans_model->selectquestionbyct($courseid,$testid);
						$data['coursename']=$this->subjectname_model->selectsubject1($courseid);
						$queansid = $previousid;

							$data['testname']=$this->testdetails_model->selecttest1($testid);
					
						$data['t']=$this->queans_model->selectquestionlimitminus($previousid,$courseid,$testid);



/* very imp */

						$data['testid']= $this->input->get_post('testid');
						$data['courseid']= $this->input->get_post('courseid');
						$courseid = $this->input->get_post('courseid');
						$testid=$this->input->get_post('testid');
						$data['endcount']=$this->queans_model->total_count($courseid,$testid);
						$this->load->model('studentlogin_model');
			   			$username  = $this->input->get_post('username');
						$data['h']=$this->studentlogin_model->selectexam1($username); 
						$engoption=$this->input->get_post('engoption');
						$hindioption=$this->input->get_post('hindioption');
						$hinditrueans=$this->input->get_post('hinditrueans');
						$englishtrueans=$this->input->get_post('englishtrueans');
						//echo "<script>alert('".$englishtrueans."')</script>";
						//echo "<script>alert('".$engoption."')</script>";
						//echo "<script>alert('".$hindioption."')</script>";
						//echo "<script>alert('".$hinditrueans."')</script>";
						$enroll = $this->input->get_post('enroll');
						/*if($engoption==false){
							echo "<script>alert('i am in hindi insert ans';)</script>";
							if($hinditrueans==false){
								$ans=$hindioption;
							}
							elseif($hindioption==false){
								$ans=$hinditrueans;
							}
							//$ans=$hinditrueans."_".$hindioption;
						}
						elseif($hindioption==false){
							echo "<script>alert('i am in english insert ans';)</script>";
							if($englishtrueans==false){
								$ans= $engoption;
							}
							elseif($engoption==false){
								$ans=$englishtrueans;
								echo "<script>alert('".$ans."'')</script>";
							}
							//$ans=$engoption."_".$englishtrueans;
						}*/

						if($englishtrueans==true){
							$ans= $englishtrueans;
						}
						if($hindioption==true){
							$ans=$hindioption;
						}
						if($engoption==true){
							$ans=$engoption;
						}
						if($hinditrueans==true){
							$ans=$hinditrueans;
						}

						
						$save1 = array(
				     	'questionsid'  => $queansid,
				     	'answer'  => $ans,
				     	'testid'  => $testid,
				     	'courseid'  => $courseid,
				     	'starttime'  => $this->date=date('d/m/y h:m:s'),		     	
				     	);	

						$this->load->model('studentlogin_model');

						$getboolan=	$this->studentlogin_model->examanscheck($courseid, $testid ,$enroll,$queansid);
						if($getboolan==FALSE)
						{
								$data['realans']=$this->studentlogin_model->getrealans($courseid,$testid,$queansid);
								
                                 
                                 foreach ($data['realans']->result() as $row)  
	                             { 
									 if($row->englishquestion==false){
	                                 	
	                                 	if($row->hindioption1==false){
	                                 		$realoption=$row->hinditrueans;
	                                 	}
	                                 	else{
		                              	  $realans1=$row->hindirightoption;
		                              	   $realoption=$this->studentlogin_model->getrealoption($realans1,$queansid);
		                                }
	                                 	
	                                 }elseif($row->englishquestion!=false){
	                                 	$realans1=$row->engrightoption;
	                                 	$realoption=$this->studentlogin_model->getrealoption($realans1,$queansid);
	                                 }
	                                 if($row->hindiquestion==false && $row->engoption1==false){
	                                 	$realoption=$row->englishtrueans;
	                                 }
                            	 }
								$this->studentlogin_model->insertquetion($realoption,$enroll,$save1);
				                  
						}
						elseif($getboolan==TRUE)
						{
							    $this->studentlogin_model->updatequestion($courseid,$testid,$queansid,$enroll,$ans);
						}


						/* end of very imp */

					}
					else{
						$testid = $this->input->get_post('testid');
						$courseid= $this->input->get_post('courseid');
						$mygetid = $this->input->get_post("mygetid");					
						$data['ql']=$this->queans_model->selectquestionbyct($courseid,$testid);
						$data['coursename']=$this->subjectname_model->selectsubject1($courseid);
							
							//$data['he']=$this->queans_model->selectquestionlimitnumbers();
						$data['testname']=$this->testdetails_model->selecttest1($testid);
						
						$data['t']=$this->queans_model->selectquestionlimitnumbers($mygetid);
						$queansid = $mygetid;

						/*very imp */

						$data['testid']= $this->input->get_post('testid');
						$data['courseid']= $this->input->get_post('courseid');
						$courseid = $this->input->get_post('courseid');
						$testid=$this->input->get_post('testid');
						$data['endcount']=$this->queans_model->total_count($courseid,$testid);
						$this->load->model('studentlogin_model');
			   			$username  = $this->input->get_post('username');
						$data['h']=$this->studentlogin_model->selectexam1($username); 
						$engoption=$this->input->get_post('engoption');
						$hindioption=$this->input->get_post('hindioption');
						$hinditrueans=$this->input->get_post('hinditrueans');
						$englishtrueans=$this->input->get_post('englishtrueans');
						$enroll = $this->input->get_post('enroll');
						
						if($engoption==false){
							if($hinditrueans==false){
								$ans=$hindioption;
							}
							elseif($hindioption==false){
								$ans=$hinditrueans;
							}
							//$ans=$hinditrueans."_".$hindioption;
						}
						elseif($hindioption==false){
							if($englishtrueans==false){
								$ans= $engoption;
							}
							elseif($engoption==false){
								$ans=$englishtrueans;
							}
							//$ans=$engoption."_".$englishtrueans;
						}
						
						/* end of very imp */
					}

					$data['testid']= $this->input->get_post('testid');
					$data['courseid']= $this->input->get_post('courseid');
					$courseid = $this->input->get_post('courseid');
					$testid=$this->input->get_post('testid');
					$data['endcount']=$this->queans_model->total_count($courseid,$testid);
					$this->load->model('studentlogin_model');
		   			$username  = $this->input->get_post('username');
					$data['h']=$this->studentlogin_model->selectexam1($username); 
					$engoption=$this->input->get_post('engoption');
					$hindioption=$this->input->get_post('hindioption');
					$hinditrueans=$this->input->get_post('hinditrueans');
					$englishtrueans=$this->input->get_post('englishtrueans');
					$enroll = $this->input->get_post('enroll');
					//$ans=$engoption."_".$englishtrueans;
					
					

					$this->load->model('studentlogin_model');
					$data['getans']=$this->studentlogin_model->getquetionans($enroll);
					$data['enrollmentno']=$enroll;
					$this->load->view('exam_page',$data);


	}






		
	
}
