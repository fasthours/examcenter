<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		
		$this->load->view('welcome_message');
		
	}
	public function adminmenu()
	{
		$this->load->view('masters');
		
	}
	public function login()
	{
       	$username  = $this->input->get_post('enrollmentno');
     	$password  = $this->input->get_post('password');

   		$this->load->model('login_model');

		$getboolan=	$this->login_model->login_valid($username,$password);
		if($getboolan==TRUE)
		{
		$this->load->view('masters');
		}
		elseif($getboolan==FALSE)
		{
			
			$this->load->view('welcome_message'); 
		}
	}
	public function exampage()
	{
		$this->load->view('exam_page');
		
	}
	public function studentdetails()
	{
		//load the database  
         $this->load->database();  
         //load the model  
       //  $this->load->model('select');  
         //load the method of model  
         $data['h']=$this->studentdetails_model->selectstudent();   
		$this->load->view('students',$data);
		
	}
	public function subjectname()
	{
		 $this->load->database();
		$data['h']=$this->subjectname_model->selectsubject(); 
		$this->load->view('subjects',$data);
		
	}
	public function testdetails()
	{
		$this->load->database();
		$data['h']=$this->subjectname_model->selectsubject(); 

		$data['k']=$this->testdetails_model->selecttest(); 

		$this->load->view('tests',$data);
		
	}
	public function addqueans()
	{
		$data['h']=$this->subjectname_model->selectsubject(); 
		$data['k']=$this->testdetails_model->selecttest();
		$data['m']=$this->queans_model->selectquestion(); 
		$this->load->view('questionanswer',$data);
		
	}
	public function construct()
	{
		$this->load->model('studentdetails_model');
		$this->load->model('subjectname_model');
		$this->load->model('testdetails_model');

	}
	public function student_details()
	{

	//image 
		$nameofimg = $this->input->get_post('enrollmentno')."_".$this->input->get_post('contactno');  
               
	
	  			$config['upload_path']          = './uploads/';
                $config['allowed_types']        = 'gif|jpg|png';
                $config['max_size']             = 100;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;
                $config['file_name']            = strtolower($nameofimg.$_FILES['photo']['name']);
                $nameofimg = strtolower($nameofimg.$_FILES['photo']['name']);	

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('photo'))
                {
                       // $error = array('error' => $this->upload->display_errors());

                        //$this->load->view('students', $error);
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());

                //        $this->load->view('students', $data);
                }
	
   //end of image	   
   				//$nameofimg = $this->input->get_post('enrollmentno')."_".$this->input->get_post('enrollmentno');  
               
		         $save = array(
		     	'name'  => $this->input->get_post('name'),
		     	'address'  => $this->input->get_post('address'),
		     	'contactno'  => $this->input->get_post('contactno'),
		     	'email'  => $this->input->get_post('email'),
		     	'enrollmentno'  => $this->input->get_post('enrollmentno'),
		     	'photo'  => $nameofimg,
		     	'password'  => $this->input->get_post('password'),
		     	'date' =>$this->input->get_post('todaya'),
		     	);	

		         	
                 //$this->db->insert('table_image', $data); 
                  $this->studentdetails_model->savestudentdetails($save);
                  echo "Data inserted successfully!!!";
 		      	  echo '<script>window.location.href = "http://localhost/examcenter/index.php/Welcome/studentdetails";</script>';
	
    }


	public function subject_name()
	{
     $save = array(
     	'subjectname'  => $this->input->get_post('subjectname'),
     	//'subjectcode'  => $this->input->get_post('subjectcode'),
     	'date' =>$this->input->get_post('todaya'),
     	);


        $this->subjectname_model->savesubjectname($save);
     	echo "Data inserted successfully!!!";
     	echo '<script>window.location.href = "http://localhost/examcenter/index.php/Welcome/subjectname";</script>';
     
	}
	public function test_details()
	{
     $save = array(
     	'testname'  => $this->input->get_post('testname'),
     	'subjectname'  => $this->input->get_post('subjectname'),
     	'totalquestion'  => $this->input->get_post('totalquestion'),
     	'totalmarks'  => $this->input->get_post('totalmarks'),
     	'testdate'  => $this->input->get_post('testdate'),
     	'testtime'  => $this->input->get_post('testtime'),
     	'date' =>$this->input->get_post('todaya'),
     	);


        $this->testdetails_model->savetestdetails($save);
     	echo "Data inserted successfully!!!";
     	echo '<script>window.location.href = "http://localhost/examcenter/index.php/Welcome/testdetails";</script>';
     
	}

	public function questionanswer_details()
	{
     $save = array(
     	'subjectid '  => $this->input->get_post('subjectid'),
     	'testid '  => $this->input->get_post('testid'),
     	'englishquestion'  => $this->input->get_post('englishquestion'),
     	'engoption1'  => $this->input->get_post('engoption1'),
     	'engoption2'  => $this->input->get_post('engoption2'),
     	'engoption3'  => $this->input->get_post('engoption3'),
     	'engoption4'  => $this->input->get_post('engoption4'),
     	'hindiquestion'  => $this->input->get_post('hindiquestion'),
     	'hindioption1'  => $this->input->get_post('hindioption1'),
     	'hindioption2'  => $this->input->get_post('hindioption2'),
     	'hindioption3'  => $this->input->get_post('hindioption3'),
     	'hindioption4'  => $this->input->get_post('hindioption4'),
     	'hinditrueans'  => $this->input->get_post('hinditrueans'),
     	'englishtrueans'  => $this->input->get_post('englishtrueans'),
     	'engrightoption'  => $this->input->get_post('engrightoption'),
     	'hindirightoption'  => $this->input->get_post('hindirightoption'),
     	'data' =>$this->input->get_post('todaya'),
     	);


        $this->queans_model->savequeans($save);
     	echo "Data inserted successfully!!!";
     	echo '<script>window.location.href = "http://localhost/examcenter/index.php/Welcome/addqueans";</script>';
     
	}

	public function editsubject_name()
	{

		if($this->input->get_post("delete")=="Delete"){
				$id = $this->input->get_post('subjectidmodel');
		
				$this->subjectname_model->did_delete_row($id);
				//echo "<script>alert('".$id."')</script>";
				echo "Data deleted sucessfully";
			}
			elseif($this->input->get_post("update")=="Update"){

		 $val1 = $this->input->get_post('subjectnamemodel');
		  $val2 = $this->input->get_post('todayamodel');
		 $id = $this->input->get_post('subjectidmodel');
		
		$this->subjectname_model->updatesubject( $id , $val1 , $val2 );
		echo "Data updated successfully!!!";
	}
     	echo '<script>window.location.href = "http://localhost/examcenter/index.php/Welcome/subjectname";</script>';
      
	}

	public function edittest_details()
	{

		if($this->input->get_post("delete")=="Delete")
		{
				$id = $this->input->get_post('testidmodel');
		
				$this->testdetails_model->did_delete_row($id);
				//echo "<script>alert('".$id."')</script>";
				echo "Data deleted sucessfully";
		}
		elseif($this->input->get_post("update")=="Update")
		{

		 $val1 = $this->input->get_post('testnamemodel');
		 $val2 = $this->input->get_post('subjectnamemodel');
		 $val3 = $this->input->get_post('totalquestionmodel');
		 $val4 = $this->input->get_post('totalmarksmodel');
		 $val5 = $this->input->get_post('testdatemodel');
		 $val6 = $this->input->get_post('testtimemodel');
		 $val7 = $this->input->get_post('todayamodel');
		 
		 $id = $this->input->get_post('testidmodel');
		
		$this->testdetails_model->updatetest( $id , $val1 ,$val2,$val3,$val4,$val5,$val6,$val7);
		echo "Data updated successfully!!!";
		}
     	echo '<script>window.location.href = "http://localhost/examcenter/index.php/Welcome/testdetails";</script>';
      
	}

	public function testing()
	{
		$search = $this->input->get_post("name");
        echo $search;
	}

	public function deletestudent()
	{
		 
		 
		echo "Data deleted successfully!!!";
     	echo '<script>window.location.href = "http://localhost/examcenter/index.php/Welcome/studentdetails";</script>';
      
	}

	public function editstudent_name()
	{


			if($this->input->get_post("delete")=="Delete"){
				$id = $this->input->get_post('studentidmodel');
		
				$this->studentdetails_model->did_delete_row($id);
				//echo "<script>alert('".$id."')</script>";
				echo "Data deleted sucessfully";
			}
			elseif($this->input->get_post("update")=="Update"){

				$nameofimg = $this->input->get_post('enrollmentnomodel')."_".$this->input->get_post('contactnomodel');  
               
	
	  			$config['upload_path']          = './uploads/';
                $config['allowed_types']        = 'gif|jpg|png';
                $config['max_size']             = 100;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;
                $config['file_name']            = strtolower($nameofimg.$_FILES['photomodel']['name']);
                $nameofimg = strtolower($nameofimg.$_FILES['photomodel']['name']);	

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('photomodel'))
                {
                       // $error = array('error' => $this->upload->display_errors());

                        //$this->load->view('students', $error);
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());

                //        $this->load->view('students', $data);
                }


		 $val1 = $this->input->get_post('namemodel');
		 $val2 = $this->input->get_post('addressmodel');
		 $val3 = $this->input->get_post('contactnomodel');
		 $val4 = $this->input->get_post('emailmodel');
		 $val5 = $this->input->get_post('enrollmentnomodel');
		 $val6 = $this->input->get_post('todayamodel');
		 $val7 = $nameofimg;
		 
		 $id = $this->input->get_post('studentidmodel');
		
		$this->studentdetails_model->updatestudent( $id , $val1 ,$val2,$val3,$val4,$val5,$val6,$val7);
		echo "Data updated successfully!!!";
		}
     	echo '<script>window.location.href = "http://localhost/examcenter/index.php/Welcome/studentdetails";</script>';
      
	}



	function showCategoryNames()
	{
    $data = array();
    $this->load->model('testdetails_model');
    $query = $this->categoryModel->getAllCategories();
    if ($query)
    {
        $data['records'] = $query;

    }
    

 }

}
