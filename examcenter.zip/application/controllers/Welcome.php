<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
		parent::__construct();
		$this->load->helper('url');
	}
	public function index()
	{
		
		$this->load->view('welcome_message');
		
	}
	public function index1()
	{
		$testid = $this->uri->segment(3);
		$courseid = $this->uri->segment(4);
		$enrollmentno = $this->uri->segment(5);
		 $this->load->helper('date');
		 date_default_timezone_set('Asia/Kolkata');
			$this->load->model('studentlogin_model');
		  $save = array(
		     	'testid'  => $testid,
		     	'courseid'  => $courseid,
		     	'endtime'  => $this->date=date('d/m/y h:m:s'),
		     	);	

		        $endtiming = $this->date=date('d/m/y h:m:s');

                    $this->studentlogin_model->savecoursetest($enrollmentno,$save);	
                   
                    $data['getmarks'] = $this->studentlogin_model->getinfo($testid); 
								foreach ($data['getmarks']->result() as $row)  
                                 { 
                                 	$totalmarks=$row->totalmarks;
                                 	$totalquestion=$row->totalquestion;                                 	
                                 }		
                                 if($totalquestion>$totalmarks){	
                                 $perquestionmarks = $totalquestion/$totalmarks;	
                                 }
                                 else if($totalmarks>$totalquestion){
                                   $perquestionmarks = $totalmarks/$totalquestion;		
                                 }				
                                 $data['countmarks']= $this->studentlogin_model->catchans($courseid,$testid,$enrollmentno);
                                 $counttrueans=0;
                                 foreach ($data['countmarks']->result() as $row1)  
                                 { 

                                 	 $answer=$row1->answer;
	                                 $realanswer=$row1->realans;

                                 	if($answer==false && $realanswer==false){

                                 	}
                                 	else{


	                                 	$answer=str_replace('_', '', $answer);
	                                 	//echo "<script>alert('answer = ".$answer."')</script>";
	                                 	
	                                 		//echo "<script>alert('realanswer = ".$realanswer."')</script>";
	                                 	if($answer==$realanswer){
	                                 		$counttrueans=$counttrueans+1;
	                                 	}
                                 	}
                                 	
                                 }	
                                 $totalmarksstu= $perquestionmarks * $counttrueans;	
                                 $avg = ($totalmarksstu / $totalmarks)*100;

                          $data['hstu']=$this->studentdetails_model->selectstudentbyenroll($enrollmentno);
		
		                foreach ($data['hstu']->result() as $rowstu)  {
		                	 $enrollstuname=$rowstu->name;          	
		                	
		                }

                    $this->studentlogin_model->updatecoursetest($totalmarksstu,$testid,$courseid,$enrollmentno,$endtiming);	
                     $savemaster = array(
						     	'enrollmentno'  => $enrollmentno,
						     	'name'  => $enrollstuname,
						     	'courseid'  => $courseid,
						     	'testid'  => $testid,		
						     	'totalmarks'=> 	$totalmarks,			     	
						     	'getmarks'=> 	$totalmarksstu,
						     	'avg'=> $avg,
						     	'dateandtime'  => $this->date=date('d/m/y h:m:s'),     	
						     	);	
							    $this->studentlogin_model->insertmasterreport($enrollmentno,$savemaster);



$totalastudent = 0;
								$totalstudent=0;
								$this->load->model('studentdetails_model');
							  $data['allstu']=$this->studentdetails_model->selectstudent();
							  foreach($data['allstu']->result() as $row){
							  	$count=1;
							  		 $enrollmentno=$row->enrollmentno;
							  		 echo "<script>alert('".$enrollmentno."'')</script>";
							  		 $totalstudent = $totalstudent+1;
							  		  $data['hmresult']=$this->studentdetails_model->masterreportcount($enrollmentno,$courseid,$testid);               
								          foreach ($data['hmresult']->result() as $row1) {
								          	if($enrollmentno == $row1->enrollmentno){
								          		if($count==1){
								          		 $totalastudent = $totalastudent +1 ;

								          		}
								          		$count++;

								          	}

								          	
								      }

							  }
							  $totalnstudent = $totalstudent-$totalastudent;

					$getboolanexammaster=	$this->studentdetails_model->exammaster_valid($testid,$courseid);
					if($getboolanexammaster==TRUE)
					{
							//$this->load->view('masters');

							
							   $this->studentlogin_model->updateexammaster($testid,$courseid,$totalstudent,$totalastudent,$totalnstudent);	

							   




					}
					elseif($getboolanexammaster==FALSE)
					{
						
						$saveexammaster = array(
						     	'courseid'  => $courseid,
						     	'testid'  => $testid,
						     	'totalstudent'  => $totalstudent,
						     	'astudent'  => $totalastudent,		
						     	'nastudent'=> 	$totalnstudent,			     	
						       	
						     	);	
							    $this->studentlogin_model->insertexammasterreport($saveexammaster);
					}



					//echo '<script>window.location.href = "http://localhost/examcenter/index.php"</script>';
					echo "<script>window.location.href='".base_url('index.php')."'</script>";



		
	}
	public function testing()
	{
		$search = $this->input->get_post("name");
        echo $search;
	}
	public function testing1()
	{
		 $this->load->database();
		$search = $this->input->get_post("name");
		$data=$this->subjectname_model->selectsubject1($search);
		foreach ($data-> result() as $row) { 
			$myreturnsearch = $row->subjectname;
		}
        echo $myreturnsearch;
	}

	public function adminmenu()
	{
		$this->load->view('masters');
		
	}
	public function login()
	{
       	$username  = $this->input->get_post('enrollmentno');
     	$password  = $this->input->get_post('password');

   		$this->load->model('login_model');

		$getboolan=	$this->login_model->login_valid($username,$password);
		if($getboolan==TRUE)
		{
		$this->load->view('masters');
		}
		elseif($getboolan==FALSE)
		{
			echo "<script>alert('Wrong Username / Password');</script>";
			$this->load->view('welcome_message'); 
		}
	}


}
