<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subject extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
		parent::__construct();
		$this->load->helper('url');
	}
	public function index()
	{
		
		 $this->load->database();
		$data['h']=$this->subjectname_model->selectsubject(); 
		$this->load->view('subjects',$data);
		
	}
	public function editsubject_name()
	{

		if($this->input->get_post("delete")=="Delete"){
				$id = $this->input->get_post('subjectidmodel');
		
				$this->subjectname_model->did_delete_row($id);
				//echo "<script>alert('".$id."')</script>";
				echo "Data deleted sucessfully";
			}
			elseif($this->input->get_post("update")=="Update"){



				$subjectname = $this->input->get_post('subjectnamemodel');

				$getboolan=	$this->subjectname_model->subject_valid($subjectname);
				if($getboolan==TRUE)
				{
							echo "<script>alert('This Course Is Already In Database')</script>";
				}
				elseif($getboolan==FALSE)
				{
							
					 $val1 = $this->input->get_post('subjectnamemodel');
					  $val2 = $this->input->get_post('todayamodel');
					 $id = $this->input->get_post('subjectidmodel');
					
					$this->subjectname_model->updatesubject( $id , $val1 , $val2 );
		//echo "Data updated successfully!!!";
				     echo "<script>alert('Data Updated successfully')</script>";
				}



		}
     //	echo '<script>window.location.href = "http://localhost/examcenter/index.php/Subject";</script>';
		echo "<script>window.location.href='".base_url('index.php/Subject')."'</script>";
      
	}
	public function subject_name()
	{
		$subjectname = $this->input->get_post('subjectname');

		$getboolan=	$this->subjectname_model->subject_valid($subjectname);
		if($getboolan==TRUE)
		{
					echo "<script>alert('This Course Is Already In Database')</script>";
		}
		elseif($getboolan==FALSE)
		{
					$save = array(
			     	'subjectname'  => $this->input->get_post('subjectname'),
			     	//'subjectcode'  => $this->input->get_post('subjectcode'),
			     	'date' =>$this->input->get_post('todaya'),
		     	);


		        $this->subjectname_model->savesubjectname($save);
		        	echo "<script>alert('Data inserted successfully')</script>";
		}

     	
     
     //	echo '<script>window.location.href = "http://localhost/examcenter/index.php/Subject";</script>';
		echo "<script>window.location.href='".base_url('index.php/Subject')."'</script>";
     
	}
	

}
