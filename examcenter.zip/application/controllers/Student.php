<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	function __construct() {
		parent::__construct();
		$this->load->helper('url');
	}
	public function index()
	{
		
		//load the database  
         $this->load->database();  
         //load the model  
       //  $this->load->model('select');  
         //load the method of model  
         $data['h']=$this->studentdetails_model->selectstudent();  

		$data['sj']=$this->subjectname_model->selectsubject();  


		$this->load->view('students',$data);
		
	}
	public function addstudent(){
		 $data['h']=$this->studentdetails_model->selectstudent();  

		$data['sj']=$this->subjectname_model->selectsubject();  
		$this->load->view("addstudent",$data);
	}
	public function students_update(){
			//load the database  savecoursetestreport
		$grabstuid = $this->input->get_post('studentids');

		         $this->load->database();  
		         //load the model  
		       //  $this->load->model('select');  
		         //load the method of model  
		        $data['h']=$this->studentdetails_model->selectstudentbyid($grabstuid);  

				$data['sj']=$this->subjectname_model->selectsubject();  


				$this->load->view('studentsupdate',$data);
	}
	public function student_details()
	{

		//image
		$changeenroll = $this->input->get_post('enrollmentno');

		$nameofimg = $changeenroll."_".$this->input->get_post('contactno');  
			$nameofimg = str_replace('/', '_', $nameofimg);
               
	
	  			$config['upload_path']          = './uploads/';
                $config['allowed_types']        = 'gif|jpg|png';
                //$config['max_size']             = 1000;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;
                $config['file_name']            = strtolower($nameofimg.$_FILES['photo']['name']);
                $nameofimg = strtolower($nameofimg.$_FILES['photo']['name']);	

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('photo'))
                {
                       // $error = array('error' => $this->upload->display_errors());

                        //$this->load->view('students', $error);
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());

                //        $this->load->view('students', $data);
                }
	
   //end of image	   
   				//$nameofimg = $this->input->get_post('enrollmentno')."_".$this->input->get_post('enrollmentno');  
               
				$enroll = $this->input->get_post('enrollmentno');
				$enrollmentno = $this->input->get_post('enrollmentno');
				$enrollmentno = str_replace('/', '_', $enrollmentno);

				$getboolan=	$this->studentdetails_model->student_valid($enroll);
				if($getboolan==TRUE)
				{
							echo "<script>alert('This Enrollment Id Is Already In Database')</script>";
				}
				elseif($getboolan==FALSE)
				{
							
					    $save = array(
		     	'name'  => $this->input->get_post('name'),
		     	'address'  => $this->input->get_post('address'),
		     	'contactno'  => $this->input->get_post('contactno'),
		     	'email'  => $this->input->get_post('email'),
		     	'enrollmentno'  => $enrollmentno,
		     	'photo'  => $nameofimg,
		     	'password'  => $this->input->get_post('password'),
		     	'date' =>$this->input->get_post('todaya'),
		     	'subjectid' => $this->input->get_post('allid'),

		    	);	

		         	
                 //$this->db->insert('table_image', $data); 
                  $this->studentdetails_model->savestudentdetails($save);
		//echo "Data updated successfully!!!";
				     echo "<script>alert('Data Saved successfully')</script>";
				}


		     
                  //echo "Data inserted successfully!!!";
 		      	//  echo '<script>window.location.href = "http://localhost/examcenter/index.php/Student";</script>';
 		      	
 		      	echo "<script>window.location.href='".base_url('index.php/Student')."'</script>";
 		      	
 		     
	
    }
    public function editstudent_name()
	{
		

			if($this->input->get_post("delete")=="Delete"){
				$id = $this->input->get_post('studentid');
				$enrollmentno = $this->input->get_post('enrollmentno');
				$enrollmentnoreport = $this->input->get_post('enrollmentno').'_report';
		
				$this->studentdetails_model->did_delete_row($id);
				//echo "<script>alert('".$id."')</script>";
				$this->studentdetails_model->droptable($enrollmentno);
				$this->studentdetails_model->droptable($enrollmentnoreport);
				echo "Data deleted sucessfully";
			}
			elseif($this->input->get_post("update")=="Update"){
				$changeenroll = $this->input->get_post('enrollmentno');
				//echo "<script>alert('".$this->input->get_post('photo')."')</script>";
				$myvar=$_FILES['photo']['name'];
				if($myvar==false){
					$nameofimg = $this->input->get_post('oldphoto');
				}
				else if($myvar!=false){	
				$nameofimg = $changeenroll."_".$this->input->get_post('contactno');  
				$nameofimg = str_replace('/', '_', $nameofimg);

				//$nameofimg = $this->input->get_post('enrollmentno')."_".$this->input->get_post('contactno');  
               
	
	  			$config['upload_path']          = './uploads/';
                $config['allowed_types']        = 'gif|jpg|png';
               // $config['max_size']             = 1000;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;
                $config['file_name']            = strtolower($nameofimg.$_FILES['photo']['name']);
                $nameofimg = strtolower($nameofimg.$_FILES['photo']['name']);	

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('photo'))
                {
                       // $error = array('error' => $this->upload->display_errors());

                        //$this->load->view('students', $error);
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());

                //        $this->load->view('students', $data);
                }



				}

				
		 $val1 = $this->input->get_post('name');
		 $val2 = $this->input->get_post('address');
		 $val3 = $this->input->get_post('contactno');
		 $val4 = $this->input->get_post('email');
		 $val5 = $this->input->get_post('enrollmentno');
		 $val6 = $this->input->get_post('todaya');
		 $val7 = $nameofimg;
		  $val9 = $this->input->get_post('subjectname');
		 
		 $id = $this->input->get_post('studentid');
		
		$this->studentdetails_model->updatestudent($id,$val1,$val2,$val3,$val4,$val5,$val6,$val7,$val9);
		echo "Data updated successfully!!!";
		}
     	//echo '<script>window.location.href = "http://localhost/examcenter/index.php/Student";</script>';
     	echo "<script>window.location.href='".base_url('index.php/Student')."'</script>";
      
	}




}
