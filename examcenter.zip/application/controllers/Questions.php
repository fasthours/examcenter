<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Questions extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		
		$data['h']=$this->subjectname_model->selectsubject(); 
		$data['k']=$this->testdetails_model->selecttest();
		$data['m']=$this->queans_model->selectquestion(); 
		$this->load->view('questionanswer',$data);
		
	}
	public function addquestion(){
		

		$data['h']=$this->subjectname_model->selectsubject(); 
		$data['k']=$this->testdetails_model->selecttest();
		$data['m']=$this->queans_model->selectquestion(); 
		$this->load->view('addquestionanswer',$data);
	

	}
	public function updatequestionanswer(){
		$data['m']=$this->queans_model->selectquestion(); 
		$data['h']=$this->subjectname_model->selectsubject(); 
		
			
				$data['s']=$this->queans_model->selectquestion1($this->input->get_post('mynewvalue')); 
			
			
		
		$data['k']=$this->testdetails_model->selecttest();
		
		$this->load->view('updatequestionanswer',$data);
	}
	public function editquestions()
	{

		if($this->input->get_post("delete")=="Delete"){
				$id = $this->input->get_post('questionid');
		
				$this->queans_model->did_delete_row($id);
				//echo "<script>alert('".$id."')</script>";
				echo "Data deleted sucessfully";			
			}
		elseif($this->input->get_post("update")=="Update"){

			 $val1 = $this->input->get_post('subjectid');
			  $val2 = $this->input->get_post('testid');
			  $val3 = $this->input->get_post('englishquestion');
			  $val4 = $this->input->get_post('engoption1');
			  $val5 = $this->input->get_post('engoption2');
			  $val6 = $this->input->get_post('engoption3');
			  $val7 = $this->input->get_post('engoption4');
			  $val8 = $this->input->get_post('engrightoption');
			  $val9 = $this->input->get_post('englishtrueans');
			  $val10 = $this->input->get_post('hindiquestion');
			  $val11 = $this->input->get_post('hindioption1');
			  $val12 = $this->input->get_post('hindioption2');
			  $val13 = $this->input->get_post('hindioption3');
			  $val14 = $this->input->get_post('hindioption4');
			  $val15 = $this->input->get_post('hindirightoption');
			  $val16 = $this->input->get_post('hinditrueans');
			  $val17 = $this->input->get_post('todaya');
			 $id = $this->input->get_post('questionid');
		
			$this->queans_model->updateque( $id , $val1 , $val2 , $val3, $val4 , $val5, $val6, $val7, $val8, $val9, $val10, $val11, $val12, $val13, $val14, $val15, $val16, $val17 );
			echo "Data updated successfully!!!";
		}
     	echo '<script>window.location.href = "http://localhost/examcenter/index.php/Questions";</script>';
      
	}
	public function questionanswer_details()
	{
     $save = array(
     	'subjectid '  => $this->input->get_post('subjectid'),
     	'testid '  => $this->input->get_post('testid'),
     	'englishquestion'  => $this->input->get_post('englishquestion'),
     	'engoption1'  => $this->input->get_post('engoption1'),
     	'engoption2'  => $this->input->get_post('engoption2'),
     	'engoption3'  => $this->input->get_post('engoption3'),
     	'engoption4'  => $this->input->get_post('engoption4'),
     	'hindiquestion'  => $this->input->get_post('hindiquestion'),
     	'hindioption1'  => $this->input->get_post('hindioption1'),
     	'hindioption2'  => $this->input->get_post('hindioption2'),
     	'hindioption3'  => $this->input->get_post('hindioption3'),
     	'hindioption4'  => $this->input->get_post('hindioption4'),
     	'hinditrueans'  => $this->input->get_post('hinditrueans'),
     	'englishtrueans'  => $this->input->get_post('englishtrueans'),
     	'engrightoption'  => $this->input->get_post('engrightoption'),
     	'hindirightoption'  => $this->input->get_post('hindirightoption'),
     	'data' =>$this->input->get_post('todaya'),
     	);


        $this->queans_model->savequeans($save);
     	echo "Data inserted successfully!!!";
     	echo '<script>window.location.href = "http://localhost/examcenter/index.php/Questions";</script>';
     
	}
	

}
