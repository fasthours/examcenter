<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.min.css");?>">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
  <style type="text/css">
  	h3{
  		border-radius: 1px;
  		color:white;
  		font-size:35px;
  	}
  	#defaultCountdown { width: 240px; height: 45px; }
  </style>
  <script src="<?php echo base_url("assets/js/jquery.plugin.min.js");?>"></script>
<script src="<?php echo base_url("assets/js/jquery.countdown.js");?>"></script>

</head>
<body>
<?php foreach ($h->result() as $row1) { ?>

<div class="container-fluid" style=" background-color: #92AE1A; padding: 5px;">
	<div class="col-xs-2"><img src="<?php echo base_url('uploads/'.$row1->photo ); ?>" width="80%"></div>
	<div class="col-xs-7">
				
				<div><h3>Student Name :-<?php  echo $row1->name; ?></h3></div>
				<div><h3>Enrollment No :-<?php  echo $row1->enrollmentno;  $enrollmentnoi = $row1->enrollmentno; ?> </h3></div>
				<input type="hidden" value="<?php echo $row1->enrollmentno; ?>" name="username1" id="username1">
			
				</div>
  <?php } ?>
	<div class="col-xs-3" style="color: white"><?php foreach($coursename->result() as $row3){ ?>
			<div><h4>Course Name : <?php echo $row3->subjectname; $courseidi=$row3->subjectid; ?></h4></div>
		<?php } ?>
		<?php foreach($testname->result() as $row5){ ?>
			<div><h4>Test Name : <?php echo $row5->testname; $duration = $row5->testduration;$testidi = $row5->testid; ?></h4></div>
		<?php } ?>
		<div id="worked" name="worked"><?php echo $duration; ?></div>
<script type="text/javascript">
$(document).ready(function (e) {
    var $worked = $("#worked");

    function update() {
        var myTime = $worked.html();
        var ss = myTime.split(":");
        var dt = new Date();
        dt.setHours(0);
        dt.setMinutes(ss[0]);
        dt.setSeconds(ss[1]);

        var dt2 = new Date(dt.valueOf() - 1000);
        var temp = dt2.toTimeString().split(" ");
        var ts = temp[0].split(":");

        $worked.html(ts[1]+":"+ts[2]);
        setTimeout(update, 1000);
        if(ts[1]=="00" && ts[2]=="00"){
        	alert("Your Time Is Shut, Page Is Going to Unload, Thank You.");
        	parent.document.location.href = "http://localhost/examcenter/index.php/Welcome/index1/<?php echo $testid;  ?>/<?php echo $courseidi; ?>/<?php echo $enrollmentnoi; ?>";
        }

    }

    setTimeout(update, 1000);
});
</script>
	</div>
</div>	
</body>
</html>