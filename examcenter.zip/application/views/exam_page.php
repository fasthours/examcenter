<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.min.css");?>">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
  <style type="text/css">
  	h3{
  		border-radius: 1px;
  		color:white;
  		font-size:35px;
  	}
  	#defaultCountdown { width: 240px; height: 45px; }
  </style>
  <script src="<?php echo base_url("assets/js/jquery.plugin.min.js");?>"></script>
<script src="<?php echo base_url("assets/js/jquery.countdown.js");?>"></script>

</head>
<body>


<form action="<?php echo base_url("index.php/Exam_page/getnext"); ?>" method="post">


<div class="container-fluid" style="height: 440px; background-color: white">
	<input type="hidden" name="enroll" id="enroll" value="<?php echo $enrollmentno; ?>">
	<div class="row">
		<div class="col-xs-2" style="background-color: lightgray;">
			<input type="hidden" value="" name="mygetid" id="mygetid">
			<?php
			$startvalue="";
			$stringsans="";
			$stuans="";
			$count=1;
			$stuanstrue="";
			$statustrue="";

			foreach ($ql->result() as $row2) {
				if($count==1){
				$startvalue= $row2->queansid;
			}
			foreach($t->result() as $rows){
				if($rows->queansid==$row2->queansid){
					//echo $rows->queansid;
				?>

					<button class='btn-success' type="submit" value="<?php echo $row2->queansid; ?>" name="myid<?php echo $count; ?>" id="myid<?php echo $count; ?>" onclick="document.getElementById('mygetid').value=document.getElementById('myid<?php echo $count; ?>').value;getvalue()" /><?php echo $count; ?></button>
			
			<!--<?php// echo $row2->queansid; ?>-->


				<?php
				}
				else{
					?>


					<button type="submit" value="<?php echo $row2->queansid; ?>" name="myid<?php echo $count; ?>" id="myid<?php echo $count; ?>" onclick="document.getElementById('mygetid').value=document.getElementById('myid<?php echo $count; ?>').value;getvalue()" /><?php echo $count; ?></button>
			
			<!--<?php echo $row2->queansid; ?>-->


					<?php
				}
			}
			?>
			
			<?php
			if($count==$endcount){
				$maxvalue= $row2->queansid;
			}
				$count++;}
			
			?>


		</div>
		
			<?php
			 foreach ($t->result() as $row){ 

			if($row->englishquestion==true && $row->hindiquestion==false){
				?><div class="col-xs-5">
					<h4>English Question</h4>
					<?php
							foreach ($getans->result() as $rowans) {

														 $questionid= $rowans->questionsid;
														 $courseid = $rowans->courseid;
														 $testid = $rowans->testid;

														if($row->queansid==$questionid && $courseid==$row->subjectid && $testid==$row->testid)
														{
															 $stringsans=$rowans->answer;
															 if($stringsans==$row->engoption1){
																$stuans =  $row->engoption1;
															 }
															 if($stringsans==$row->engoption2){
																$stuans =  $row->engoption2;
															}
															if($stringsans==$row->engoption3){
																$stuans =  $row->engoption3;
															}
															if($stringsans==$row->engoption4){
																$stuans =  $row->engoption4;
															}
															
																if($stringsans=="True"){
																  $statustrue="True";
																}
																if($stringsans=="False"){
																	$stuanstrue="False";
																}
															

														}
													   
														

							}
					?>
					<?php if($row->queansid == $maxvalue){
							//					echo "this is end";
						//echo "i am at last id";
						?>

									<script type="text/javascript">
										$(document).ready(function(){
										$(".hideshow").show();
										$("#next").hide();
									});
									</script>

									<input type="hidden" value="<?php echo $row->queansid; ?>" name="previousid" id="previousid">
									<input type="hidden" value="" name="username" id="username">
								<div class="content"><h4><B>Question :<?php  echo $row->englishquestion; ?></B></h4> </div>
								<div class="content"><h4>Answers: <BR><?php if($row->engoption1==false && $row->engoption2==false && $row->engoption3==false && $row->engoption4==false) 
						                                              { //echo $stuanstrue; ?><br>                                              
														       		  <input type='radio' id="englishtrueans1" name="englishtrueans" value="True" <?php if($stuanstrue=="True"){echo "checked='checked'";} ?> onclick="selectone()">True<BR>
						                                              <input type='radio' id="englishtrueans2" name="englishtrueans" value="False" <?php if($stuanstrue=="False"){echo "checked='checked'";} ?> onclick="selectone()">False<BR>
						                                               <?php } 
						                                               else { 

						                                               	?><br>
						                                            
						                                              <input type='radio' id="engoption1" name="engoption" value="<?php echo $row->engoption1; ?>" <?php if($stuans==$row->engoption1){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption1; ?><BR>
						                                              <input type='radio' id="engoption2" name="engoption" value="<?php echo $row->engoption2; ?>" <?php if($stuans==$row->engoption2){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption2; ?><BR>
						                                              <input type='radio' id="engoption3" name="engoption" value="<?php echo $row->engoption3; ?>" <?php if($stuans==$row->engoption3){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption3; ?><BR>
						                                              <input type='radio' id="engoption4" name="engoption" value="<?php echo $row->engoption4; ?>" <?php if($stuans==$row->engoption4){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption4; ?><BR>                                                           
						                                              <?php }  ?></h4>  
						        </div>

						<?php
				}else if($row->queansid == $startvalue){

					?>

					<script type="text/javascript">
							$(document).ready(function(){
							//	alert('working');
							$("#previous").hide();
							$(".hideshow").hide();
							//$("#previous").hide();


							});
					</script>
					<input type="hidden" value="<?php echo $row->queansid; ?>" name="previousid" id="previousid">
			<input type="hidden" value="" name="username" id="username">
		<div class="content"><h4><B>Question :<?php  echo $row->englishquestion; ?></B></h4> </div>
		<div class="content"><h4>Answers: <BR><?php if($row->engoption1==false && $row->engoption2==false && $row->engoption3==false && $row->engoption4==false) 
                                              {  $statustrue=$row->englishtrueans; ?><br>
                                         	  <input type='radio' id="englishtrueans1" name="englishtrueans" value="True" <?php if($stuanstrue=="True"){echo "checked='checked'";} ?> onclick="selectone()">True<BR>
                                              <input type='radio' id="englishtrueans2" name="englishtrueans" value="False" <?php if($stuanstrue=="False"){echo "checked='checked'";} ?> onclick="selectone()">False<BR>
                                               <?php } 
                                               else { ?><br>
                                              

                                               
                                              <input type='radio' id="engoption1" name="engoption" value="<?php echo $row->engoption1; ?>" <?php if($stuans==$row->engoption1){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption1; ?><BR>
                                              <input type='radio' id="engoption2" name="engoption" value="<?php echo $row->engoption2; ?>" <?php if($stuans==$row->engoption2){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption2; ?><BR>
                                              <input type='radio' id="engoption3" name="engoption" value="<?php echo $row->engoption3; ?>" <?php if($stuans==$row->engoption3){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption3; ?><BR>
                                              <input type='radio' id="engoption4" name="engoption" value="<?php echo $row->engoption4; ?>" <?php if($stuans==$row->engoption4){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption4; ?><BR>                                                           
                                              <?php }  ?></h4>  
        </div>
					<?php
				}
				else{ ?>
				<script type="text/javascript">
					$(document).ready(function(){
					//	alert('working');
					$(".hideshow").hide();
					//$("#previous").hide();


				});
			</script>
			<input type="hidden" value="<?php echo $row->queansid; ?>" name="previousid" id="previousid">
			<input type="hidden" value="" name="username" id="username">
		<div class="content"><h4><B>Question :<?php  echo $row->englishquestion; ?></B></h4> </div>
		<div class="content"><h4>Answers: <BR><?php if($row->engoption1==false && $row->engoption2==false && $row->engoption3==false && $row->engoption4==false) 
                                              {  ?><br>
                                              
                                         	  <input type='radio' id="englishtrueans1" name="englishtrueans" value="True" <?php if($stuanstrue=="True"){echo "checked='checked'";} ?> onclick="selectone()">True<BR>
                                              <input type='radio' id="englishtrueans2" name="englishtrueans" value="True" <?php if($stuanstrue=="False"){echo "checked='checked'";} ?> onclick="selectone()">False<BR>
                                               <?php } 
                                               else { ?><br>
                                              <input type='radio' id="engoption1" name="engoption" value="<?php echo $row->engoption1; ?>" <?php if($stuans==$row->engoption1){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption1; ?><BR>
                                              <input type='radio' id="engoption2" name="engoption" value="<?php echo $row->engoption2; ?>" <?php if($stuans==$row->engoption2){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption2; ?><BR>
                                              <input type='radio' id="engoption3" name="engoption" value="<?php echo $row->engoption3; ?>" <?php if($stuans==$row->engoption3){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption3; ?><BR>
                                              <input type='radio' id="engoption4" name="engoption" value="<?php echo $row->engoption4; ?>" <?php if($stuans==$row->engoption4){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption4; ?><BR>                                                           
                                              <?php }  ?></h4>  
        </div>
		<?php } 
				?>

					</div><!-- end of only english questions -->
				<?php
				}
			
			if($row->englishquestion==false && $row->hindiquestion==true){
				?><div class="col-xs-5">
					<h4>Hindi Question</h4>
<?php
							foreach ($getans->result() as $rowans) {

														$questionid= $rowans->questionsid;
														$courseid = $rowans->courseid;
														$testid = $rowans->testid;

														if($row->queansid==$questionid && $courseid==$row->subjectid && $testid==$row->testid)
														{
															 $stringsans=$rowans->answer;
															 if($stringsans==$row->hindioption1){
																$stuans =  $row->hindioption1;
															 }
															 if($stringsans==$row->hindioption2){
																$stuans =  $row->hindioption2;
															}
															if($stringsans==$row->hindioption3){
																$stuans =  $row->hindioption3;
															}
															if($stringsans==$row->hindioption4){
																$stuans =  $row->hindioption4;
															}
															
																//echo $stringsans;
																if($stringsans=="True"){
																 $statustrue="True";
																}
																elseif($stringsans=="False"){
																	$stuanstrue="False";
																}
															

														}
													   
														

							}
					?>
					<?php if($row->queansid == $maxvalue){
							//					echo "this is end";

						?>

									<script type="text/javascript">
										$(document).ready(function(){
										$(".hideshow").show();
										$("#next").hide();
									});
									</script>

									<input type="hidden" value="<?php echo $row->queansid; ?>" name="previousid" id="previousid">
									<input type="hidden" value="" name="username" id="username">
								<div class="content"><h4><B>Question :<?php  echo $row->hindiquestion; ?></B></h4> </div>
								<div class="content"><h4>Answers: <BR><?php if($row->hindioption1==false && $row->hindioption2==false && $row->hindioption3==false && $row->hindioption4==false) 
						                                              {  ?><br>                                              
														       		  <input type='radio' id="hinditrueans1" name="hinditrueans" value="True" <?php if($statustrue=="True"){echo "checked='checked'";} ?> onclick="selectone()">True<BR>
						                                              <input type='radio' id="hinditrueans2" name="hinditrueans" value="False" <?php if($statustrue=="False"){echo "checked='checked'";} ?> onclick="selectone()">False<BR>
						                                               <?php } 
						                                               else { 

						                                               	?><br>
						                                            
						                                              <input type='radio' id="hindioption1" name="hindioption" value="<?php echo $row->hindioption1; ?>" <?php if($stuans==$row->hindioption1){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->hindioption1; ?><BR>
						                                              <input type='radio' id="hindioption2" name="hindioption" value="<?php echo $row->hindioption2; ?>" <?php if($stuans==$row->hindioption2){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->hindioption2; ?><BR>
						                                              <input type='radio' id="hindioption3" name="hindioption" value="<?php echo $row->hindioption3; ?>" <?php if($stuans==$row->hindioption3){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->hindioption3; ?><BR>
						                                              <input type='radio' id="hindioption4" name="hindioption" value="<?php echo $row->hindioption4; ?>" <?php if($stuans==$row->hindioption4){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->hindioption4; ?><BR>                                                           
						                                              <?php }  ?></h4>  
						        </div>

						<?php
				}else if($row->queansid == $startvalue){

					?>

					<script type="text/javascript">
							$(document).ready(function(){
							//	alert('working');
							$("#previous").hide();
							$(".hideshow").hide();
							//$("#previous").hide();


							});
					</script>
					<input type="hidden" value="<?php echo $row->queansid; ?>" name="previousid" id="previousid">
			<input type="hidden" value="" name="username" id="username">
		<div class="content"><h4><B>Question :<?php  echo $row->hindiquestion; ?></B></h4> </div>
		<div class="content"><h4>Answers: <BR><?php if($row->hindioption1==false && $row->hindioption2==false && $row->hindioption3==false && $row->hindioption4==false) 
                                              {  ?><br>
                                         	  <input type='radio' id="hinditrueans1" name="hinditrueans" value="True" <?php if($statustrue=="True"){echo "checked='checked'";} ?> onclick="selectone()">True<BR>
                                              <input type='radio' id="hinditrueans2" name="hinditrueans" value="False" <?php if($statustrue=="False"){echo "checked='checked'";} ?> onclick="selectone()">False<BR>
                                               <?php } 
                                               else { ?><br>
                                              

                                               
                                              <input type='radio' id="hindioption1" name="hindioption" value="<?php echo $row->hindioption1; ?>" <?php if($stuans==$row->engoption1){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->hindioption1; ?><BR>
                                              <input type='radio' id="hindioption2" name="hindioption" value="<?php echo $row->hindioption2; ?>" <?php if($stuans==$row->engoption2){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->hindioption2; ?><BR>
                                              <input type='radio' id="hindioption3" name="hindioption" value="<?php echo $row->hindioption3; ?>" <?php if($stuans==$row->engoption3){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->hindioption3; ?><BR>
                                              <input type='radio' id="hindioption4" name="hindioption" value="<?php echo $row->hindioption4; ?>" <?php if($stuans==$row->engoption4){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->hindioption4; ?><BR>                                                           
                                              <?php }  ?></h4>  
        </div>
					<?php
				}
				else{ ?>
				<script type="text/javascript">
					$(document).ready(function(){
					//	alert('working');
					$(".hideshow").hide();
					//$("#previous").hide();


				});
			</script>
			<input type="hidden" value="<?php echo $row->queansid; ?>" name="previousid" id="previousid">
			<input type="hidden" value="" name="username" id="username">
		<div class="content"><h4><B>Question :<?php  echo $row->hindiquestion; ?></B></h4> </div>
		<div class="content"><h4>Answers: <BR><?php if($row->hindioption1==false && $row->hindioption2==false && $row->hindioption3==false && $row->hindioption4==false) 
                                              {  ?><br>
                                              
                                         	  <input type='radio' id="hinditrueans1" name="hinditrueans" value="True" <?php if($statustrue=="True"){echo "checked='checked'";} ?> onclick="selectone()">True<BR>
                                              <input type='radio' id="hinditrueans2" name="hinditrueans" value="True" <?php if($stuanstrue=="False"){echo "checked='checked'";} ?> onclick="selectone()">False<BR>
                                               <?php } 
                                               else { ?><br>
                                              <input type='radio' id="hindioption1" name="hindioption" value="<?php echo $row->hindioption1; ?>" <?php if($stuans==$row->hindioption1){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->hindioption1; ?><BR>
                                              <input type='radio' id="hindioption2" name="hindioption" value="<?php echo $row->hindioption2; ?>" <?php if($stuans==$row->hindioption2){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->hindioption2; ?><BR>
                                              <input type='radio' id="hindioption3" name="hindioption" value="<?php echo $row->hindioption3; ?>" <?php if($stuans==$row->hindioption3){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->hindioption3; ?><BR>
                                              <input type='radio' id="hindioption4" name="hindioption" value="<?php echo $row->engoption4; ?>" <?php if($stuans==$row->hindioption4){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->hindioption4; ?><BR>                                                           
                                              <?php }  ?></h4>  
        </div>
		<?php } 
				?>

					</div><!-- enf of only hindi questions -->
				<?php
				}

			if($row->englishquestion==true && $row->hindiquestion==true){
				?><div class="col-xs-5">
					<h4>English Question</h4>
					<?php
							foreach ($getans->result() as $rowans) {

														 $questionid= $rowans->questionsid;
														 $courseid = $rowans->courseid;
														 $testid = $rowans->testid;

														if($row->queansid==$questionid && $courseid==$row->subjectid && $testid==$row->testid)
														{
															 $stringsans=$rowans->answer;
															 if($stringsans==$row->engoption1){
																$stuans =  $row->engoption1;
															 }
															 if($stringsans==$row->engoption2){
																$stuans =  $row->engoption2;
															}
															if($stringsans==$row->engoption3){
																$stuans =  $row->engoption3;
															}
															if($stringsans==$row->engoption4){
																$stuans =  $row->engoption4;
															}
															
																if($stringsans=="True"){
																  $statustrue="True";
																}
																if($stringsans=="False"){
																	$stuanstrue="False";
																}
															

														}
													   
														

							}
					?>
					<?php if($row->queansid == $maxvalue){
							//					echo "this is end";
						//echo "i am at last id";
						?>

									<script type="text/javascript">
										$(document).ready(function(){
										$(".hideshow").show();
										$("#next").hide();
									});
									</script>

									<input type="hidden" value="<?php echo $row->queansid; ?>" name="previousid" id="previousid">
									<input type="hidden" value="" name="username" id="username">
								<div class="content"><h4><B>Question :<?php  echo $row->englishquestion; ?></B></h4> </div>
								<div class="content"><h4>Answers: <BR><?php if($row->engoption1==false && $row->engoption2==false && $row->engoption3==false && $row->engoption4==false) 
						                                              { //echo $stuanstrue; ?><br>                                              
														       		  <input type='radio' id="englishtrueans1" name="englishtrueans" value="True" <?php if($stuanstrue=="True"){echo "checked='checked'";} ?> onclick="selectone()">True<BR>
						                                              <input type='radio' id="englishtrueans2" name="englishtrueans" value="False" <?php if($stuanstrue=="False"){echo "checked='checked'";} ?> onclick="selectone()">False<BR>
						                                               <?php } 
						                                               else { 

						                                               	?><br>
						                                            
						                                              <input type='radio' id="engoption1" name="engoption" value="<?php echo $row->engoption1; ?>" <?php if($stuans==$row->engoption1){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption1; ?><BR>
						                                              <input type='radio' id="engoption2" name="engoption" value="<?php echo $row->engoption2; ?>" <?php if($stuans==$row->engoption2){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption2; ?><BR>
						                                              <input type='radio' id="engoption3" name="engoption" value="<?php echo $row->engoption3; ?>" <?php if($stuans==$row->engoption3){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption3; ?><BR>
						                                              <input type='radio' id="engoption4" name="engoption" value="<?php echo $row->engoption4; ?>" <?php if($stuans==$row->engoption4){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption4; ?><BR>                                                           
						                                              <?php }  ?></h4>  
						        </div>

						<?php
				}else if($row->queansid == $startvalue){

					?>

					<script type="text/javascript">
							$(document).ready(function(){
							//	alert('working');
							$("#previous").hide();
							$(".hideshow").hide();
							//$("#previous").hide();


							});
					</script>
					<input type="hidden" value="<?php echo $row->queansid; ?>" name="previousid" id="previousid">
			<input type="hidden" value="" name="username" id="username">
		<div class="content"><h4><B>Question :<?php  echo $row->englishquestion; ?></B></h4> </div>
		<div class="content"><h4>Answers: <BR><?php if($row->engoption1==false && $row->engoption2==false && $row->engoption3==false && $row->engoption4==false) 
                                              {  $statustrue=$row->englishtrueans; ?><br>
                                         	  <input type='radio' id="englishtrueans1" name="englishtrueans" value="True" <?php if($stuanstrue=="True"){echo "checked='checked'";} ?> onclick="selectone()">True<BR>
                                              <input type='radio' id="englishtrueans2" name="englishtrueans" value="False" <?php if($stuanstrue=="False"){echo "checked='checked'";} ?> onclick="selectone()">False<BR>
                                               <?php } 
                                               else { ?><br>
                                              

                                               
                                              <input type='radio' id="engoption1" name="engoption" value="<?php echo $row->engoption1; ?>" <?php if($stuans==$row->engoption1){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption1; ?><BR>
                                              <input type='radio' id="engoption2" name="engoption" value="<?php echo $row->engoption2; ?>" <?php if($stuans==$row->engoption2){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption2; ?><BR>
                                              <input type='radio' id="engoption3" name="engoption" value="<?php echo $row->engoption3; ?>" <?php if($stuans==$row->engoption3){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption3; ?><BR>
                                              <input type='radio' id="engoption4" name="engoption" value="<?php echo $row->engoption4; ?>" <?php if($stuans==$row->engoption4){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption4; ?><BR>                                                           
                                              <?php }  ?></h4>  
        </div>
					<?php
				}
				else{ ?>
				<script type="text/javascript">
					$(document).ready(function(){
					//	alert('working');
					$(".hideshow").hide();
					//$("#previous").hide();


				});
			</script>
			<input type="hidden" value="<?php echo $row->queansid; ?>" name="previousid" id="previousid">
			<input type="hidden" value="" name="username" id="username">
		<div class="content"><h4><B>Question :<?php  echo $row->englishquestion; ?></B></h4> </div>
		<div class="content"><h4>Answers: <BR><?php if($row->engoption1==false && $row->engoption2==false && $row->engoption3==false && $row->engoption4==false) 
                                              {  ?><br>
                                              
                                         	  <input type='radio' id="englishtrueans1" name="englishtrueans" value="True" <?php if($stuanstrue=="True"){echo "checked='checked'";} ?> onclick="selectone()">True<BR>
                                              <input type='radio' id="englishtrueans2" name="englishtrueans" value="True" <?php if($stuanstrue=="False"){echo "checked='checked'";} ?> onclick="selectone()">False<BR>
                                               <?php } 
                                               else { ?><br>
                                              <input type='radio' id="engoption1" name="engoption" value="<?php echo $row->engoption1; ?>" <?php if($stuans==$row->engoption1){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption1; ?><BR>
                                              <input type='radio' id="engoption2" name="engoption" value="<?php echo $row->engoption2; ?>" <?php if($stuans==$row->engoption2){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption2; ?><BR>
                                              <input type='radio' id="engoption3" name="engoption" value="<?php echo $row->engoption3; ?>" <?php if($stuans==$row->engoption3){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption3; ?><BR>
                                              <input type='radio' id="engoption4" name="engoption" value="<?php echo $row->engoption4; ?>" <?php if($stuans==$row->engoption4){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption4; ?><BR>                                                           
                                              <?php }  ?></h4>  
        </div>
		<?php } 
				?>
					<!-- ending english first half -->
					</div>
						<script type="text/javascript">

		    function selectone(){
					if(document.getElementById('englishtrueans1').checked==true){
						document.getElementById('hinditrueans1').checked=true;
					}
					if(document.getElementById('englishtrueans2').checked==true){
						document.getElementById('hinditrueans2').checked=true;
					}
		    }
		    function selecttwo(){
		    		if(document.getElementById('hinditrueans1').checked==true){
						document.getElementById('englishtrueans1').checked=true;
					}
					if(document.getElementById('hinditrueans2').checked==true){
						document.getElementById('englishtrueans2').checked=true;
					}
					
		    }


			function selectcopyeng(){


					
					

					if(document.getElementById('engoption1').checked==true){
						document.getElementById('hindioption1').checked=true;
					}

					if(document.getElementById('engoption2').checked==true){
						document.getElementById('hindioption2').checked=true;
					}

					if(document.getElementById('engoption3').checked==true){
						document.getElementById('hindioption3').checked=true;
					}

					if(document.getElementById('engoption4').checked==true){
						document.getElementById('hindioption4').checked=true;
					}
			}

			function selectcopy(){
				
						

					
				

					if(document.getElementById('hindioption1').checked==true){
						document.getElementById('engoption1').checked=true;
					}

					if(document.getElementById('hindioption2').checked==true){
						document.getElementById('engoption2').checked=true;
					}

					if(document.getElementById('hindioption3').checked==true){
						document.getElementById('engoption3').checked=true;
					}

					if(document.getElementById('hindioption4').checked==true){
						document.getElementById('engoption4').checked=true;
					}

					

					

					

				
			}
		</script>


					<div class="col-xs-5">
					<h4>Hindi Question</h4>

					<?php
						foreach ($getans->result() as $rowans) {

														$questionid= $rowans->questionsid;
														$courseid = $rowans->courseid;
														$testid = $rowans->testid;

														if($row->queansid==$questionid && $courseid==$row->subjectid && $testid==$row->testid)
														{
															 $stringsans=$rowans->answer;
															 if($stringsans==$row->hindioption1){
																$stuans =  $row->hindioption1;
															 }
															 if($stringsans==$row->hindioption2){
																$stuans =  $row->hindioption2;
															}
															if($stringsans==$row->hindioption3){
																$stuans =  $row->hindioption3;
															}
															if($stringsans==$row->hindioption4){
																$stuans =  $row->hindioption4;
															}
															
																//echo $stringsans;
																if($stringsans=="True"){
																 $statustrue="True";
																}
																elseif($stringsans=="False"){
																	$stuanstrue="False";
																}
															

														}
													   
														

							}
					?>
					<div class="content"><h4><B>Question: <?php  echo $row->hindiquestion; ?></B></h4> </div> 
		<div class="content"><h4>Answers:<BR><?php if($row->hindioption1==false && $row->hindioption2==false && $row->hindioption3==false && $row->hindioption4==false) 
                                              { ?><br>
                                              <input type='radio' id="hinditrueans1" name="hinditrueans" value="True" <?php if($stuanstrue=="True"){echo "checked='checked'"; } ?> onclick="selecttwo()">True<BR>
                                              <input type='radio' id="hinditrueans2" name="hinditrueans" value="False" <?php if($stuanstrue=="False"){echo "checked='checked'"; } ?> onclick="selecttwo()">False<BR>
                                               <?php } 
                                               else { echo $stuans; ?><br>
                                              <input type='radio' id="hindioption1" name="hindioption" value="<?php echo $row->hindioption1; ?>" <?php if($stuans==$row->hindioption1){echo "checked='checked'";} ?> onclick="selectcopy()"><?php echo $row->hindioption1; ?><BR>
                                              <input type='radio' id="hindioption2" name="hindioption" value="<?php echo $row->hindioption2; ?>" <?php if($stuans==$row->hindioption2){echo "checked='checked'";} ?> onclick="selectcopy()"><?php echo $row->hindioption2; ?><BR>
                                              <input type='radio' id="hindioption3" name="hindioption" value="<?php echo $row->hindioption3; ?>" <?php if($stuans==$row->hindioption3){echo "checked='checked'";} ?> onclick="selectcopy()"><?php echo $row->hindioption3; ?><BR>
                                              <input type='radio' id="hindioption4" name="hindioption" value="<?php echo $row->hindioption4; ?>" <?php if($stuans==$row->hindioption4){echo "checked='checked'";} ?> onclick="selectcopy()"><?php echo $row->hindioption4; ?><BR>
                                              <?php }   ?> </h4></div>
					<!-- ending hindi second half -->
					</div>
				<?php
				}
			}
				 ?>
		
		
		
	</div>
</div>
<div class="container-fluid" style="height: 70px; background-color: #4D4D4D">
	<div class="col-xs-4"></div>
	<div class="col-xs-4"></div>
	<?php echo "<input type='hidden' value='".$courseid."' name='courseid' id='courseid'/>"; ?>
	<?php echo "<input type='hidden' value='".$testid."' name='testid' id='testid'/>"; ?>

	<div class="col-xs-4"><input class="btn btn-success" type="submit" value="previous" name="previous" id="previous" onclick="getvalue()">&nbsp;<input class="btn btn-success" value="next" type="submit" name="next" id="next" onclick="getvalue()">&nbsp;<input type="submit" class="btn btn-danger hideshow" value="Finish" name="submittest" id="submittest" style="margin-left:30%"></div>
	<script type="text/javascript">
		function getvalue(){
			document.getElementById('username').value = document.getElementById('username1').value ;
		}
	</script>
</div>
</form>
</body>
</html>