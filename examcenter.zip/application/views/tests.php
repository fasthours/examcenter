<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ExamCenter</title>
    <!-- Bootstrap Styles-->
    <link href="<?php echo base_url('adminasset/css/bootstrap.css'); ?>" rel="stylesheet" />
    <!-- FontAwesome Styles-->
    <link href="<?php echo base_url('adminasset/css/font-awesome.css'); ?>" rel="stylesheet" />
    <!-- Morris Chart Styles-->
    <link href="<?php echo base_url('adminasset/js/morris/morris-0.4.3.min.css');?> " rel="stylesheet" />
    <!-- Custom Styles-->
    <link href="<?php echo base_url('adminasset/css/custom-styles.css');?>" rel="stylesheet" />
    <!-- Google Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

      
</head>
<style type="text/css">
    .css-serial {
 counter-reset: serial-number; /* Set the serial number counter to 0 */
}
.css-serial td:first-child:before {
 counter-increment: serial-number; /* Increment the serial number counter */
 content: counter(serial-number); /* Display the counter */
}
</style>
<body>
    <div id="wrapper">
        <?php $this->load->view('uppermenu.php'); ?>
        <!--/. NAV TOP  -->
        <?php  $this->load->view('sidemenu.php'); ?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">


                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Test <small>Enter Test Details</small>
                        </h1>
                    </div>
                </div>
                <!-- /. ROW  -->

                <div class="row">
                 <form role="form" action="<?php echo site_url('Test/test_details'); ?>" method="post">
                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Test Name *</label>
                                            <input class="form-control" name="testname" id="testname" required="required">         

                                        </div>
                                        <div class="form-group">
                                            <label>Course Name *</label>
                                            <select class="form-control" id="subjectname" name="subjectname" required="required">
                                                <?php
                                                foreach ($h-> result() as $row) {

                                                                     ?> 
                                                                     
                                                                     <option value="<?php echo $row->subjectid; ?>"><?php echo $row->subjectname; ?></option>



                                                                     <?php } 
                                                ?>                                               
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Total Question *</label>
                                            <input class="form-control" name="totalquestion" id="totalquestion" required="required">         

                                        </div>
                                        <div class="form-group">
                                            <label>Total Marks *</label>
                                            <input class="form-control" name="totalmarks" id="totalmarks" required="required">         

                                        </div>

                                        <div class="form-group">
                                           <label>Test&nbsp;*&nbsp;</label>&nbsp;&nbsp;
                                           <input type="radio" name="optionradio" id="optionradio" value="On" checked="checked">&nbsp;ON&nbsp;&nbsp;
                                           <input type="radio" name="optionradio" id="optionradio" value="Off" checked="checked">&nbsp;OFF                              
                                        </div>
                                        <div class="form-group">
                                           <label>Test Duration</label>
                                            <select name="tduration" id="tduration">
                                                <option value="30:00">Half Hours</option>
                                                <option value="60:00">One Hours</option>
                                            </select>                              
                                        </div>
                                        
                                        <input type="hidden" name="todaya" id="todaya" value="<?php echo date('Y/m/d H:i:s'); ?>">
                                        <button type="submit" class="btn btn-default" name="submit" id="submit" value="submit">Submit Button</button>
                                        <button type="reset" class="btn btn-default">Reset Button</button>
                    </div> 
                    </form>
                     <form role="form" action="<?php echo site_url('Test/test_details'); ?>" method="post">
                    <div class="col-lg-6">
                        <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Advanced Tables
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover css-serial" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>No</th>                                            
                                            <th>Test Detials</th>
                                                   
                                            <th>Edit / Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php  
                                        $count=1;
                                        foreach ($k->result() as $row) 
                                        { 

                                        ?>
                                        <tr class="odd gradeX">
                                            <td><input type="hidden" value="<?php echo $row->testid; ?>" id="testid<?php echo $count; ?>" name="testid<?php echo $count; ?>">
                                                <input type="hidden" value="<?php echo $row->testdate; ?>" id="testdate<?php echo $count; ?>" name="testdate<?php echo $count; ?>">
                                                <input type="hidden" value="<?php echo $row->testtime; ?>" id="testtime<?php echo $count; ?>" name="testtime<?php echo $count; ?>">
                                                                                                
                                             </td>

                                            <td>Subject :- <input type="text" value="<?php echo $row->subjectname; ?>" id="subjectname<?php echo $count; ?>" name="subjectname<?php echo $count; ?>" readonly="readonly" style="border:none;"><BR>

                                            Unit :-  <input type="text" value="<?php echo $row->testname; ?>" id="testname<?php echo $count; ?>" name="testname<?php echo $count; ?>" readonly="readonly" style="border:none;"> <BR>

                                            Total-Marks :- <input type="text" value="<?php echo $row->totalmarks; ?>" id="totalmarks<?php echo $count; ?>" name="totalmarks<?php echo $count; ?>" readonly="readonly" style="border:none;"> <BR>

                                            Total-question :- <input type="text" value="<?php echo $row->totalquestion; ?>" id="totalquestion<?php echo $count; ?>" name="totalquestion<?php echo $count; ?>" readonly="readonly" style="border:none;"></td>             
                                                                 
                                            <td class="center"><input type="submit" value="update" class="btn btn-info btn-sm"  name="update" id="update" 
                                                onclick="document.getElementById('testidmodel').value=document.getElementById('testid<?php echo $count; ?>').value;"></td>
                                        </tr>
                                         <?php $count++; } ?>  
                                         <input type="text" value="" name="testidmodel" id="testidmodel">
                                         
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                    </div>                   
                  </form> 


               


                 </div>
                 <!-- /.Row -->
                <!-- /. ROW  -->
                <footer><p>All right reserved. Template by: <a href="http://webthemez.com">WebThemez</a></p></footer>
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="<?php echo base_url('adminasset/js/jquery-1.10.2.js'); ?>"></script>
    <!-- Bootstrap Js -->
    <script src="<?php echo base_url('adminasset/js/bootstrap.min.js'); ?>"></script>
    <!-- Metis Menu Js -->
    <script src="<?php echo base_url('adminasset/js/jquery.metisMenu.js'); ?>"></script>
    <!-- Morris Chart Js -->
    <script src="<?php echo base_url('adminasset/js/morris/raphael-2.1.0.min.js'); ?>"></script>
    <script src="<?php echo base_url('adminasset/js/morris/morris.js'); ?>"></script>
    <script src="<?php echo base_url('adminasset/js/jquery.metisMenu.js');?>"></script>
    <script src="<?php echo base_url('adminasset/js/dataTables/jquery.dataTables.js');?>"></script>
    <script src="<?php echo base_url('adminasset/js/dataTables/dataTables.bootstrap.js') ?>"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
    <!-- Custom Js -->
    <script src="<?php echo base_url('adminasset/js/custom-scripts.js'); ?>"></script>


</body>

</html>