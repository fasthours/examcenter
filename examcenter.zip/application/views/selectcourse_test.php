<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.min.css");?>">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
  <style type="text/css">
  	h3{
  		border-radius: 1px;
  		color:white;
  		font-size:35px;
  	}
  </style>
   <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){
     // alert("working");
      $('#subjectid').on('change',function(){
        var subjectID = $(this).val();
        if(subjectID){
            $.ajax({              
                type:'POST',
                url:'http://localhost/examcenter/index.php/Selectcourse_test/gettest',
                data:'subject_id='+subjectID,
                success:function(html){
                  
                    $('#testid').html(html);
                   // $('#city').html('<option value="">Select state first</option>'); 
                }
            }); 
        }else{
            $('#testid').html('<option value="">Select Course</option>');
           // $('#city').html('<option value="">Select state first</option>'); 
        }
    });
    });
  </script>
</head>
<body>
<form action="<?php echo base_url("index.php/Selectcourse_test/savecourstest"); ?>" method="post">
  <?php foreach ($h->result() as $row) { ?>
<div class="container-fluid" style=" background-color: #92AE1A; padding: 5px;">
	<div class="col-xs-2"><img src="<?php echo base_url('uploads/'.$row->photo ); ?>" width="80%"></div>
	<div class="col-xs-8">

			
				<div><h3>Student Name :-<?php  echo $row->name; ?></h3></div>
				<div><h3>Enrollment No :-<?php  $enrolldisplay= $row->enrollmentno;
                                                $enrolldisplay = str_replace("_", "/", $enrolldisplay);
                                                echo $enrolldisplay; ?> </h3></div>
				<input type="hidden" value="<?php echo $row->enrollmentno; ?>" name="enrollmentno" id="enrollmentno">
				<?php } ?>
				</div>
	<div class="col-xs-2"></div>
</div>	


<div class="container-fluid" style="height: 200px; background-color: grey">

	<div class="row">
	
	<div class="col-xs-5">
		<div class="form-group">
		<label>Course Name *</label>
        <select class="form-control" id="subjectid" name="subjectid" required="required">
           <option selected="selected" value="select">Please Select subject</option>
            <?php
            foreach ($coursename-> result() as $row1) {
            ?> 
            <option value="<?php echo $row1->subjectid; ?>"><?php echo $row1->subjectname; ?></option>
            <?php } ?>                                               
        </select>
        </div>
    </div>

    <div class="col-xs-5">
        <div class="form-group">
        <label>Test Name *</label>
        <select class="form-control" name="testid" id="testid">
        <option selected="selected" value="select">Please Select Test</option>
        <?php  
                foreach ($testname->result() as $row2)  
                {  
        ?>
        <option value="<?php echo $row2->testid; ?>"><?php echo $row2->testname; ?></option>
        <?php
                }
        ?>  
        </select>
        </div>
   	</div>  
    <div class="col-xs-2"><br>
      
      <div class="form-group"> 
      <label>Navigate</label>                                 
        <button class="btn btn-success">Submit</button>
        </div>
    </div>   
    </div>

      

</div>

</form>
</body>
</html>