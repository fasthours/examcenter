<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?>
<?php $enrollmentno = $username;
      ?>
				
<iframe src="<?php echo base_url('index.php/Exam_page/exam_pageup/'.$enrollmentno.'/'.$courseid.'/'.$testid); ?>" width="100%" height="150px" scrolling="no" frameborder="0"></iframe>
<iframe src="<?php echo base_url('index.php/Exam_page/index/'.$enrollmentno.'/'.$courseid.'/'.$testid); ?>" width="100%" height="480px" frameborder="0"></iframe>

</html>