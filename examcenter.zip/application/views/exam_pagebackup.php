<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style type="text/css">
  	/* make sidebar nav vertical */ 
@media (min-width: 768px) {
  .sidebar-nav .navbar .navbar-collapse {
    padding: 0;
    max-height: none;
  }
  .sidebar-nav .navbar ul {
    float: none;
    display: block;
  }
  .sidebar-nav .navbar li {
    float: none;
    display: block;
  }
  .sidebar-nav .navbar li a {
    padding-top: 12px;
    padding-bottom: 12px;
  }
}
  </style>
</head>
<body>
<div class="container">
	<div class="col-lg-12" style="border-bottom: 2px red solid;  padding-top: 10px ">
		<div class="col-lg-2">
			<img src="<?php echo base_url("assets/images/student1.jpg"); ?>" alt="student photograph" width="100" height="100">
		</div>
		<div class="col-lg-7" style="border-left: 2px red solid; border-right: 2px red solid">
			<?php foreach ($h->result() as $row) { ?>
				<div><h3>Student Name :-<?php  echo $row->name; ?></h3></div>
				<div><h3>Enrollment No :-<?php  echo $row->enrollmentno; ?> </h3></div>
				<?php } ?>sub
		</div>
		<div class="col-lg-3">
			<div><h3>Timer :- 10:10 AM</h3></div>
		</div>
	</div>
</div>
<div class="container" >
	<div class="row">
		<div class="col-lg-2"  style="border-right: red 1px solid; padding-bottom: 5px">
			Question Navigation<br><br>
			<table class="table" border="1">
			<tbody>
				<tr>
				<td>1</td><td>2</td><td>3</td><td>4</td><td>5</td>
				</tr>
				<tr>
				<td>6</td><td>7</td><td>8</td><td>9</td><td>10</td>
				</tr>
				<tr>
				<td>11</td><td>12</td><td>13</td><td>14</td><td>15</td>
				</tr>
				<tr>
				<td>16</td><td>17</td><td>18</td><td>19</td><td>20</td>
				</tr>
				<tr>
				<td>21</td><td>22</td><td>23</td><td>24</td><td>25</td>
				</tr>
				<tr>
				<td>26</td><td>27</td><td>28</td><td>29</td><td>30</td>
				</tr>
				<tr>
				<td>31</td><td>32</td><td>33</td><td>34</td><td>35</td>
				</tr>
				<tr>
				<td>36</td><td>37</td><td>38</td><td>39</td><td>40</td>
				</tr>
				<tr>
				<td>41</td><td>42</td><td>43</td><td>44</td><td>45</td>
				</tr>
				<tr>
				<td>46</td><td>47</td><td>48</td><td>49</td><td>50</td>
				</tr>
				<tr>
				<td>51</td><td>52</td><td>53</td><td>54</td><td>55</td>
				</tr>
				<tr>
				<td>56</td><td>57</td><td>58</td><td>59</td><td>60</td>
				</tr>
				<tr>
				<td>61</td><td>62</td><td>63</td><td>64</td><td>65</td>
				</tr>
				<tr>
				<td>66</td><td>67</td><td>68</td><td>69</td><td>70</td>
				</tr>
				<tr>
				<td>71</td><td>72</td><td>73</td><td>74</td><td>75</td>
				</tr>
				<tr>
				<td>76</td><td>77</td><td>78</td><td>79</td><td>80</td>
				</tr>
				<tr>
				<td>81</td><td>82</td><td>83</td><td>84</td><td>85</td>
				</tr>
				<tr>
				<td>86</td><td>87</td><td>88</td><td>89</td><td>90</td>
				</tr>
				<tr>
				<td>91</td><td>92</td><td>93</td><td>94</td><td>95</td>
				</tr>
				<tr>
				<td>96</td><td>97</td><td>98</td><td>99</td><td>100</td>
				</tr>
			</tbody>
				
			</table>
		</div>
		<div class="col-lg-5" style="border-right: red 1px solid; padding-bottom: 790px">
			English Format
		</div>
		
		<div class="col-lg-5">
			Hindi Format
		</div>
	</div>
</div>

<div class="footer" style="border-top: red 1px solid;">
<div class="container">
	<div class="row">
		<div class="col-lg-6">
		<ul class="pager">
  		<li class="previous"><a href="#">Previous</a></li>
  		</ul></div>
  		<div class="col-lg-6">
		<ul class="pager">
  		<li class="next"><a href="#">Next</a></li>
  		</ul></div>
  	</div>
</div>
</div>
</body>
</html>