<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
   <!-- <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />-->
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    
    <title>ExamCenter</title>
    <!-- Bootstrap Styles-->
    <link href="<?php echo base_url('adminasset/css/bootstrap.css'); ?>" rel="stylesheet" />
    <!-- FontAwesome Styles-->
    <link href="<?php echo base_url('adminasset/css/font-awesome.css'); ?>" rel="stylesheet" />
    <!-- Morris Chart Styles-->
    <link href="<?php echo base_url('adminasset/js/morris/morris-0.4.3.min.css');?> " rel="stylesheet" />
    <!-- Custom Styles-->
    <link href="<?php echo base_url('adminasset/css/custom-styles.css');?>" rel="stylesheet" />
    <!-- Google Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <SCRIPT language=JavaScript src="<?php echo base_url('adminasset/js/common.js'); ?>"></SCRIPT>
<SCRIPT language=JavaScript src="<?php echo base_url('adminasset/js//hindi.js')?>"></SCRIPT>
<style>
 
<!--
/************** Font Declarations *********************************/
@font-face { src: url("<?php echo base_url('adminasset/fonts/HIMALAYA.ttf');?>"); font-family: "HIMALAYA";  }
@font-face{
  font-family :"jayafontk10";
  src:url('<?php echo base_url('assets/fonts/K010.ttf') ?>');
}


/* @font-face {src: url("Osho.ttf");font-family: "Osho";}

@font-face {src: url("kalimati.ttf");font-family: "kalimati";}

@font-face {src: url("samanata.ttf");font-family: "samanata";}

@font-face {src: url("cdac.ttf");font-family: "cdac";}
*/
/*****************************************************************/



/*****************************************************************/
.jayafont {    
    font: 1em 'jayafontk10';

}


</style>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){


     $("#enyesnos").click(function(){
        $("#hiddenofmine").hide();
      });
     
     $("#engquestion").click(function(){
        $("#hiddenofmine").show();
      });

     // alert("working");
      $('#subjectid').on('change',function(){
        var subjectID = $(this).val();
        if(subjectID){
            $.ajax({              
                type:'POST',
                url:'http://localhost/examcenter/index.php/Selectcourse_test/gettest',
                data:'subject_id='+subjectID,
                success:function(html){
                  
                    $('#testid').html(html);
                   // $('#city').html('<option value="">Select state first</option>'); 
                }
            }); 
        }else{
            $('#testid').html('<option value="">Select Course</option>');
           // $('#city').html('<option value="">Select state first</option>'); 
        }
    });
    });
  </script>

</head>

<body>
    <div id="wrapper">
        <?php $this->load->view('uppermenu.php'); ?>
        <!--/. NAV TOP  -->
        <?php  $this->load->view('sidemenu.php'); ?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">


                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Question/Answer <small>Enter Question/Answer Details</small>
                        </h1>
                    </div>
                </div>
                <!-- /. ROW  -->

                <div class="row">
                 <form role="form" action="<?php echo base_url('index.php/Questions/questionanswer_details'); ?>" method="post">
                    <div class="col-lg-12">
                      <div class="col-lg-6">
                          <div class="form-group">
                                            <label>Subject Name</label>
                                            <select class="form-control" name="subjectid" id="subjectid">
                                               <?php  
                                             foreach ($h->result() as $row)  
                                             {  
                                                ?>
                                                <option value="<?php echo $row->subjectid; ?>"><?php echo $row->subjectname; ?></option>
                                              <?php
                                          }
                                              ?>  
                                                                                            
                                            </select>
                                        </div>
                      </div>
                      <div class="col-lg-6">
                          <div class="form-group">
                                            <label>Test Name</label>
                                            <select class="form-control" name="testid" id="testid">
                                                 <?php  
                                             foreach ($k->result() as $row)  
                                             {  
                                                ?>
                                                <option value="<?php echo $row->testid; ?>"><?php echo $row->testname; ?></option>
                                              <?php
                                          }
                                              ?>  
                                            </select>
                                        </div>
                                        
                      </div>


                                      
                                      
                                          <div class="form-group well">
                                          <ul class="nav nav-tabs">
                                            <li class="active"><a data-toggle="pill" href="#home">English</a></li>
                                            <li><a data-toggle="pill" href="#menu1">Hindi</a></li>                                           
                                          </ul>
                                          
                                          <div class="tab-content" style="padding-top:10px;">
                                                        
                                            <div id="home" class="tab-pane fade in active">

                                                   <div class="form-group">
                                                            <label>Question</label>
                                                            <textarea class="form-control" rows="3" id="englishquestion" name="englishquestion"></textarea>  
                                                         </div>
                                                  <ul class="nav nav-tabs">
                                                    <li class="active"><a data-toggle="pill" href="#enquestion" id="engquestion" style="padding-right: 300px;">Options</a></li>
                                                    <li><a data-toggle="pill" href="#enyesno" id="enyesnos">Yes/No Question</a></li>                                           
                                                  </ul>
                                                  <div class="tab-content">
                                                    <div id="enquestion" class="tab-pane fade in active">                                                          
                                                         <div class="form-group">
                                                            <label>Option1</label>
                                                            <input class="form-control" name="engoption1" id="engoption1">         
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Option2</label>
                                                            <input class="form-control" name="engoption2" id="engoption2">         
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Option3</label>
                                                            <input class="form-control" name="engoption3" id="engoption3">         
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Option4</label>
                                                            <input class="form-control" name="engoption4" id="engoption4">         
                                                        </div>
                                                      
                                                    </div>
                                                    <div id="enyesno" class="tab-pane fade" style="padding-top: 10px">
                                                      <div class="form-group">
                                                           <label>
                                                                <input type="radio" name="englishtrueans" id="englishtrueans" value="true">True
                                                           </label>       
                                                        </div>
                                                        <div class="form-group">
                                                           <label>
                                                                <input type="radio" name="englishtrueans" id="englishtrueans" value="false">False
                                                           </label>       
                                                        </div>
                                                    </div>
                                                   
                                                 </div>
                                            </div>
                                                    <div id="menu1" class="tab-pane fade gargi">
                                                       <div class="form-group">
                                                            <label>Question</label>
                                                            <textarea class="form-control jayafont" name="hindiquestion" id="hindiquestion" charset="utf-8"></textarea>
                                                         </div>
                                                  <ul class="nav nav-tabs">
                                                    <li class="active"><a data-toggle="pill" href="#enquestion1" style="padding-right: 300px;">Options</a></li>
                                                    <li><a data-toggle="pill" href="#enyesno1">Yes/No Question</a></li>                                           
                                                  </ul>
                                                  <div class="tab-content">
                                                    <div id="enquestion1" class="tab-pane fade in active">                                                          
                                                         <div class="form-group">
                                                            <label>Option1</label>
                                                            <input class="form-control jayafont" name="hindioption1" id="hindioption1" charset="utf-8" >         
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Option2</label>
                                                            <input class="form-control jayafont" name="hindioption2" id="hindioption2" charset="utf-8" >         
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Option3</label>
                                                            <input class="form-control jayafont" name="hindioption3" id="hindioption3" charset="utf-8">         
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Option4</label>
                                                            <input class="form-control jayafont" name="hindioption4" id="hindioption4" charset="utf-8">         
                                                        </div>
                                                       

                                                    </div>
                                                    
                                                    <div id="enyesno1" class="tab-pane fade" style="padding-top: 10px">
                                                    
                                                      <div class="form-group">
                                                           <label>
                                                                <input type="radio" name="hinditrueans" id="hinditrueans" value="true">True
                                                           </label>       
                                                        </div>
                                                        <div class="form-group">
                                                           <label>
                                                                <input type="radio" name="hinditrueans" id="hinditrueans" value="false">False
                                                           </label>       
                                                        </div>
                                                    </div>
                                                   
                                                 </div>
                                                    </div>
                                                   
                                          </div>
                                                        <div class="form-group" class="hiddenofmine" id="hiddenofmine">
   
                                                            <label>Currect Answer</label>
                                                            <select name="engrightoption" id="engrightoption">
                                                            <option value="engoption1">Option1</option> 
                                                            <option value="engoption2">Option2</option>       
                                                            <option value="engoption3">Option3</option> 
                                                            <option value="engoption4">Option4</option> 
                                                            </select>
                                                        </div>
                                        </div>
                                        <input type="hidden" name="todaya" id="todaya" value="<?php echo date('Y/m/d H:i:s'); ?>">
                                        <button type="submit" class="btn btn-default">Submit Button</button>
                                        <button type="reset" class="btn btn-default">Reset Button</button>
                    </div> 
                    </form>




                 </div>
                 <!-- /.Row -->
                <!-- /. ROW  -->
				<?php $this->load->view("footer.php"); ?>
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="<?php echo base_url('adminasset/js/jquery-1.10.2.js'); ?>"></script>
    <!-- Bootstrap Js -->
    <script src="<?php echo base_url('adminasset/js/bootstrap.min.js'); ?>"></script>
    <!-- Metis Menu Js -->
    <script src="<?php echo base_url('adminasset/js/jquery.metisMenu.js'); ?>"></script>
    <!-- Morris Chart Js -->
    <script src="<?php echo base_url('adminasset/js/morris/raphael-2.1.0.min.js'); ?>"></script>
    <script src="<?php echo base_url('adminasset/js/morris/morris.js'); ?>"></script>
    <script src="<?php echo base_url('adminasset/js/jquery.metisMenu.js');?>"></script>
    <script src="<?php echo base_url('adminasset/js/dataTables/jquery.dataTables.js');?>"></script>
    <script src="<?php echo base_url('adminasset/js/dataTables/dataTables.bootstrap.js') ?>"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
    <!-- Custom Js -->
    <script src="<?php echo base_url('adminasset/js/custom-scripts.js'); ?>"></script>


</body>

</html>