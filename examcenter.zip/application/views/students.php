<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ExamCenter</title>
    <!-- Bootstrap Styles-->
    <link href="<?php echo base_url('adminasset/css/bootstrap.css'); ?>" rel="stylesheet" />
    <!-- FontAwesome Styles-->
    <link href="<?php echo base_url('adminasset/css/font-awesome.css'); ?>" rel="stylesheet" />
    <!-- Morris Chart Styles-->
    <link href="<?php echo base_url('adminasset/js/morris/morris-0.4.3.min.css');?> " rel="stylesheet" />
    <!-- Custom Styles-->
    <link href="<?php echo base_url('adminasset/css/custom-styles.css');?>" rel="stylesheet" />
    <!-- Google Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <script type="text/javascript">
    $(document).ready(function(){
    jQuery('.numbersOnly').keyup(function () { 
    this.value = this.value.replace(/[^0-9\.]/g,'');
    });
    });

    
  </script>
</head>

<body>
    <div id="wrapper">
        <?php $this->load->view('uppermenu.php'); ?>
        <!--/. NAV TOP  -->
        <?php  $this->load->view('sidemenu.php'); ?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">


                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Students <small><a href="<?php echo site_url('Student/addstudent'); ?>">Add New Student Details</a></small>
                        </h1>
                    </div>
                </div>
                <!-- /. ROW  -->

                <div class="row">
                      <form action="<?php echo site_url('Student/students_update'); ?>" method="post" name="student" enctype="multipart/form-data">
                    <div class="col-lg-12">
                        <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Advanced Tables
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>Enrollment_No</th>                                            
                                            <th>Student Detials</th>
                                                   
                                            <th>Edit / Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                   <div class="hidden"> <input type="text" value="" id="studentids" name="studentids"></div>
                                        <?php  
                                        $count=1;
                                             foreach ($h->result() as $row)  
                                             {  
                                                ?>
                                                <!-- hidden input for passing model -->
                                                                                                 
                                                      
                                                       
                                                       
                                                         
                                                          
                                                <!-- end of hidden input for passing model -->
                                                <tr class="odd gradeX">  
                                                <td><?php $enrolldisplay= $row->enrollmentno;
                                                $enrolldisplay = str_replace("_", "/", $enrolldisplay);
                                                echo $enrolldisplay;
                                                ?>
                                                    <input type="hidden" value="<?php echo $row->enrollmentno; ?>" id="enrollmentno<?php echo $count; ?>" name="enrollmentno<?php echo $count; ?>">

                                                    <input type="hidden" value="<?php echo $row->studentid; ?>" id="studentid<?php echo $count; ?>" name="studentid<?php echo $count; ?>"> 

                                                    <input type="hidden" value="<?php echo $row->password; ?>" id="password<?php echo $count; ?>" name="password<?php echo $count; ?>">                                                </td>  
                                                <td>
                                                Name :-  <input type="text" value="<?php echo $row->name; ?>" id="name<?php echo $count; ?>" name="name<?php echo $count; ?>" readonly="readonly" style="border:none;"><BR>
                                                Address :- <input type="text" value="<?php echo $row->address; ?>" id="address<?php echo $count; ?>" name="address<?php echo $count; ?>" readonly="readonly" style="border:none;"><BR>
                                                Email :-  <input type="text" value="<?php echo $row->email; ?>" id="email<?php echo $count; ?>" name="email<?php echo $count; ?>" readonly="readonly" style="border:none;"><BR>
                                                Contact No :- <input type="text" value="<?php echo $row->contactno; ?>" id="contactno<?php echo $count; ?>" name="contactno<?php echo $count; ?>" readonly="readonly" style="border:none;"><br>
                                                Subject :- <input type="text" value="<?php echo $row->subjectid; ?>" id="subjectid<?php echo $count; ?>" name="subjectid<?php echo $count; ?>" readonly="readonly" style="border:none;">
                                                </td>
                                                <td class="center"><img src="<?php echo base_url('uploads/'.$row->photo);?>" " width="100" height="100" name="img<?php echo $count; ?>" id="img<?php  echo $count; ?>">
                                                <input type="hidden"  value="<?php echo base_url('uploads/'.$row->photo);?>"  name="photos<?php echo $count; ?>" id="photos<?php  echo $count; ?>"> <BR>
                                                
                                                 <input  type="submit" class="btn btn-info btn-sm" value="Update" name="update" id="update" onclick="document.getElementById('studentids').value=document.getElementById('studentid<?php echo $count; ?>').value;"></td>  
                                                </tr>  
                                             <?php
                                             $count++; }  
                                             ?>   

                                            

                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                    </div>                   
                  </form>  


                 

                 </div>
                 <!-- /.Row -->
                <!-- /. ROW  -->
				<?php $this->load->view("footer.php"); ?>
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="<?php echo base_url('adminasset/js/jquery-1.10.2.js'); ?>"></script>
    <!-- Bootstrap Js -->
    <script src="<?php echo base_url('adminasset/js/bootstrap.min.js'); ?>"></script>
    <!-- Metis Menu Js -->
    <script src="<?php echo base_url('adminasset/js/jquery.metisMenu.js'); ?>"></script>
    <!-- Morris Chart Js -->
    <script src="<?php echo base_url('adminasset/js/morris/raphael-2.1.0.min.js'); ?>"></script>
    <script src="<?php echo base_url('adminasset/js/morris/morris.js'); ?>"></script>
    <script src="<?php echo base_url('adminasset/js/jquery.metisMenu.js');?>"></script>
    <script src="<?php echo base_url('adminasset/js/dataTables/jquery.dataTables.js');?>"></script>
    <script src="<?php echo base_url('adminasset/js/dataTables/dataTables.bootstrap.js') ?>"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
    <!-- Custom Js -->
    <script src="<?php echo base_url('adminasset/js/custom-scripts.js'); ?>"></script>


</body>

</html>