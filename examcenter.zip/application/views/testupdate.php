<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ExamCenter</title>
    <!-- Bootstrap Styles-->
    <link href="<?php echo base_url('adminasset/css/bootstrap.css'); ?>" rel="stylesheet" />
    <!-- FontAwesome Styles-->
    <link href="<?php echo base_url('adminasset/css/font-awesome.css'); ?>" rel="stylesheet" />
    <!-- Morris Chart Styles-->
    <link href="<?php echo base_url('adminasset/js/morris/morris-0.4.3.min.css');?> " rel="stylesheet" />
    <!-- Custom Styles-->
    <link href="<?php echo base_url('adminasset/css/custom-styles.css');?>" rel="stylesheet" />
    <!-- Google Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />

      
</head>
<style type="text/css">
    .css-serial {
 counter-reset: serial-number; /* Set the serial number counter to 0 */
}
.css-serial td:first-child:before {
 counter-increment: serial-number; /* Increment the serial number counter */
 content: counter(serial-number); /* Display the counter */
}
</style>
<body>
    <div id="wrapper">
        <?php $this->load->view('uppermenu.php'); ?>
        <!--/. NAV TOP  -->
        <?php  $this->load->view('sidemenu.php'); ?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">


                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Test <small>Enter Test Details</small>
                        </h1>
                    </div>
                </div>
                <!-- /. ROW  -->

                <div class="row">
                
                       <div class="col-md-12">
                        <!-- START ORIGINAL MODEL HERE-->
                      
                    <form action="<?php echo base_url('index.php/Test/edittest_details');?>" method="post" enctype="multipart/form-data">
                     <?php foreach ($test->result() as $row) 
                                        { ?>
                                          <div class="col-md-9">
                                            <div class="form-group">                                           
                                            <label>Test Name *</label>
                                             <input class="form-control" type="hidden" value="<?php echo $row->testid; ?>" name="testidmodel" id="testidmodel" required="required"> 
                                            <input class="form-control" name="testname" id="testname" required="required" value="<?php echo $row->testname; ?>">
                                            </div>
                                            </div>  

                                            <div class="col-md-9">
                                            <div class="form-group">                                           
                                            <label>Course Name *</label>
                                            <select class="form-control" id="subjectname" name="subjectname" required="required">
                                                <?php
                                                foreach ($h-> result() as $row2) {
                                                  foreach($test->result() as $row1)
                                                     { 
                                                  if($row1->subjectname == $row2->subjectid){
                                                ?>
                                                                     
                                            <option selected="selected" value="<?php echo $row2->subjectid; ?>"><?php echo $row2->subjectname; ?></option>
                                          <?php
                                            }
                                            else{
                                              ?>
                                                <option value="<?php echo $row2->subjectid; ?>"><?php echo $row2->subjectname; ?></option>
                                              <?php

                                            }

                                          }
                                        }
                                              ?>                                     
                                                                                         
                                            </select>
                                        </div> 
                                        </div> 

                                        <div class="col-md-9">
                                        <div class="form-group">                                        
                                            <label>Total Question *</label>
                                            <input class="form-control" name="totalquestion" id="totalquestion" required="required" value="<?php echo $row->totalquestion; ?>">         
                                           </div> 
                                        </div>

                                         <div class="col-md-9">
                                        <div class="form-group">                                       
                                            <label>Total Marks *</label>
                                            <input class="form-control" name="totalmarks" id="totalmarks" required="required" value="<?php echo $row->totalmarks; ?>">         
                                        </div>
                                        </div>     


                                         <div class="col-md-9">
                                        <div class="form-group">   
                                        <label>Test*</label>&nbsp;&nbsp;
                                        <input type="radio" name="optionradiomodel" id="optionradiomodel" value="On"  <?php if($row->onoff == 'On') { echo "checked='checked'";} ?> > ON &nbsp;&nbsp;
                                        <input type="radio" name="optionradiomodel" id="optionradiomodel" value="Off" <?php if($row->onoff == 'Off') { echo "checked='checked'";} ?>  >OFF
                                           
                                           
                                           </div>
                                           </div>
                                          

                                            <div class="col-md-9">
                                           <div class="form-group">
                                           <label>Test Duration*</label>
                                            <select class="form-control" id="tdurationmodel" name="tdurationmodel" >

                                          <?php  
                                             foreach ($k->result() as $row4)  
                                             { 
                                                foreach($test->result() as $row5)
                                                { 
                                                  
                                                ?>
                                                <?php if($row5->testid == $row4->testid){
                                                    $selectvalue = $row4->testduration;
                                                } 
                                                
                                              }
                                            }
                                              ?>
                                        
                                            <option  value="30:00" <?php if($selectvalue == "30:00"){echo "selected='selected'";} ?>>Half Hours</option>
                                            <option  value="60:00" <?php if($selectvalue == "60:00"){echo "selected='selected'";}?>>One Hours</option>
                                            

                            </select>                     
                                              
                                        </div>
                                        </div>

                                        

                                     <?php   } ?>
                                         <div class="col-md-9">
                                        <div class="form-group ">
                                         <input type="hidden" name="todayamodel" id="todayamodel" value="<?php echo date('Y/m/d H:i:s'); ?>">
                                            <input type="submit" class="btn btn-warning" data-dimiss="modal" value="Update" name="update" id="update">
                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <input type="submit" class="btn btn-danger" data-dimiss="modal" value="Delete" name="delete" id="delete">
                                        </div>
                                        </div>

                                </form>                    
                               
                                </div>
                               
         

                       </div>     
                    
                    <!--End Advanced Tables -->
                                    
                 


                

                 </div>
                 <!-- /.Row -->
                <!-- /. ROW  -->
                <footer><p>All right reserved. Template by: <a href="http://webthemez.com">WebThemez</a></p></footer>
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="<?php echo base_url('adminasset/js/jquery-1.10.2.js'); ?>"></script>
    <!-- Bootstrap Js -->
    <script src="<?php echo base_url('adminasset/js/bootstrap.min.js'); ?>"></script>
    <!-- Metis Menu Js -->
    <script src="<?php echo base_url('adminasset/js/jquery.metisMenu.js'); ?>"></script>
    <!-- Morris Chart Js -->
    <script src="<?php echo base_url('adminasset/js/morris/raphael-2.1.0.min.js'); ?>"></script>
    <script src="<?php echo base_url('adminasset/js/morris/morris.js'); ?>"></script>
    <script src="<?php echo base_url('adminasset/js/jquery.metisMenu.js');?>"></script>
    <script src="<?php echo base_url('adminasset/js/dataTables/jquery.dataTables.js');?>"></script>
    <script src="<?php echo base_url('adminasset/js/dataTables/dataTables.bootstrap.js') ?>"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
    <!-- Custom Js -->
    <script src="<?php echo base_url('adminasset/js/custom-scripts.js'); ?>"></script>


</body>

</html>