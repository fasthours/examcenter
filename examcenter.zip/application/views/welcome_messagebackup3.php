<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style type="text/css">

body {
   background-color: #ffffff;   
}

/* start of 280 px style */
@media only screen and (min-width:280px){

.firstlevel{
  z-index: 10;
}
.firstbackground{
  height:30px;
  background-color: #f4f6f9;
}
.secondbackground{
  height:30px;
  margin-top: 5px;
  background-color:#d7dee8;
}
.secondlevel{
  z-index: 20;
}
.roundedsquare{
    border-radius: 12px;
    border: 1px solid blue;
    height: 100px;
    margin-top:-40px;
    width: 80%;
    background-color: transparent;
}
.thirdlevel{
  z-index: 30;
}
.roundedsquareblackup{
    border-radius: 25px;
    border: 1px solid blue;
    height: 20px;
    margin-top:-100px;
    width: 80%;
    background-color: #4D4D4D;
}
.fourthlevel{
  z-index: 40;
}
.roundedsquaregreenup{
    border-radius: 25px;
    border: 1px solid blue;
    height: 10px;
    margin-top:-20px;
    width: 80%;
    background-color: #92AE1A;
}
.alignment{position:relative;margin-top:-8px;}
    .leftarrow,.rightarrow{width:50%; position:absolute;}
    .rightarrow{right:-7.1%;}
    .leftarrow{left:-7.1%;}
.rightarrows{
  width: 31%
 }
 .leftarrows{
  width: 31%
 }

}
/* end of 280 px style */


/* start of 320 px style */
@media only screen and (min-width:320px)  { 


.firstlevel{
  z-index: 10;
}
.firstbackground{
  height:30px;
  background-color: #f4f6f9;
}
.secondbackground{
  height:30px;
  margin-top: 5px;
  background-color:#d7dee8;
}
.secondlevel{
  z-index: 20;
}
.roundedsquare{
    border-radius: 12px;
    border: 1px solid blue;
    height: 100px;
    margin-top:-40px;
    width: 80%;
    background-color: transparent;
}
.thirdlevel{
  z-index: 30;
}
.roundedsquareblackup{
    border-radius: 25px;
    border: 1px solid blue;
    height: 20px;
    margin-top:-100px;
    width: 80%;
    background-color: #4D4D4D;  
}
.fourthlevel{
  z-index: 40;
}
.roundedsquaregreenup{
    border-radius: 25px;
    border: 1px solid blue;
    height: 10px;
    margin-top:-20px;
    width: 80%;
    background-color: #92AE1A;
}
.alignment{position:relative;margin-top:-8px;}
    .leftarrow,.rightarrow{width:50%; position:absolute;}
    .rightarrow{right:-7.1%;}
    .leftarrow{left:-7.1%;}
.rightarrows{
  width: 31%
 }
 .leftarrows{
  width: 31%
 }
 }

/* end of 320 px style */
/* start of 481 px style */

@media only screen and (min-width:481px)  { 


.firstlevel{
  z-index: 10;
}
.firstbackground{
  height:30px;
  background-color: #f4f6f9;
}
.secondbackground{
  height:30px;
  margin-top: 5px;
  background-color:#d7dee8;
}
.secondlevel{
  z-index: 20;
}
.roundedsquare{
    border-radius: 12px;
    border: 1px solid blue;
    height: 100px;
    margin-top:-40px;
    width: 80%;
    background-color: transparent;
}
.thirdlevel{
  z-index: 30;
}
.roundedsquareblackup{
    border-radius: 25px;
    border: 1px solid blue;
    height: 20px;
    margin-top:-100px;
    width: 80%;
    background-color: #4D4D4D;
}
.fourthlevel{
  z-index: 40;
}
.roundedsquaregreenup{
    border-radius: 25px;
    border: 1px solid blue;
    height: 10px;
    margin-top:-20px;
    width: 80%;
    background-color: #92AE1A;
}
.alignment{position:relative;margin-top:-8px;}
    .leftarrow,.rightarrow{width:50%; position:absolute;}
    .rightarrow{right:-7.1%;}
    .leftarrow{left:-7.1%;}
.rightarrows{
  width: 31%
 }
 .leftarrows{
  width: 31%
 }

}

/* end of 481 px style */

/*start of 641 px style */

@media only screen and (min-width:641px)  { 

.firstlevel{
  z-index: 10;
}
.firstbackground{
  height:110px;
  background-color: #f4f6f9;
}
.secondbackground{
  height:130px;
  margin-top: 5px;
  background-color:#d7dee8;
}
.secondlevel{
  z-index: 20;
}
.roundedsquare{
    border-radius: 25px;
    border: 1px solid blue;
    height: 400px;
    margin-top:-160px;
    width: 90%;
    background-color: transparent;
}
.thirdlevel{
  z-index: 30;
}
.roundedsquareblackup{
    border-radius: 25px;
    border: 1px solid blue;
    height: 60px;
    margin-top:-399px;
    width: 90%;
    background-color: #4D4D4D;
}
.fourthlevel{
  z-index: 40;
}
.roundedsquaregreenup{
    border-radius: 16px;
    border: 1px solid transparent;
    height: 35px;
    margin-top:-60px;
    width: 90%;
    background-color: #92AE1A;
}
.alignment{position:relative;margin-top:-8px;}
    .leftarrow,.rightarrow{width:50%; position:absolute;}
    .rightarrow{right:-12.1%;}
    .leftarrow{left:-12.1%;}
.rightarrows{
  width: 31%
 }
 .leftarrows{
  width: 31%
 }


}



/* end of 641 px style */




/*start of 680 px style */

@media only screen and (min-width:680px)  { 

.firstlevel{
  z-index: 10;
}
.firstbackground{
  height:110px;
  background-color: #f4f6f9;
}
.secondbackground{
  height:130px;
  margin-top: 5px;
  background-color:#d7dee8;
}
.secondlevel{
  z-index: 20;
}
.roundedsquare{
    border-radius: 25px;
    border: 1px solid blue;
    height: 400px;
    margin-top:-160px;
    width: 90%;
    background-color: transparent;
}
.thirdlevel{
  z-index: 30;
}
.roundedsquareblackup{
    border-radius: 25px;
    border: 1px solid blue;
    height: 60px;
    margin-top:-399px;
    width: 90%;
    background-color: #4D4D4D;
}
.fourthlevel{
  z-index: 40;
}
.roundedsquaregreenup{
    border-radius: 16px;
    border: 1px solid transparent;
    height: 35px;
    margin-top:-60px;
    width: 90%;
    background-color: #92AE1A;
}
.alignment{position:relative;margin-top:-8px;}
    .leftarrow,.rightarrow{width:50%; position:absolute;}
    .rightarrow{right:-12.1%;}
    .leftarrow{left:-12.1%;}
.rightarrows{
  width: 31%
 }
 .leftarrows{
  width: 31%
 }


}



/* end of 680 px style */

/* start of 720 px style */

@media only screen and (min-width:720px)  { 

.firstlevel{
  z-index: 10;
}
.firstbackground{
  height:110px;
  background-color: #f4f6f9;
}
.secondbackground{
  height:130px;
  margin-top: 5px;
  background-color:#d7dee8;
}
.secondlevel{
  z-index: 20;
}
.roundedsquare{
    border-radius: 25px;
    border: 1px solid blue;
    height: 400px;
    margin-top:-160px;
    width: 90%;
    background-color: transparent;
}
.thirdlevel{
  z-index: 30;
}
.roundedsquareblackup{
    border-radius: 25px;
    border: 1px solid blue;
    height: 60px;
    margin-top:-399px;
    width: 90%;
    background-color: #4D4D4D;
}
.fourthlevel{
  z-index: 40;
}
.roundedsquaregreenup{
    border-radius: 16px;
    border: 1px solid transparent;
    height: 35px;
    margin-top:-60px;
    width: 90%;
    background-color: #92AE1A;
}
.alignment{position:relative;margin-top:-8px;}
    .leftarrow,.rightarrow{width:50%; position:absolute;}
    .rightarrow{right:-12.1%;}
    .leftarrow{left:-12.1%;}
.rightarrows{
  width: 31%
 }
 .leftarrows{
  width: 31%
 }


}

/* end of 720 px style */

/* start of 743 px style */


@media only screen and(min-width:720px)  { 

.firstlevel{
  z-index: 10;
}
.firstbackground{
  height:110px;
  background-color: #f4f6f9;
}
.secondbackground{
  height:130px;
  margin-top: 5px;
  background-color:#d7dee8;
}
.secondlevel{
  z-index: 20;
}
.roundedsquare{
    border-radius: 25px;
    border: 1px solid blue;
    height: 400px;
    margin-top:-160px;
    width: 90%;
    background-color: transparent;
}
.thirdlevel{
  z-index: 30;
}
.roundedsquareblackup{
    border-radius: 25px;
    border: 1px solid blue;
    height: 63px;
    margin-top:-399px;
    width: 90%;
    background-color: #4D4D4D;
}
.fourthlevel{
  z-index: 40;
}
.roundedsquaregreenup{
    border-radius: 16px;
    border: 1px solid transparent;
    height: 35px;
    margin-top:-62px;
    width: 90%;
    background-color: #92AE1A;
}
.alignment{position:relative;margin-top:-8px;}
    .leftarrow,.rightarrow{width:50%; position:absolute;}
    .rightarrow{right:-12.1%;}
    .leftarrow{left:-12.1%;}
.rightarrows{
  width: 31%
 }
 .leftarrows{
  width: 31%
 }


}


/* end of 743 px style */

/* start of 961 px style */

@media only screen and(min-width:961px)  { /* tablet, landscape iPad, lo-res laptops ands desktops */ 

.firstlevel{
  z-index: 10;
}
.firstbackground{
  height:110px;
  background-color: #f4f6f9;
}
.secondbackground{
  height:130px;
  margin-top: 5px;
  background-color:#d7dee8;
}
.secondlevel{
  z-index: 20;
}
.roundedsquare{
    border-radius: 25px;
    border: 1px solid blue;
    height: 400px;
    margin-top:-160px;
    width: 90%;
    background-color: transparent;
}
.thirdlevel{
  z-index: 30;
}
.roundedsquareblackup{
    border-radius: 25px;
    border: 1px solid blue;
    height: 70px;
    margin-top:-399px;
    width: 90%;
    background-color: #4D4D4D;
}
.fourthlevel{
  z-index: 40;
}
.roundedsquaregreenup{
    border-radius: 16px;
    border: 1px solid transparent;
    height: 40px;
    margin-top:-70px;
    width: 90%;
    background-color: #92AE1A;
}
.alignment{position:relative;margin-top:-8px;}
    .leftarrow,.rightarrow{width:50%; position:absolute;}
    .rightarrow{right:-11.4%;}
    .leftarrow{left:-11.4%;}
.rightarrows{
  width: 34%
 }
 .leftarrows{
  width: 34%
 }


}
/* end of 961 px style */

/* start of 992 px style */

@media only screen and (min-width:992px)  { /* tablet, landscape iPad, lo-res laptops ands desktops */ 

.firstlevel{
  z-index: 10;
}
.firstbackground{
  height:110px;
  background-color: #f4f6f9;
}
.secondbackground{
  height:130px;
  margin-top: 5px;
  background-color:#d7dee8;
}
.secondlevel{
  z-index: 20;
}
.roundedsquare{
    border-radius: 25px;
    border: 1px solid blue;
    height: 400px;
    margin-top:-160px;
    width: 90%;
    background-color: transparent;
}
.thirdlevel{
  z-index: 30;
}
.roundedsquareblackup{
    border-radius: 25px;
    border: 1px solid blue;
    height: 75px;
    margin-top:-399px;
    width: 90%;
    background-color: #4D4D4D;
}
.fourthlevel{
  z-index: 40;
}
.roundedsquaregreenup{
    border-radius: 16px;
    border: 1px solid transparent;
    height: 40px;
    margin-top:-75px;
    width: 90%;
    background-color: #92AE1A;
}
.alignment{position:relative;margin-top:-9px;}
    .leftarrow,.rightarrow{width:50%; position:absolute;}
    .rightarrow{right:-12.4%;}
    .leftarrow{left:-12.4%;}
.rightarrows{
  width: 30%
 }
 .leftarrows{
  width: 30%
 }


}


/* end of 992 px style*/


/* start of 1025 px style */
@media only screen and (min-width:1025px) { 

  /* big landscape tablets, laptops, and desktops */

  .firstlevel{
  z-index: 10;
}
.firstbackground{
  height:110px;
  background-color: #f4f6f9;
}
.secondbackground{
  height:130px;
  margin-top: 5px;
  background-color:#d7dee8;
}
.secondlevel{
  z-index: 20;
}
.roundedsquare{
    border-radius: 25px;
    border: 1px solid blue;
    height: 400px;
    margin-top:-160px;
    width: 90%;
    background-color: transparent;
}
.thirdlevel{
  z-index: 30;
}
.roundedsquareblackup{
    border-radius: 25px;
    border: 1px solid blue;
    height: 100px;
    margin-top:-401px;
    width: 90%;
    background-color: #4D4D4D;
}
.fourthlevel{
  z-index: 40;
}
.roundedsquaregreenup{
    border-radius: 20px;
    border: 1px solid transparent;
    height: 55px;
    margin-top:-100px;
    width: 90%;
    background-color: #92AE1A;
}
.alignment{position:relative;margin-top:-13px;}
    .leftarrow,.rightarrow{width:50%; position:absolute;}
    .rightarrow{right:-10%;}
    .leftarrow{left:-10%;}
.rightarrows{
  width: 40%
 }
 .leftarrows{
  width: 40%
 }
}
/* end of 1025 px style */

/* starting of 1200 px style */

@media only screen and (min-width: 1200px) {
   
.firstlevel{
  z-index: 10;
}
.firstbackground{
  height:110px;
  background-color: #f4f6f9;
}
.secondbackground{
  height:130px;
  margin-top: 5px;
  background-color:#d7dee8;
}
.secondlevel{
  z-index: 20;
}
.roundedsquare{
    border-radius: 25px;
    border: 1px solid blue;
    height: 400px;
    margin-top:-160px;
    width: 90%;
    background-color: transparent;
}
.thirdlevel{
  z-index: 30;
}
.roundedsquareblackup{
    border-radius: 25px;
    border: 1px solid blue;
    height: 100px;
    margin-top:-401px;
    width: 90%;
    background-color: #4D4D4D;
}
.fourthlevel{
  z-index: 40;
}
.roundedsquaregreenup{
    border-radius: 25px;
    border: 1px solid transparent;
    height:50px;
    margin-top:-100px;
    width: 90%;
    background-color: #92AE1A;
}
.alignment{position:relative;margin-top:-15px;}
    .leftarrow,.rightarrow{width:50%; position:absolute;}
    .rightarrow{right:-10.7%;}
    .leftarrow{left:-10.7%;}

    .rightarrows{
  width: 37%;
 }
 .leftarrows{
  width: 37%;
 }
}


/* end of 1200px style */









  </style>


</head>
<body>
  <div class="container">
    <div class="firstlevel firstbackground"></div>
    <div class="firstlevel secondbackground"></div>
    <center><div class="secondlevel roundedsquare"></div></center>
    <center><div class="thirdlevel roundedsquareblackup"></div></center>
     <center><div class="fourthlevel roundedsquaregreenup"></div></center>
      <center><div class="fifthlevel alignment"><div class="leftarrow"><img class="image-responsive rightarrows" src="<?php echo base_url("assets/images/arrowright.png"); ?>" width="30%"></div><div class="rightarrow"><img class="image-responsive leftarrows" src="<?php echo base_url("assets/images/arrow.png"); ?>" width="30%"></div></div></center>

  </div>
</body>
</html>