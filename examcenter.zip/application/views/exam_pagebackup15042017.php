<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.min.css");?>">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
  <style type="text/css">
  	h3{
  		border-radius: 1px;
  		color:white;
  		font-size:35px;
  	}
  	#defaultCountdown { width: 240px; height: 45px; }
  	@font-face{
  font-family :"jayafontk10";
  src:url('<?php echo base_url('assets/fonts/K010.ttf') ?>');
}
.jayafont {    
    font: 1em 'jayafontk10';

}
  </style>
  <script src="<?php echo base_url("assets/js/jquery.plugin.min.js");?>"></script>
<script src="<?php echo base_url("assets/js/jquery.countdown.js");?>"></script>

</head>
<body>


<form action="<?php echo base_url("index.php/Exam_page/getnext"); ?>" method="post">


<div class="container-fluid" style="height: 440px; background-color: white">
	<input type="hidden" name="enroll" id="enroll" value="<?php echo $enrollmentno; ?>">
	<div class="row">
		<div class="col-xs-2" style="background-color: lightgray;">
			<input type="hidden" value="" name="mygetid" id="mygetid">
			<?php
			$stuanstrue="";
			$stuans="";
			$count=1;


			foreach ($ql->result() as $row2) {
				if($count==1){
				$startvalue= $row2->queansid;
			}
			foreach($t->result() as $rows){
				if($rows->queansid==$row2->queansid){
					//echo $rows->queansid;
				?>

					<button class='btn-success' type="submit" value="<?php echo $row2->queansid; ?>" name="myid<?php echo $count; ?>" id="myid<?php echo $count; ?>" onclick="document.getElementById('mygetid').value=document.getElementById('myid<?php echo $count; ?>').value;getvalue()" /><?php echo $count; ?></button>
			
			<!--<?php// echo $row2->queansid; ?>-->


				<?php
				}
				else{
					?>


					<button type="submit" value="<?php echo $row2->queansid; ?>" name="myid<?php echo $count; ?>" id="myid<?php echo $count; ?>" onclick="document.getElementById('mygetid').value=document.getElementById('myid<?php echo $count; ?>').value;getvalue()" /><?php echo $count; ?></button>
			
			<!--<?php echo $row2->queansid; ?>-->


					<?php
				}
			}
			?>
			
			<?php
			if($count==$endcount){
				$maxvalue= $row2->queansid;
			}
				$count++;}
			
			?>


		</div>
		
		<div class="col-xs-5">
		
			
			<?php foreach($t->result() as $row){ 
				//echo $row->queansid;


				?>
				<?php
												foreach ($getans->result() as $rowans) {
													?>
													<?php $stringsans=$rowans->answer;
												
														 $newstr = explode("_",$stringsans);
														
														if($newstr[0]==$row->engoption1){
															$stuans =  $newstr[0];
														}
														if($newstr[0]==$row->engoption2){
															$stuans =  $newstr[0];
														}
														if($newstr[0]==$row->engoption3){
															$stuans =  $newstr[0];
														}
														if($newstr[0]==$row->engoption4){
															$stuans =  $newstr[0];
														}	
														//echo $row->englishtrueans;
														if($newstr[0]==$row->englishtrueans){
															 $stuanstrue =  $newstr[0];
														}	

														//echo $row->englishtrueans;
														
														//echo "trueflase: ".$newstr[0];
														
														
													 ?>
													<?php
												}
											 ?>
			<?php if($row->queansid == $maxvalue){
	//					echo "this is end";

?>

			<script type="text/javascript">
				$(document).ready(function(){
				$(".hideshow").show();
				$("#next").hide();
			});
			</script>

					<input type="hidden" value="<?php echo $row->queansid; ?>" name="previousid" id="previousid">
			<input type="hidden" value="" name="username" id="username">
		<?php if($row->englishquestion==False){ echo "<div class='content'></div>";}else{ ?><h2>English Questions</h2>
		<div class="content"><h4><B>Question :<BR><?php  echo $row->englishquestion; ?></B></h4> </div><?php }if($row->englishquestion==False){}else{ ?>
		<div class="content"><h4>Answers: <BR><?php if(($row->engoption1==FALSE) && ($row->engoption2==FALSE) && ($row->engoption3==FALSE) && ($row->engoption4==FALSE)) 
                                              { echo $stuanstrue; ?><br>                                              
								       		  <input type='radio' id="englishtrueans1" name="englishtrueans" value="True" <?php if($stuanstrue==$row->englishtrueans){echo "checked='checked'";} ?> onclick="selectone()">True<BR>
                                              <input type='radio' id="englishtrueans2" name="englishtrueans" value="False" <?php  if($stuanstrue==$row->englishtrueans){echo "checked='checked'";} ?> onclick="selectone()">False<BR>
                                               <?php } 
                                               else { 


                                               	?><br>
                                            
                                              <input type='radio' id="engoption1" name="engoption" value="<?php echo $row->engoption1; ?>" <?php if($stuans==$row->engoption1){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption1; ?><BR>
                                              <input type='radio' id="engoption2" name="engoption" value="<?php echo $row->engoption2; ?>" <?php if($stuans==$row->engoption2){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption2; ?><BR>
                                              <input type='radio' id="engoption3" name="engoption" value="<?php echo $row->engoption3; ?>" <?php if($stuans==$row->engoption3){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption3; ?><BR>
                                              <input type='radio' id="engoption4" name="engoption" value="<?php echo $row->engoption4; ?>" <?php if($stuans==$row->engoption4){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption4; ?><BR>                                                           
                                              <?php }}  ?></h4>  
        </div>

<?php
				}
				else if($row->queansid == $startvalue){

					?>

					<script type="text/javascript">
							$(document).ready(function(){
							//	alert('working');
							$("#previous").hide();
							$(".hideshow").hide();
							//$("#previous").hide();


							});
					</script>
					<input type="hidden" value="<?php echo $row->queansid; ?>" name="previousid" id="previousid">
			<input type="hidden" value="" name="username" id="username">
		<?php if($row->englishquestion==False){echo "<div class='content'></div>"; }else{ ?><h2>English Questions</h2>
		<div class="content"><h4><B>Question :<BR><?php  echo $row->englishquestion; ?></B></h4> </div><?php }if($row->englishquestion==False){}else{ ?>
		<div class="content"><h4>Answers: <BR><?php if(($row->engoption1==FALSE) && ($row->engoption2==FALSE) && ($row->engoption3==FALSE) && ($row->engoption4==FALSE)) 
                                              { echo $stuanstrue;  ?><br>
                                         	  <input type='radio' id="englishtrueans1" name="englishtrueans" value="True" <?php if($stuanstrue==$row->englishtrueans){echo "checked='checked'";} ?> onclick="selectone()">True<BR>
                                              <input type='radio' id="englishtrueans2" name="englishtrueans" value="False" <?php if($stuanstrue==$row->englishtrueans){echo "checked='checked'";} ?> onclick="selectone()">False<BR>
                                               <?php } 
                                               else { ?><br>
                                              

                                               
                                              <input type='radio' id="engoption1" name="engoption" value="<?php echo $row->engoption1; ?>" <?php if($stuans==$row->engoption1){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption1; ?><BR>
                                              <input type='radio' id="engoption2" name="engoption" value="<?php echo $row->engoption2; ?>" <?php if($stuans==$row->engoption2){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption2; ?><BR>
                                              <input type='radio' id="engoption3" name="engoption" value="<?php echo $row->engoption3; ?>" <?php if($stuans==$row->engoption3){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption3; ?><BR>
                                              <input type='radio' id="engoption4" name="engoption" value="<?php echo $row->engoption4; ?>" <?php if($stuans==$row->engoption4){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption4; ?><BR>                                                           
                                              <?php }}  ?></h4>  
        </div>
					<?php
				}
				else{ ?>
				<script type="text/javascript">
					$(document).ready(function(){
					//	alert('working');
					$(".hideshow").hide();
					//$("#previous").hide();


				});
			</script>
			<input type="hidden" value="<?php echo $row->queansid; ?>" name="previousid" id="previousid">
			<input type="hidden" value="" name="username" id="username">
			<?php if($row->englishquestion==False){echo "<div class='content'></div>";}else{ ?><h2>English Questions</h2>
		<div class="content"><h4><B>Question :<BR><?php  echo $row->englishquestion; ?></B></h4> </div><?php }if($row->englishquestion==False){}else{ ?>
		<div class="content"><h4>Answers: <BR><?php if(($row->engoption1==FALSE) && ($row->engoption2==FALSE) && ($row->engoption3==FALSE) && ($row->engoption4==FALSE)) 
                                              { //echo $row->englishtrueans;
                                              echo $stuanstrue; ?><br>
                                              
                                         	  <input type='radio' id="englishtrueans1" name="englishtrueans" value="True" <?php if($stuanstrue==$row->englishtrueans){echo "checked='checked'";} ?> onclick="selectone()">True<BR>
                                              <input type='radio' id="englishtrueans2" name="englishtrueans" value="False" <?php if($stuanstrue==$row->englishtrueans){echo "checked='checked'";} ?> onclick="selectone()">False<BR>
                                               <?php } 
                                               else { ?><br>
                                              <input type='radio' id="engoption1" name="engoption" value="<?php echo $row->engoption1; ?>" <?php if($stuans==$row->engoption1){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption1; ?><BR>
                                              <input type='radio' id="engoption2" name="engoption" value="<?php echo $row->engoption2; ?>" <?php if($stuans==$row->engoption2){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption2; ?><BR>
                                              <input type='radio' id="engoption3" name="engoption" value="<?php echo $row->engoption3; ?>" <?php if($stuans==$row->engoption3){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption3; ?><BR>
                                              <input type='radio' id="engoption4" name="engoption" value="<?php echo $row->engoption4; ?>" <?php if($stuans==$row->engoption4){echo "checked='checked'";} ?> onclick="selectcopyeng()"><?php echo $row->engoption4; ?><BR>                                                           
                                              <?php }}  ?></h4>  
        </div>
		<?php }   } ?>
		</div>
		<script type="text/javascript">

		    function selectone(){
					if(document.getElementById('englishtrueans1').checked==true){
						document.getElementById('hinditrueans1').checked=true;
					}
					if(document.getElementById('englishtrueans2').checked==true){
						document.getElementById('hinditrueans2').checked=true;
					}
		    }
		    function selecttwo(){
		    		if(document.getElementById('hinditrueans1').checked==true){
						document.getElementById('englishtrueans1').checked=true;
					}
					if(document.getElementById('hinditrueans2').checked==true){
						document.getElementById('englishtrueans2').checked=true;
					}
					
		    }


			function selectcopyeng(){


					
					

					if(document.getElementById('engoption1').checked==true){
						document.getElementById('hindioption1').checked=true;
					}

					if(document.getElementById('engoption2').checked==true){
						document.getElementById('hindioption2').checked=true;
					}

					if(document.getElementById('engoption3').checked==true){
						document.getElementById('hindioption3').checked=true;
					}

					if(document.getElementById('engoption4').checked==true){
						document.getElementById('hindioption4').checked=true;
					}
			}

			function selectcopy(){
				
						

					
				

					if(document.getElementById('hindioption1').checked==true){
						document.getElementById('engoption1').checked=true;
					}

					if(document.getElementById('hindioption2').checked==true){
						document.getElementById('engoption2').checked=true;
					}

					if(document.getElementById('hindioption3').checked==true){
						document.getElementById('engoption3').checked=true;
					}

					if(document.getElementById('hindioption4').checked==true){
						document.getElementById('engoption4').checked=true;
					}

					

					

					

				
			}
		</script>
		<?php if($row->englishquestion==False){echo "<div class='col-xs-5'></div>";} ?>
		<div class="col-xs-5">
			
			<?php
			$stuans="";
			$getoption="";
			$this->load->model("studentlogin_model");
			 foreach ($t->result() as $row) { ?>
				<?php
												foreach ($getans->result() as $rowans) {
													?>
													<?php $stringsans=$rowans->answer;
													
													 $newstr = explode("_",$stringsans);
														 $newtruestr = str_replace("","",$stringsans);
														if($row->englishquestion==false){

															
														//  $getoption1 = "hindioption1";
														//echo $getoption=$this->studentlogin_model->getrealoption($getoption1,$row->queansid);
														 //echo $newstr[0];
														 if($row->engrightoption=="engoption1"){
														 	 $getoption1 = "hindioption1";
														 	$getoption=$this->studentlogin_model->getrealoption($getoption1,$row->queansid);
														 	if($newstr[0]==$getoption){
														 		 $stuans=$newstr[0];
															 }
														 }	
														 if($row->engrightoption=="engoption2"){
														 	$getoption1 = "hindioption2";
														 	$getoption=$this->studentlogin_model->getrealoption($getoption1,$row->queansid);
														 	if($newstr[0]==$getoption){
														 		 $stuans=$newstr[0];
															 }
														 }	
														 if($row->engrightoption=="engoption3"){
														 	$getoption1 = "hindioption3";
														 	$getoption=$this->studentlogin_model->getrealoption($getoption1,$row->queansid);
														 	if($newstr[0]==$getoption){
														 		 $stuans=$newstr[0];
															 }
														 }	
														 if($row->engrightoption=="engoption4"){
														 	$getoption1 = "hindioption4";
														 	$getoption=$this->studentlogin_model->getrealoption($getoption1,$row->queansid);
														 	if($newstr[0]==false){
														 		if($newstr[0]==$getoption){
														 		 $stuans=$newstr[0];
														 		}
														 		else{

														 		}
															 }
														 }
														// echo $row->engrightoption;	
														 echo $stuans;

														 }
														 else{

															 	if($newstr[0]==$row->engoption1){
																 $stuans =  $newstr[0];
																}
																if($newstr[0]==$row->engoption2){
																	 $stuans =  $newstr[0];
																}
																if($newstr[0]==$row->engoption3){
																	 $stuans =  $newstr[0];
																}
																if($newstr[0]==$row->engoption4){
																	$stuans =  $newstr[0];
																}
																if($row->engoption1==false && $row->engoption2==false && $row->engoption3==false && $row->engoption4==false){
																	if($newstr[0]==$row->englishtrueans){
																		 $stuans = $newstr[0];
																	}

																}

															 }
														

														//echo $row->englishtrueans;
														//echo $newstr[0];
														
														
														
														

													 ?>
													<?php
												}
											 ?>
											 <?php if($row->hindiquestion==False){"";}else{ ?><h2>Hindi Questions</h2>
		<div class="content"><h4><B>प्रश्न:<div> <?php  echo $row->hindiquestion; ?></div></B></h4> </div> <?php }if($row->hindiquestion==False){}else{ ?>
		<div class="content"><h4>उत्तरे:<BR><div><?php if(($row->hindioption1==FALSE) && ($row->hindioption2==FALSE) && ($row->hindioption3==FALSE) && ($row->hindioption4==FALSE)) 
                                              {   	?><br>
                                              <input type='radio' id="hinditrueans1" name="hinditrueans" value="True" <?php  if($stuans==$row->englishtrueans){echo "checked='checked'";} ?> onclick="selecttwo()">सही<BR>
                                              <input type='radio' id="hinditrueans2" name="hinditrueans" value="False" <?php if($stuans==$row->englishtrueans){echo "checked='checked'";} ?> onclick="selecttwo()">ग़लत<BR>
                                               <?php } 
                                               else { 

                                               	if($row->englishquestion==false){
echo $stuans;
                                               		?><br>
                                              <input type='radio' id="hindioption1" name="hindioption" value="<?php echo $row->hindioption1; ?>" <?php if($stuans==$row->hindioption1){echo "checked='checked'";} ?> onclick="selectcopy()"><?php echo $row->hindioption1; ?><BR>
                                              <input type='radio' id="hindioption2" name="hindioption" value="<?php echo $row->hindioption2; ?>" <?php if($stuans==$row->hindioption2){echo "checked='checked'";} ?> onclick="selectcopy()"><?php echo $row->hindioption2; ?><BR>
                                              <input type='radio' id="hindioption3" name="hindioption" value="<?php echo $row->hindioption3; ?>" <?php if($stuans==$row->hindioption3){echo "checked='checked'";} ?> onclick="selectcopy()"><?php echo $row->hindioption3; ?><BR>
                                              <input type='radio' id="hindioption4" name="hindioption" value="<?php echo $row->hindioption4; ?>" <?php if($stuans==$row->hindioption4){echo "checked='checked'";} ?> onclick="selectcopy()"><?php echo $row->hindioption4; ?><BR>
                                              <?php }else{
                                              	?>
                                              	<br>
                                              <input type='radio' id="hindioption1" name="hindioption" value="<?php echo $row->engoption1; ?>" <?php if($stuans==$row->engoption1){echo "checked='checked'";} ?> onclick="selectcopy()"><?php echo $row->hindioption1; ?><BR>
                                              <input type='radio' id="hindioption2" name="hindioption" value="<?php echo $row->engoption2; ?>" <?php if($stuans==$row->engoption2){echo "checked='checked'";} ?> onclick="selectcopy()"><?php echo $row->hindioption2; ?><BR>
                                              <input type='radio' id="hindioption3" name="hindioption" value="<?php echo $row->engoption3; ?>" <?php if($stuans==$row->engoption3){echo "checked='checked'";} ?> onclick="selectcopy()"><?php echo $row->hindioption3; ?><BR>
                                              <input type='radio' id="hindioption4" name="hindioption" value="<?php echo $row->engoption4; ?>" <?php if($stuans==$row->engoption4){echo "checked='checked'";} ?> onclick="selectcopy()"><?php echo $row->hindioption4; ?><BR>
                                              <?php
                                              	}} }  ?></div> </h4></div>	
		<?php } ?>
		</div>
	</div>
</div>
<div class="container-fluid" style="height: 70px; background-color: #4D4D4D">
	<div class="col-xs-4"></div>
	<div class="col-xs-4"></div>
	<?php echo "<input type='hidden' value='".$courseid."' name='courseid' id='courseid'/>"; ?>
	<?php echo "<input type='hidden' value='".$testid."' name='testid' id='testid'/>"; ?>

	<div class="col-xs-4"><input class="btn btn-success" type="submit" value="previous" name="previous" id="previous" onclick="getvalue()">&nbsp;<input class="btn btn-success" value="next" type="submit" name="next" id="next" onclick="getvalue()">&nbsp;<input type="submit" class="btn btn-danger hideshow" value="Finish" name="submittest" id="submittest" style="margin-left:30%"></div>
	<script type="text/javascript">
		function getvalue(){
			document.getElementById('username').value = document.getElementById('username1').value ;
		}
	</script>
</div>
</form>
</body>
</html>