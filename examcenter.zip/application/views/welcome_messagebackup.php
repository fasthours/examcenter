<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style type="text/css">





h1 {
  -webkit-animation: fadein 10s; /* Safari, Chrome and Opera > 12.1 */
       -moz-animation: fadein 10s; /* Firefox < 16 */
        -ms-animation: fadein 10s; /* Internet Explorer */
         -o-animation: fadein 10s; /* Opera < 12.1 */
            animation: fadein 10s;
}
@keyframes fadein {
    from { opacity: 0; }
    to   { opacity: 1; }
}

/* Firefox < 16 */
@-moz-keyframes fadein {
    from { opacity: 0; }
    to   { opacity: 1; }
}

/* Safari, Chrome and Opera > 12.1 */
@-webkit-keyframes fadein {
    from { opacity: 0; }
    to   { opacity: 1; }
}

/* Internet Explorer */
@-ms-keyframes fadein {
    from { opacity: 0; }
    to   { opacity: 1; }
}

/* Opera < 12.1 */
@-o-keyframes fadein {
    from { opacity: 0; }
    to   { opacity: 1; }
}

body {
    background-image: url('<?php echo base_url('/assets/images/com.jpg'); ?>') ,url('<?php echo base_url('/assets/images/globe.jpg'); ?>');
    background-repeat: repeat-y ,repeat-y;
   
    background-position: 0 0,right bottom;

   
}

  </style>
</head>
<body>
<div class="container" >
	<div class="col-lg-12" style="border-bottom: gray 2px solid; padding-bottom: 2px; padding-top: 2px">
		<div class="row">
			<div class="col-lg-3">
				<img src="<?php echo base_url('/assets/images/3.jpg'); ?>" alt="logo" class="img-responsive">
			</div>
			<div class="col-lg-6" style="background-image: url('<?php echo base_url('/assets/images/edu.gif'); ?>')">
				<div class="page-header">
				    <h1 style="font-size: 50px;color:white;">Jaya Computer Institute</h1>				   
				 </div>
				 <div><h2 class="content" style="color:orange;"><center>Online Exam Center</center></h2></div>
			</div>
			<div class="col-lg-3 panel" style="padding-top:14px">
				<address>
				  <strong>ADDRESS:</strong><br>
				  <span class="glyphicon glyphicon-home"></span> H.No. 69, HABIBPUR VIP ROAD NEAR TAMBESHWAR MANDIR <br>
				 DIST.: FATEHPUR<br > PI14CODE- 212601 (UP) <br>
				  <abbr title="Phone"><span class="glyphicon glyphicon-phone"></span> 9839624498, </abbr><i class="fa fa-whatsapp"></i>7704051508
				</address>
			</div>
		</div>
	</div>
	
	
	

</div>
<div class="container" >

<div class="row" style="background-image: url('<?php echo base_url('/assets/images/grade1.png'); ?>')">
	<div class="col-lg-6" style="border-right: gray 1px solid; padding-bottom: 120px">
		<h1><font color="red">Exam Instructions</font></h1>
		<h7><ol>
		<li> Time allowed for exam: 2 hours </li>
		<li> The clock will be set at the server. The countdown timer in the top right corner of screen will display the remaining time available for you to complete the exam. When the timer riches zero, the examination will end by itself. You will not be required to end or submit your examination.</li>
		<li> The question palette displayed on the left side of screen will show the status of each question using one of the following colors.
			<ol><li> <label style="color: #808080">Grey</label>- You have not visited the question yet.</li>
			<li> <label style="color: #FF0000">Red</label>- You have not answered the question.</li>
			<li> <label style="color: #008000">Green</label>- You have answerd the question.</li></ol></li>
		<li> Allowed materials: Pencil </li>
		<li> Not allowed: Textbook, keyboard, cell phone</li>
		<li> Exam is available: 2/26/2017 12:00am</li>
		</ol></h7>
	</div>
		<div class="col-lg-6">
		<div class="row" style="border-bottom: gray 1px solid; ">
			<div class="col-lg-6" style="border-right: gray 1px solid; padding-bottom: 80px">
				<center><h2>STUDENT</h2></center>
				<div class="form-group">
                    <label>Enrollment No:</label>
                    <input type="text" class="form-control" name="enno" id="enno" placeholder="Enter Enrollment No" required="">
                </div>
                <div class="form-group">
                    <label>Password:</label>
                    <input type="pasword" class="form-control" name="password" id="password" placeholder="Enter Password" required="">
                </div>
                <center>
                <button type="submit" class="btn btn-default">Submit</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <button type="reset" class="btn btn-default">Reset</button>
                </center>
			</div>

			<div class="col-lg-6">
				<center><h2>ADMIN</h2></center>
				<div class="form-group">
                    <label>Username:</label>
                    <input type="text" class="form-control" name="username" id="username" placeholder="Enter Username" required="">
                </div>
                <div class="form-group">
                    <label>Password:</label>
                    <input type="pasword" class="form-control" name="apassword" id="apassword" placeholder="Enter Password" required="">
                </div>
                <center>
                <a href="<?php echo base_url('/index.php/Welcome/adminmenu'); ?>" class="btn btn-default">Submit</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <button type="reset" class="btn btn-default">Reset</button>
                </center>
                <div class="checkbox">
                  <label><input type="checkbox"> Remember me</label>
                </div>
                <p>forgot your password? <a href="#">click here</a></p>
			</div>
		</div>
		
		<div>
		<marquee>
		<div class="col-lg-2" style="padding-top: 30px; padding-bottom: 20px;  ">
				<img src="student1.jpg" alt="photo"  width="100" height="100">
		</div>
		<div class="col-lg-2" style="padding-top: 30px; padding-bottom: 20px;">
				<img src="student1.jpg" alt="photo"  width="100" height="100">
		</div>
		<div class="col-lg-2" style="padding-top: 30px; padding-bottom: 20px; ">
				<img src="student1.jpg" alt="photo" width="100" height="100">
		</div>
		<div class="col-lg-2" style="padding-top: 30px; padding-bottom: 20px;">
				<img src="student1.jpg" alt="photo" width="100" height="100">
		</div>
		<div class="col-lg-2" style="padding-top: 30px; padding-bottom: 20px; ">
				<img src="student1.jpg" alt="photo" width="100" height="100">
		</div>
		</marquee>
		
		</div>
			
	</div>
</div>

</div>



</body>
</html>