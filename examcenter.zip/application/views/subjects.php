<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ExamCenter</title>
    <!-- Bootstrap Styles-->
    <link href="<?php echo base_url('adminasset/css/bootstrap.css'); ?>" rel="stylesheet" />
    <!-- FontAwesome Styles-->
    <link href="<?php echo base_url('adminasset/css/font-awesome.css'); ?>" rel="stylesheet" />
    <!-- Morris Chart Styles-->
    <link href="<?php echo base_url('adminasset/js/morris/morris-0.4.3.min.css');?> " rel="stylesheet" />
    <!-- Custom Styles-->
    <link href="<?php echo base_url('adminasset/css/custom-styles.css');?>" rel="stylesheet" />
    <!-- Google Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<style type="text/css">
    .css-serial {
 counter-reset: serial-number; /* Set the serial number counter to 0 */
}
.css-serial td:first-child:before {
 counter-increment: serial-number; /* Increment the serial number counter */
 content: counter(serial-number); /* Display the counter */
}
</style>

<body>
    <div id="wrapper">
        <?php $this->load->view('uppermenu.php'); ?>
        <!--/. NAV TOP  -->
        <?php  $this->load->view('sidemenu.php'); ?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">


                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Course <small>Enter Course Details</small>
                        </h1>
                    </div>
                </div>
                <!-- /. ROW  -->

                <div class="row">
                 <form role="form" action="<?php echo site_url('Subject/subject_name'); ?>" method="post">
                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Course Name</label>
                                            <input class="form-control" name="subjectname" id="subjectname">         

                                        </div>
                                         <input type="hidden" name="todaya" id="todaya" value="<?php echo date('Y/m/d H:i:s'); ?>">
                                        <button type="submit" class="btn btn-default">Submit Button</button>
                                        <button type="reset" class="btn btn-default">Reset Button</button>
                    </div> 
                    <div class="col-lg-6">
                        <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             Advanced Tables
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover css-serial" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>No</th>                                            
                                            <th>Course Detials</th>
                                                   
                                            <th>Edit / Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php  
                                    //count for model purpose
                                        $count =1;
                                    //end of count for model purpose
                                        foreach ($h->result() as $row) 
                                        {  
                                         ?><tr class="odd gradeX">
                                            <td></td>                     
                                            <td><?php echo $row->subjectname;?>
                                              <!-- passing value to model -->
                                                <input type="hidden" name="shrika<?php echo $count; ?>" id="shrika<?php echo $count; ?>" value="<?php echo $row->subjectname;?>" />
                                                 <input type="hidden" name="subjectid<?php echo $count; ?>" id="subjectid<?php echo $count; ?>" value="<?php echo $row->subjectid;?>">
                                              <!-- end of passing value to model -->  

                                            </td>             
                                                                 
                                             <td class="center"> <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#myModal" onclick="document.getElementById('subjectnamemodel').value=document.getElementById('shrika<?php echo $count; ?>').value; document.getElementById('subjectidmodel').value=document.getElementById('subjectid<?php echo $count; ?>').value;">Update</button></td>
                                        </tr>
                                        <?php $count++; } ?>   
                                        
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                    </div>                   
                  </form>  

                    
                    <!-- START ORIGINAL MODEL HERE-->
                        <div class="modal fade" id="myModal" role="dialog">
                                <div class="modal-dialog">
                
                                <!-- Modal content-->
                                <div class="modal-content">
                                <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                    <h4 class="modal-title">Enter Course Details</h4>
                                </div>
                                <div class="modal-body">
                                <form action="<?php echo base_url('index.php/Subject/editsubject_name'); ?>" method="post">
                     
                                                    <div class="form-group">
                                                    <label>Subject Name *</label>
                                                    <input class="form-control" name="subjectnamemodel" id="subjectnamemodel" required="required">
                                                    <input type="hidden" name="subjectidmodel" id="subjectidmodel">         
                                                    </div>
                                                    <input type="hidden" name="todayamodel" id="todayamodel" value="<?php echo date('Y/m/d H:i:s'); ?>">
                                                    <div class="form-group">
                                            <input type="submit" class="btn btn-warning" data-dimiss="modal" value="Update" name="update" id="update">
                                        </div>
                                        <div class="form-group">
                                            <input type="submit" class="btn btn-danger" data-dimiss="modal" value="Delete" name="delete" id="delete">
                                        </div>
                                </form>                    
                               
                                </div>
                                <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                </div>
                                </div>
                                </div>
                    </div> 
                    <!-- END OF ORIGINAL MODEL HERE -->

                 </div>
                 <!-- /.Row -->
                <!-- /. ROW  -->
				<footer><p>All right reserved. Template by: <a href="http://webthemez.com">WebThemez</a></p></footer>
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="<?php echo base_url('adminasset/js/jquery-1.10.2.js'); ?>"></script>
    <!-- Bootstrap Js -->
    <script src="<?php echo base_url('adminasset/js/bootstrap.min.js'); ?>"></script>
    <!-- Metis Menu Js -->
    <script src="<?php echo base_url('adminasset/js/jquery.metisMenu.js'); ?>"></script>
    <!-- Morris Chart Js -->
    <script src="<?php echo base_url('adminasset/js/morris/raphael-2.1.0.min.js'); ?>"></script>
    <script src="<?php echo base_url('adminasset/js/morris/morris.js'); ?>"></script>
    <script src="<?php echo base_url('adminasset/js/jquery.metisMenu.js');?>"></script>
    <script src="<?php echo base_url('adminasset/js/dataTables/jquery.dataTables.js');?>"></script>
    <script src="<?php echo base_url('adminasset/js/dataTables/dataTables.bootstrap.js') ?>"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
    <!-- Custom Js -->
    <script src="<?php echo base_url('adminasset/js/custom-scripts.js'); ?>"></script>


</body>

</html>