<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ExamCenter</title>
    <!-- Bootstrap Styles-->
    <link href="<?php echo base_url('adminasset/css/bootstrap.css'); ?>" rel="stylesheet" />
    <!-- FontAwesome Styles-->
    <link href="<?php echo base_url('adminasset/css/font-awesome.css'); ?>" rel="stylesheet" />
    <!-- Morris Chart Styles-->
    <link href="<?php echo base_url('adminasset/js/morris/morris-0.4.3.min.css');?> " rel="stylesheet" />
    <!-- Custom Styles-->
    <link href="<?php echo base_url('adminasset/css/custom-styles.css');?>" rel="stylesheet" />
    <!-- Google Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <script type="text/javascript">
    $(document).ready(function(){
    jQuery('.numbersOnly').keyup(function () { 
    this.value = this.value.replace(/[^0-9\.]/g,'');
    });
    });

    
  </script>
</head>

<body>
    <div id="wrapper">
        <?php $this->load->view('uppermenu.php'); ?>
        <!--/. NAV TOP  -->
        <?php  $this->load->view('sidemenu.php'); ?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">


                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Students <small>Enter Student Details</small>
                        </h1>
                    </div>
                </div>
                <!-- /. ROW  -->

                <div class="row">
               <form action="<?php echo site_url('Student/student_details'); ?>" method="post" name="student" enctype="multipart/form-data">
                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Student Full Name *</label>
                                            <input class="form-control" name="name" id="name" onkeypress="return onlyAlphabets(event,this);" required="required">         

                                        </div>
                                        <script type="text/javascript">
                                            function makesance(){
                                                document.getElementById('allid').value="";
                                               <?php 
                                                 foreach ($sj-> result() as $row2) { ?>
                                                    var me;
                                                       if(me = document.getElementById('<?php echo $row2->subjectname.$row2->subjectid; ?>').checked);
                                                       {
                                                            if(me==true){
                                                               //alert(document.getElementById('<?php echo $row2->subjectname.$row2->subjectid; ?>').checked);
                                                                document.getElementById('allid').value = document.getElementById('allid').value +","+ "<?php echo $row2->subjectid; ?>";
                                                             }
                                                       }

                                                    
                                               <?php  } ?>
                                            }
                                        </script>
                                         <div class="form-group">
                                            <label>Course Name *</label>
                                    
                                            <?php  foreach ($sj-> result() as $row2) { ?>
                                               <input type="checkbox" name="<?php echo $row2->subjectname.$row2->subjectid; ?>" id="<?php echo $row2->subjectname.$row2->subjectid; ?>" value="<?php echo $row2->subjectid; ?>" onchange="makesance();">
                                               <?php echo $row2->subjectname; ?>
                                            <?php } ?>
                                            <input type="hidden" value="" name="allid" id="allid">
                                        </div>
                                        <div class="form-group">
                                            <label>Address</label>
                                            <textarea class="form-control" name="address" id="address" rows="3"></textarea>              

                                        </div>
                                        <div class="form-group">
                                            <label>Contact *</label>
                                            <input class="form-control" name="contactno" id="contactno" required="required">         

                                        </div>
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input class="form-control" name="email" id="email" required="required">         

                                        </div>
                                        <div class="form-group">
                                            <label>Enrollment *</label>
                                            <input class="form-control" name="enrollmentno" id="enrollmentno" required="required">         

                                        </div>
                                        <div class="form-group">
                                            <label>Photo</label>
                                            <input class="form-control" type="file" name="photo" id="photo" accept="image/JPEG">         

                                        </div>
                                         <div class="form-group">
                                            <label>Password</label>
                                            <input class="form-control" name="password" id="password" value="<?php echo(rand(11111,99999)); ?>">         
                                             <input type="hidden" name="todaya" id="todaya" value="<?php echo date('Y/m/d H:i:s'); ?>">
                                        </div>
                                        <input type="submit" class="btn btn-default" value="Submit Button" name="save" id="save">
                                        <button type="reset" class="btn btn-default">Reset Button</button>
                    </div> 
                    </form>
                     


                 

                 </div>
                 <!-- /.Row -->
                <!-- /. ROW  -->
				<?php $this->load->view("footer.php"); ?>
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="<?php echo base_url('adminasset/js/jquery-1.10.2.js'); ?>"></script>
    <!-- Bootstrap Js -->
    <script src="<?php echo base_url('adminasset/js/bootstrap.min.js'); ?>"></script>
    <!-- Metis Menu Js -->
    <script src="<?php echo base_url('adminasset/js/jquery.metisMenu.js'); ?>"></script>
    <!-- Morris Chart Js -->
    <script src="<?php echo base_url('adminasset/js/morris/raphael-2.1.0.min.js'); ?>"></script>
    <script src="<?php echo base_url('adminasset/js/morris/morris.js'); ?>"></script>
    <script src="<?php echo base_url('adminasset/js/jquery.metisMenu.js');?>"></script>
    <script src="<?php echo base_url('adminasset/js/dataTables/jquery.dataTables.js');?>"></script>
    <script src="<?php echo base_url('adminasset/js/dataTables/dataTables.bootstrap.js') ?>"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
    <!-- Custom Js -->
    <script src="<?php echo base_url('adminasset/js/custom-scripts.js'); ?>"></script>


</body>

</html>