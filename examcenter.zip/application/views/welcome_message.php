<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.min.css");?>">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">  
  <link rel="stylesheet" href="<?php echo base_url('assets/css/mycss.css');?>">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  
<style type="text/css">
@font-face{
  font-family :"marathifont";
  src:url('<?php echo base_url('assets/fonts/DVSR0XTT.ttf') ?>');
}

@font-face {
    font-family: "myFirstFont";
    /*src: url('sansation_light.woff');*/
    src:url('<?php echo base_url('assets/fonts/COOPBL.ttf') ?>');
}
@font-face{
  font-family: "mysecondfont";
  src:url('<?php echo base_url('assets/fonts/ufonts.com_arial-narrow.ttf') ?>');
}
@font-face{
  font-family: "mythirdfont";
  src:url('<?php echo base_url('assets/fonts/calibril.ttf') ?>');
}
.ddback{
  background-image: url('<?php echo base_url('assets/images/background.png'); ?>'); background-repeat: no-repeat;
  background-size: 100% 100%;
}


 </style> 
</head>
<body>


    <div class="container-fluid" style="background-color: #cccccc;">     
      <div class="headerbackground"><img src="<?php echo base_url('assets/images/headerbackground.png'); ?>" class="image-responsive" width="80%"></div>
      <div class="logo"><img src="<?php echo base_url('assets/images/JayaName.png'); ?>" class="image-responsive" width="50%"></div>
      <div class="logo1"><img src="<?php echo base_url('assets/images/logo.png'); ?>" class="image-responsive" width="48%"></div>
      <div class="address"><img src="<?php echo base_url('assets/images/comtextaddress.png'); ?>" class="image-responsive" width="63%"></div>
    </div>
   <div class="container-fluid" id="textonlineexamcenter" style="background-color: #4D4D4D;">
    <center><div class="row">Online Exam Center</div></center>
   </div> 
   <div class="container-fluid hidden-sm hidden-md hidden-lg" style="background-color: #4D4D4D">
    <div class="row">
     
      <div class="col-xs-6">
        <center><img src="<?php echo base_url('assets/images/student.png'); ?>" class="image-responsive" width="50%"></center>
        <div class="rectangle">
          
        <form action="<?php echo site_url('Selectcourse_test/login'); ?>" method="post">
            
            <div class="form-group">
            <lable class="enroll">Enrollment No.:</lable>
            <input type="text" class="form-control input-xs" name="enrollmentno" id="enrollmentno">
            </div>
            <div class="form-group" style="margin-top:-10px">
            <lable class="enroll">Password.:</lable>
            <input type="password" class="form-control input-xs" name="passwordstud" id="passwordstud">
            </div>
            <div class="form-group" style="margin-top:-10px">
           
            <input type="submit" value="submit" class="form-control input-xs buttons">
            </div>
            <div class="form-group" style="margin-top:-10px">
           
            <input type="reset" value="reset" class="form-control input-xs buttons">
            </div>
            
          </form>
   
        </div>
      </div>
      <div class="col-xs-6">
      <center><img src="<?php echo base_url('assets/images/Admin.png'); ?>" class="image-responsive" width="50%"></center>
      <div class="rectangle">
        <form action="<?php echo site_url('Welcome/login'); ?>">
            <div class="form-group">
            <lable class="enroll">Username</lable>
            <input type="text" class="form-control input-sm" name="enrollmentno" id="enrollmentno">
            </div>
            <div class="form-group" style="margin-top:-10px">
            <lable class="enroll">Password.:</lable>
            <input type="password" class="form-control input-sm" name="password" id="password">
            </div>
             <div class="form-group" style="margin-top:-10px">
           
            <input type="submit" value="submit" class="form-control input-xs buttons">
            </div>
            <div class="form-group" style="margin-top:-10px">
           
            <input type="reset" value="reset" class="form-control input-xs buttons">
            </div>
            
          </form>
       </div>   
      </div>
      <div class="col-xs-12">
        Page Instruction
        <ol>
          <li>shrika</li>
          <li>shrika1</li>
          <li>shrika2</li>
          <li>shrika3</li>
        </ol>
      </div>
    </div>
     
   </div>
    <div class="container-fluid hidden-xs" style="background-color: #4D4D4D">
    <div class="row">
      <div class="col-xs-4">PAGE INSTRUCTIONS</div>
      <div class="col-xs-4">
        <center><img src="<?php echo base_url('assets/images/student.png'); ?>" class="image-responsive" width="50%"></center>
        <div class="rectangle">
          
             <form action="<?php echo site_url('Selectcourse_test/login'); ?>" method="post">
            <div class="form-group">
            <lable class="enroll">Enrollment No.:</lable>
            <input type="text" class="form-control input-xs" name="enrollmentno" id="enrollmentno">
            </div>
            <div class="form-group" style="margin-top:-10px">
            <lable class="enroll">Password.:</lable>
            <input type="password" class="form-control input-xs" name="passwordstud" id="passwordstud">
            </div>
            <div class="form-group" style="margin-top:-10px">
           
            <input type="submit" value="submit" class="form-control input-xs buttons">
            </div>
            <div class="form-group" style="margin-top:-10px">
           
            <input type="reset" value="reset" class="form-control input-xs buttons">
            </div>
            
          </form>
   
        </div>
      </div>
      <div class="col-xs-4">
      <center><img src="<?php echo base_url('assets/images/Admin.png'); ?>" class="image-responsive" width="50%"></center>
      <div class="rectangle">
         <form action="<?php echo site_url('Welcome/login'); ?>" method="post">
            <div class="form-group">
            <lable class="enroll">Username</lable>
            <input type="text" class="form-control input-sm" name="enrollmentno" id="enrollmentno">
            </div>
            <div class="form-group" style="margin-top:-10px">
            <lable class="enroll">Password.:</lable>
            <input type="password" class="form-control input-sm" name="password" id="password">
            </div>
             <div class="form-group" style="margin-top:-10px">
           
            <input type="submit" value="submit" class="form-control input-xs buttons">
            </div>
            <div class="form-group" style="margin-top:-10px">
           
            <input type="reset" value="reset" class="form-control input-xs buttons">
            </div>
            
          </form>
       </div>   
      </div>
    </div>
     
   </div>
    <div class="container-fluid ddback hideme hidden-lg hidden-md hidden-sm" style="margin-top:0px; height: 200px">
       
        <div class="col-xs-12">
          <div class="col-xs-2"></div>
          <div class="col-xs-8">
            <div class="rectangle"><center><img src="<?php echo base_url('assets/images/student.jpg'); ?>" class="img-responsive"></center></div>
            <div><center>Director</center></div>
            <div><center>Anil Patel</center></div>
            <div><center>Institute Teacher</center></div>
          </div>
          <div class="col-xs-2"></div>
        </div>
        <div class="col-xs-12">
          <div class="col-xs-2"></div>
          <div class="col-xs-8">
            <div class="rectangle"><center><img src="<?php echo base_url('assets/images/student.jpg'); ?>" class="img-responsive"></center></div>
            <div><center>Director</center></div>
            <div><center>Anil Patel</center></div>
            <div><center>Institute Teacher</center></div>
          </div>
          <div class="col-xs-2"></div>
        </div>
        <div class="col-xs-12">
          <div class="col-xs-2"></div>
          <div class="col-xs-8">
            <div class="rectangle"><center><img src="<?php echo base_url('assets/images/student.jpg'); ?>" class="img-responsive"></center></div>
            <div><center>Director</center></div>
            <div><center>Anil Patel</center></div>
            <div><center>Institute Teacher</center></div>
          </div>
          <div class="col-xs-2"></div>
        </div>
    </div>

    <div class="container-fluid ddback hideme hidden-xs" style="margin-top:0px; padding-top:10px; padding-bottom: 200px">
        <div class="col-xs-6"></div>
        <div class="col-xs-2" style="margin-top: 10px;">
          <div class="rectangle">
            <img src="<?php echo base_url('assets/images/student.jpg'); ?>" class="img-responsive">
          </div>
          <div><center>Director</center></div>
          <div><center>Anil Patel</center></div>
          <div><center>Institute Teacher</center></div>
          </div>
        <div class="col-xs-2" style="margin-top: 10px;">
          <div class="rectangle">
            <img src="<?php echo base_url('assets/images/student.jpg'); ?>" class="img-responsive">
          </div>
          <div><center>Designing</center></div>
          <div><center>Gangavishnu</center></div>
          <div><center>Artist Callygraphy</center></div>
        </div>
        <div class="col-xs-2" style="margin-top: 10px;">
          <div class="rectangle">
            <img src="<?php echo base_url('assets/images/student.jpg'); ?>" class="img-responsive">
          </div>
          <div><center>Development</center></div>
          <div><center>S.K.Gacche</center></div>
          <div><center>I.T. Director</center></div>
        </div>
    </div>

  <div class="container-fluid hideme hidden-xs" style="background-color: #4D4D4D;height: 250px">
    <div class="ccc"><img src="<?php echo base_url('assets/images/ccc.png'); ?>" class="image-responsive" width="60%"></div>
  </div>

  <div class="container-fluid hideme" style="background-color: #92AE1A;height: 50px">
  
  </div>



</body>
</html>