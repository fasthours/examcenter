<nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                    <li>
                        <a class="active-menu" href="<?php echo base_url("index.php/Welcome/adminmenu"); ?>"><i class="fa fa-dashboard"></i> Dashboard</a>
                    </li>
                     <li>
                        <a href="#"><i class="fa fa-sitemap"></i> Masters<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">                          
                            <li>
                                <a href="<?php echo base_url("index.php/Subject"); ?>">Course</a>
                            </li>
                              <li>
                                <a href="<?php echo base_url("index.php/Student"); ?>">Student</a>
                            </li>
                             <li>
                                <a href="<?php echo base_url("index.php/Test"); ?>">Test</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url("index.php/Questions"); ?>">Question/Answer</a>
                            </li>
                            
                        </ul>
                    </li>
					<li>
                        <a href="#"><i class="fa fa-sitemap"></i> Reports</a>
                        <ul class="nav nav-second-level">                          
                            <li>
                                <a href="<?php echo base_url("index.php/StudentReport"); ?>">Student Report</a>
                            </li>
                              <li>
                                <a href="<?php echo base_url("index.php/ExamReport"); ?>">Exam Report</a>
                            </li>
                              <li>
                                <a href="<?php echo base_url("index.php/StudentDetailsReport"); ?>">Student Details Report</a>
                            </li>
                            
                            
                        </ul>
                    </li>
                    


                    
                   
                </ul>

            </div>

        </nav>