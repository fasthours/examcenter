<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
   <!-- <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />-->
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    
    <title>ExamCenter</title>
    <!-- Bootstrap Styles-->
    <link href="<?php echo base_url('adminasset/css/bootstrap.css'); ?>" rel="stylesheet" />
    <!-- FontAwesome Styles-->
    <link href="<?php echo base_url('adminasset/css/font-awesome.css'); ?>" rel="stylesheet" />
    <!-- Morris Chart Styles-->
    <link href="<?php echo base_url('adminasset/js/morris/morris-0.4.3.min.css');?> " rel="stylesheet" />
    <!-- Custom Styles-->
    <link href="<?php echo base_url('adminasset/css/custom-styles.css');?>" rel="stylesheet" />
    <!-- Google Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <SCRIPT language=JavaScript src="<?php echo base_url('adminasset/js/common.js'); ?>"></SCRIPT>
<SCRIPT language=JavaScript src="<?php echo base_url('adminasset/js//hindi.js')?>"></SCRIPT>
<style>
.css-serial {
 counter-reset: serial-number; /* Set the serial number counter to 0 */
}
.css-serial td:first-child:before {
 counter-increment: serial-number; /* Increment the serial number counter */
 content: counter(serial-number); /* Display the counter */
}
<!--
/************** Font Declarations *********************************/
@font-face { src: url("<?php echo base_url('adminasset/fonts/HIMALAYA.ttf');?>"); font-family: "HIMALAYA";  }

/* @font-face {src: url("Osho.ttf");font-family: "Osho";}

@font-face {src: url("kalimati.ttf");font-family: "kalimati";}

@font-face {src: url("samanata.ttf");font-family: "samanata";}

@font-face {src: url("cdac.ttf");font-family: "cdac";}
*/
/*****************************************************************/



/*****************************************************************/
.gargi {    
    font: 1em 'gargi';

}


</style>


</head>

<body>
    <div id="wrapper">
        <?php $this->load->view('uppermenu.php'); ?>
        <!--/. NAV TOP  -->
        <?php  $this->load->view('sidemenu.php'); ?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">


                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Question/Answer <small>Enter Question/Answer Details</small>
                        </h1>
                    </div>
                </div>
                <!-- /. ROW  -->

                <div class="row">
                 



                    <div class="col-lg-12">
                    
                        <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <form action="<?php echo base_url('index.php/Questions/updatequestionanswer'); ?>" method="post">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                             <a href="<?php echo base_url('index.php/Questions/addquestion') ?>">Add New Question/Answer</a> 
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover css-serial" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>No</th>                                            
                                            <th>English Question</th>
                                            <th>Hindi Question</th>
                                                   
                                            <th>Edit / Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    <?php
                                      $count =1;
                                        foreach ($m->result() as $row)  
                                             { 
                                             ?> 
                                        <tr class="odd gradeX">
                                            <td></td>                     
                                            <td>
                                               <B>Question :- </B><BR> 
                                              <?php 
                                               echo $row->englishquestion;?><BR>
                                              <b>Answer :- </b><BR>
                                              <?php if(empty($row->engoption1 && $row->engoption2 && $row->engoption3 && $row->engoption4)) 
                                              { ?>
                                              1.True<BR>
                                              2.False<BR>
                                               <?php } 
                                               else { ?>
                                              1.<?php echo $row->engoption1; ?><BR>
                                              2.<?php echo $row->engoption2; ?><BR>
                                              3.<?php echo $row->engoption3; ?><BR>
                                              4.<?php echo $row->engoption4; ?><BR>
                                                                                          
                                              <?php }  ?>


                                              
                                               <input type="hidden" name="subjectidch<?php echo $count; ?>" id="subjectidch<?php echo $count; ?>" value="<?php echo $row->queansid; ?>">
                                            </td> 
                                            <td>
                                               <B>Question :- </B><BR> 
                                              <?php 
                                               echo $row->hindiquestion;?><BR>
                                              <b>Answer :- </b><BR>                                                                               
                                             
                                              <?php if(empty($row->hindioption1 && $row->hindioption2 && $row->hindioption3 && $row->hindioption4)) 
                                              { ?>
                                              1.True<BR>
                                              2.False<BR>
                                               <?php } 
                                               else { ?>
                                              1.<?php echo $row->hindioption1; ?><BR>
                                              2.<?php echo $row->hindioption2; ?><BR>
                                              3.<?php echo $row->hindioption3; ?><BR>
                                              4.<?php echo $row->hindioption4; ?><BR>
                                              <?php }   ?>
                                               
                                            </td>                     
                                                                 
                                            <td class="center"><input type="submit" value="Update" class="btn btn-info btn-sm" name="subjectids<?php echo $count; ?>" id="subjectids<?php echo $count; ?>"  onclick="
                                                document.getElementById('mynewvalue').value=document.getElementById('subjectidch<?php echo $count; ?>').value;"></td>
                                        </tr>
                                         <?php $count++; } ?>
                                        <input type="text" value="" name="mynewvalue" id="mynewvalue" style="display: none;">
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                    </div>                   
                  </form>  
                 </div>
                 <!-- /.Row -->
                <!-- /. ROW  -->
				<?php $this->load->view("footer.php"); ?>
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="<?php echo base_url('adminasset/js/jquery-1.10.2.js'); ?>"></script>
    <!-- Bootstrap Js -->
    <script src="<?php echo base_url('adminasset/js/bootstrap.min.js'); ?>"></script>
    <!-- Metis Menu Js -->
    <script src="<?php echo base_url('adminasset/js/jquery.metisMenu.js'); ?>"></script>
    <!-- Morris Chart Js -->
    <script src="<?php echo base_url('adminasset/js/morris/raphael-2.1.0.min.js'); ?>"></script>
    <script src="<?php echo base_url('adminasset/js/morris/morris.js'); ?>"></script>
    <script src="<?php echo base_url('adminasset/js/jquery.metisMenu.js');?>"></script>
    <script src="<?php echo base_url('adminasset/js/dataTables/jquery.dataTables.js');?>"></script>
    <script src="<?php echo base_url('adminasset/js/dataTables/dataTables.bootstrap.js') ?>"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
    <!-- Custom Js -->
    <script src="<?php echo base_url('adminasset/js/custom-scripts.js'); ?>"></script>


</body>

</html>