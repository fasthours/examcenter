<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style type="text/css">

body {
   background-color: #ffffff;   
}
.firstback{
  z-index: 0;
  height:110px;
  background-color: #f4f6f9;
}
.secondback{
  z-index: 0;
  height:130px;
  margin-top:4px;
  background-color: #d7dee8;
}
.thirdback{
  z-index: 0;
   height:50px;
  background-color: transparent;
}
.fourthback{
  z-index: 0;
  height:600px;
  background-color: #4D4D4D;
}
.fifthback{
  z-index: 0;
}
.sixthback{
  z-index: 0;
}
.secondlevel{
  z-index: 10;
}
.roundcircle{
    border-radius: 25px;
    border: 1px solid blue;
    padding-left: 12.5%;
    width: 80%;
    height: 400px;
    margin-top: -800px;
    
   /* background-color: #5B5F4A;*/
   background-color: transparent;
   
}
.thirdlevel{
  z-index: 20;
}
.roundcircleblackup{
    border-radius: 20px;
    border: 1px solid transparent;   
    width: 80%;
    height: 100px;
    margin-top:-35%;
    
    
   /* background-color: #5B5F4A;*/
   background-color: #4D4D4D;
   
}
.fourthlevel{
  z-index: 30;
}
.roundcirclegreenup{
    border-radius: 20px;
    border: 1px solid transparent;   
    width: 80%;
    height: 54px;
    margin-top:-9%;
    
    
   /* background-color: #5B5F4A;*/
   background-color: #92AE1A;
   
}
.fifthlevel{
  z-index: 40;
}
.alignment{position:relative;margin-top:-1%;}
    .leftarrow,.rightarrow{width:50%; position:absolute;}
    .rightarrow{right:-6.5%;}
    .leftarrow{left:-6.5%;}

.imagesalignment{position:relative;margin-top:60px;}
    .leftimage,.rightimage{width:50%; position:absolute;}
    .rightimage{right:0.5%;}
    .leftimage{left:18.5%;}   

.sixthlevel{
  z-index: 50;
}
.seventhlevel{
  z-index: 60;
}
.roundcircleblackdown{
    border-radius: 5px;
    border: 1px solid transparent;
    padding-left: 12.5%;
    width: 80%;
    height: 50px;
    margin-top: -11.8%;
    
   /* background-color: #5B5F4A;*/
   background-color: #92AE1A;
   
}
.roundcirclegreendown{
    border-radius: 25px;
    border: 1px solid transparent;
    padding-left: 12.5%;
    width: 80%;
    height: 135px;
    margin-top: 19.4%;
    
   /* background-color: #5B5F4A;*/
   background-color: black;
   
}

  </style>


</head>
<body>
  <div class="container">
	 <div class="firstback"></div>
   <div class="secondback"></div>
   <div class="thirdback"></div>
   <div class="fourthback"></div>
   <div class="fifthback"></div>
   <div class="sixthback"></div>
  
   <center><div class="secondlevel roundcircle"></div></center>
   <center><div class="thirdlevel roundcircleblackup"></div></center>
   <center><div class="fourthlevel roundcirclegreenup"></div></center>
   <center><div class="fifthlevel alignment"><div class="leftarrow"><img src="<?php echo base_url("assets/images/arrowright.png"); ?>" class="image-responsive" width="34%" /></div><div class="rightarrow"><img src="<?php echo base_url("assets/images/arrow.png"); ?>" class="image-responsive" width="34%" /></div></div></center>

    <center><div class="fifthlevel imagesalignment"><div class="leftimage"><img src="<?php echo base_url("assets/images/bannersir.jpg"); ?>" class="image-responsive" width="70%" /></div><div class="rightimage"><img src="<?php echo base_url("assets/images/banner2.jpg"); ?>" class="image-responsive" width="62%" /></div></div></center>
   <center><div class="sixthlevel roundcirclegreendown"></div></center>
    <center><div class="seventhlevel roundcircleblackdown"></div></center>
  </div>
</body>
</html>