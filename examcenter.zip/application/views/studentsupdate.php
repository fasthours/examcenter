<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ExamCenter</title>
    <!-- Bootstrap Styles-->
    <link href="<?php echo base_url('adminasset/css/bootstrap.css'); ?>" rel="stylesheet" />
    <!-- FontAwesome Styles-->
    <link href="<?php echo base_url('adminasset/css/font-awesome.css'); ?>" rel="stylesheet" />
    <!-- Morris Chart Styles-->
    <link href="<?php echo base_url('adminasset/js/morris/morris-0.4.3.min.css');?> " rel="stylesheet" />
    <!-- Custom Styles-->
    <link href="<?php echo base_url('adminasset/css/custom-styles.css');?>" rel="stylesheet" />
    <!-- Google Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <script type="text/javascript">
    $(document).ready(function(){
    jQuery('.numbersOnly').keyup(function () { 
    this.value = this.value.replace(/[^0-9\.]/g,'');
    });
    });

    
  </script>
</head>

<body onload="makesance()">
    <div id="wrapper">
        <?php $this->load->view('uppermenu.php'); ?>
        <!--/. NAV TOP  -->
        <?php  $this->load->view('sidemenu.php'); ?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">


                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Students <small>Enter Student Details</small>
                        </h1>
                    </div>
                </div>
                <!-- /. ROW  -->

                <div class="row">
               <form action="<?php echo base_url('index.php/Student/editstudent_name'); ?>" method="post" name="student" enctype="multipart/form-data">
          
                    <div class="col-lg-6">
                         <?php  
                                        $count=1;
                                             foreach ($h->result() as $row)  
                                             {  
                                                ?>
                                        <div class="form-group">
                                            <label>Student Full Name *</label>
                                            <input class="form-control" type="hidden" value="<?php echo $row->studentid; ?>" name="studentid" id="studentid">
                                            <input class="form-control" type="text" value="<?php echo $row->name; ?>" name="name" id="name" onkeypress="return onlyAlphabets(event,this);" >         

                                        </div>
                                        <?php $j=1; ?>
                                        <script type="text/javascript">
                                            function makesance(){
                                                if($j=1){

                                                }
                                                else{
                                                document.getElementById('subjectname').value="";
                                            }
                                               <?php 
                                                 foreach ($sj-> result() as $row2) { ?>
                                                    var me;
                                                       if(me = document.getElementById('<?php echo $row2->subjectname.$row2->subjectid; ?>').checked);
                                                       {

                                                            if(me==true){
                                                               //alert(document.getElementById('<?php echo $row2->subjectname.$row2->subjectid; ?>').checked);
                                                                document.getElementById('subjectname').value = document.getElementById('subjectname').value +","+ "<?php echo $row2->subjectid; ?>";
                                                             }
                                                             
                                                       }

                                                    
                                               <?php  } ?>
                                            }
                                        </script>
                                        <?php
                                           $getvaluemy = $row->subjectid;
                                           $datacount =  substr_count($getvaluemy, ",");
                                          // echo $datacount;
                                           $pieces = explode(",", $getvaluemy);
                                          // echo $datacount;

                                         ?>
                                         <div class="form-group">
                                            <label>Course Name *</label>
                                                <?php 
                                                $i=1;
                                                
                                                 ?>
                                                
                                                
                                            <?php  foreach ($sj->result() as $row2) { ?>                                
                                               <?php //echo $pieces[$i];

                                                for($i=1;$i<=$datacount;$i++){
                                               
                                                   if($pieces[$i]==$row2->subjectid){
                                                    echo "<input type='checkbox' checked='checked' name='".$row2->subjectname.$row2->subjectid."' id='".$row2->subjectname.$row2->subjectid."' onclick='makesance()'>"; }
                                                    else if($pieces[$i]!=$row2->subjectid){
                                                        
                                                    }
                                                  

                                                }
                                                 ?>
                                                   
                                                     <?php echo $row2->subjectname; ?>
                                        
                                               
                                            <?php } 
                                           ?>
                                            
                                        </div>
                                        <div class="form-group">
                                            <label>Address</label>
                                            <textarea class="form-control" name="address" id="address" rows="3"><?php echo $row->address; ?></textarea>              

                                        </div>
                                        <div class="form-group">
                                            <label>Contact *</label>
                                            <input class="form-control" name="contactno" id="contactno" value="<?php echo $row->contactno; ?>" required="required">         

                                        </div>
                                        <div class="form-group">
                                            <label>Email</label>
                                            <input class="form-control" name="email" id="email" value="<?php echo $row->email; ?>" required="required">         

                                        </div>
                                        <div class="form-group">
                                            <label>Enrollment *</label>
                                            <input class="form-control" readonly="readonly" name="enrollmentno" id="enrollmentno" value="<?php echo $row->enrollmentno; ?>" required="required">         

                                        </div>
                                        <div class="form-group">
                                          <img src="http://localhost/examcenter/uploads/<?php echo $row->photo; ?>" width="100" height="100">
                                          <input type="hidden" name="oldphoto" id="oldphoto" value="<?php echo $row->photo; ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Photo</label>
                                            <input class="form-control" type="file" name="photo" id="photo" value="" accept="image/JPEG">         

                                        </div>
                                         <div class="form-group">
                                            <label>Password</label>
                                            <input class="form-control" disabled="disabled" name="password" id="password" value="<?php echo $row->password; ?>">         
                                             <input type="hidden" name="todaya" id="todaya" value="<?php echo date('Y/m/d H:i:s'); ?>">
                                        </div>
                                        <input type="hidden" value="" name="subjectname" id="subjectname">
                                         <div class="form-group">
                                            <input type="submit" class="btn btn-warning" data-dimiss="modal" value="Update" name="update" id="update" >
                                       
                                            <input type="submit" class="btn btn-danger" data-dimiss="modal" value="Delete" name="delete" id="delete">
                                        </div>
                                        <?php
                                             $count++; }  
                                             ?>   
                    </div> 

                    
                    </form>
                 

                 </div>
                 <!-- /.Row -->
                <!-- /. ROW  -->
				<?php $this->load->view("footer.php"); ?>
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="<?php echo base_url('adminasset/js/jquery-1.10.2.js'); ?>"></script>
    <!-- Bootstrap Js -->
    <script src="<?php echo base_url('adminasset/js/bootstrap.min.js'); ?>"></script>
    <!-- Metis Menu Js -->
    <script src="<?php echo base_url('adminasset/js/jquery.metisMenu.js'); ?>"></script>
    <!-- Morris Chart Js -->
    <script src="<?php echo base_url('adminasset/js/morris/raphael-2.1.0.min.js'); ?>"></script>
    <script src="<?php echo base_url('adminasset/js/morris/morris.js'); ?>"></script>
    <script src="<?php echo base_url('adminasset/js/jquery.metisMenu.js');?>"></script>
    <script src="<?php echo base_url('adminasset/js/dataTables/jquery.dataTables.js');?>"></script>
    <script src="<?php echo base_url('adminasset/js/dataTables/dataTables.bootstrap.js') ?>"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
    <!-- Custom Js -->
    <script src="<?php echo base_url('adminasset/js/custom-scripts.js'); ?>"></script>


</body>

</html>