<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
   <!-- <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />-->
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    
    <title>ExamCenter</title>
    <!-- Bootstrap Styles-->
    <link href="<?php echo base_url('adminasset/css/bootstrap.css'); ?>" rel="stylesheet" />
    <!-- FontAwesome Styles-->
    <link href="<?php echo base_url('adminasset/css/font-awesome.css'); ?>" rel="stylesheet" />
    <!-- Morris Chart Styles-->
    <link href="<?php echo base_url('adminasset/js/morris/morris-0.4.3.min.css');?> " rel="stylesheet" />
    <!-- Custom Styles-->
    <link href="<?php echo base_url('adminasset/css/custom-styles.css');?>" rel="stylesheet" />
    <!-- Google Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <SCRIPT language=JavaScript src="<?php echo base_url('adminasset/js/common.js'); ?>"></SCRIPT>
<SCRIPT language=JavaScript src="<?php echo base_url('adminasset/js//hindi.js')?>"></SCRIPT>
<style>
 
<!--
/************** Font Declarations *********************************/
@font-face { src: url("<?php echo base_url('adminasset/fonts/HIMALAYA.ttf');?>"); font-family: "HIMALAYA";  }

/* @font-face {src: url("Osho.ttf");font-family: "Osho";}

@font-face {src: url("kalimati.ttf");font-family: "kalimati";}

@font-face {src: url("samanata.ttf");font-family: "samanata";}

@font-face {src: url("cdac.ttf");font-family: "cdac";}
*/
/*****************************************************************/



/*****************************************************************/
.gargi {    
    font: 1em 'gargi';

}


</style>


</head>

<body>
    <div id="wrapper">
        <?php $this->load->view('uppermenu.php'); ?>
        <!--/. NAV TOP  -->
        <?php  $this->load->view('sidemenu.php'); ?>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">


                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Question/Answer <small>Enter Question/Answer Details</small>
                        </h1>
                    </div>
                </div>
                <!-- /. ROW  -->

                <div class="row">
                 <form role="form" action="<?php echo base_url('index.php/Questions/editquestions'); ?>" method="post">
                    <div class="col-lg-12">
                      <div class="col-lg-6">
                          <div class="form-group">
                                            <label>Subject Name</label>
                                            <select class="form-control" name="subjectid" id="subjectid">
                                               <?php  
                                             foreach ($h->result() as $row)  
                                             { 
                                                foreach($s->result() as $row1)
                                                { 
                                                  if($row1->subjectid == $row->subjectid){
                                                ?>
                                                <option selected="selected" value="<?php echo $row->subjectid; ?>"><?php echo $row->subjectname; ?></option>
                                              <?php
                                            }
                                            else{
                                              ?>
                                                <option value="<?php echo $row->subjectid; ?>"><?php echo $row->subjectname; ?></option>
                                              <?php

                                            }

                                          }
                                        }
                                              ?>  
                                                                                            
                                            </select>
                                        </div>
                      </div>
                      <div class="col-lg-6">
                          <div class="form-group">
                                            <label>Test Name</label>
                                            <select class="form-control" name="testid" id="testid">
                                                 <?php  
                                             foreach ($k->result() as $row)  
                                             {  
                                              foreach ($s->result() as  $row1) {
                                               if($row1->testid == $row->testid){                                              
                                                ?>
                                                <option selected="selected" value="<?php echo $row->testid; ?>"><?php echo $row->testname; ?></option>
                                              <?php
                                            }else{
                                                 ?>
                                                <option selected="selected" value="<?php echo $row->testid; ?>"><?php echo $row->testname; ?></option>
                                              <?php
                                            }
                                          }
                                          }
                                              ?>  
                                            </select>
                                        </div>
                                        
                      </div>
                                      
                                      <?php foreach ($m->result() as $row1)  
                                             {   

                                              foreach ($s->result() as $row2)  
                                             {  

                                              if($row1->queansid == $row2->queansid){
                                                ?>
                                          <div class="form-group well">
                                          <ul class="nav nav-tabs">
                                            <li class="active"><a data-toggle="pill" href="#home">English</a></li>
                                            <li><a data-toggle="pill" href="#menu1">Hindi</a></li>                                           
                                          </ul>
                                          
                                          <div class="tab-content" style="padding-top:10px;">
                                                        
                                            <div id="home" class="tab-pane fade in active">
                                            <input type="hidden" value="<?php echo $row1->queansid; ?>" name="questionid" id="questionid">
                                                       <div class="form-group">
                                                            <label>Question</label>
                                                            <textarea  class="form-control" rows="3" id="englishquestion" name="englishquestion"><?php echo $row1->englishquestion; ?></textarea>  
                                                         </div>
                                                  <ul class="nav nav-tabs">
                                                    <li class="active"><a data-toggle="pill" href="#enquestion" style="padding-right: 300px;">Options</a></li>
                                                    <li><a data-toggle="pill" href="#enyesno">Yes/No Question</a></li>                                           
                                                  </ul>
                                                  <div class="tab-content">
                                                    <div id="enquestion" class="tab-pane fade in active">                                                          
                                                         <div class="form-group">
                                                            <label>Option1</label>
                                                            <input class="form-control" value="<?php echo $row1->engoption1;  ?>" name="engoption1" id="engoption1">         
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Option2</label>
                                                            <input class="form-control" value="<?php echo $row1->engoption2;  ?>" name="engoption2" id="engoption2">         
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Option3</label>
                                                            <input class="form-control" value="<?php echo $row1->engoption3;  ?>" name="engoption3" id="engoption3">         
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Option4</label>
                                                            <input class="form-control" value="<?php echo $row1->engoption4;  ?>" name="engoption4" id="engoption4">         
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Currect Answer</label>
                                                            <select name="engrightoption" id="engrightoption">
                                                            <?php if($row1->engrightoption=="engoption1"){ ?><option value="engoption1" selected="selected">Option1</option><?php }else { ?><option value="engoption1">Option1</option> <?php } ?> 
                                                            <?php if($row1->engrightoption=="engoption2"){ ?><option value="engoption2" selected="selected">Option2</option><?php }else { ?> <option value="engoption2">Option2</option>   <?php } ?>     
                                                            <?php if($row1->engrightoption=="engoption3"){ ?><option value="engoption3" selected="selected">Option3</option><?php }else { ?> <option value="engoption3">Option3</option> <?php } ?> 
                                                            <?php if($row1->engrightoption=="engoption4"){ ?> <option value="engoption4" selected="selected">Option4</option><?php }else { ?><option value="engoption4">Option4</option> <?php } ?> 
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div id="enyesno" class="tab-pane fade" style="padding-top: 10px">
                                                      <div class="form-group">
                                                           <label>
                                                                <input type="radio" name="englishtrueans" id="englishtrueans" value="True" checked="">True
                                                           </label>       
                                                        </div>
                                                        <div class="form-group">
                                                           <label>
                                                                <input type="radio" name="englishtrueans" id="englishtrueans" value="False" checked="">False
                                                           </label>       
                                                        </div>
                                                    </div>
                                                   
                                                 </div>
                                            </div>
                                                    <div id="menu1" class="tab-pane fade gargi">
                                                       <div class="form-group">
                                                            <label>Question</label>
                                                            <textarea class="form-control" name="hindiquestion" id="hindiquestion" charset="utf-8" onKeyDown="toggleKBMode(event)" onKeyPress="javascript:convertThis(event)"><?php echo $row1->hindiquestion; ?></textarea>
                                                         </div>
                                                  <ul class="nav nav-tabs">
                                                    <li class="active"><a data-toggle="pill" href="#enquestion1" style="padding-right: 300px;">Options</a></li>
                                                    <li><a data-toggle="pill" href="#enyesno1">Yes/No Question</a></li>                                           
                                                  </ul>
                                                  <div class="tab-content">
                                                    <div id="enquestion1" class="tab-pane fade in active">                                                           
                                                         <div class="form-group">
                                                            <label>Option1</label>
                                                            <input class="form-control" value="<?php echo $row1->hindioption1;  ?>" name="hindioption1" id="hindioption1" charset="utf-8" onKeyDown="toggleKBMode(event)" onKeyPress="javascript:convertThis(event)">         
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Option2</label>
                                                            <input class="form-control" value="<?php echo $row1->hindioption2;  ?>" name="hindioption2" id="hindioption2" charset="utf-8" onKeyDown="toggleKBMode(event)" onKeyPress="javascript:convertThis(event)">         
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Option3</label>
                                                            <input class="form-control" value="<?php echo $row1->hindioption3;  ?>" name="hindioption3" id="hindioption3" charset="utf-8" onKeyDown="toggleKBMode(event)" onKeyPress="javascript:convertThis(event)">         
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Option4</label>
                                                            <input class="form-control" value="<?php echo $row1->hindioption4;  ?>" name="hindioption4" id="hindioption4" charset="utf-8" onKeyDown="toggleKBMode(event)" onKeyPress="javascript:convertThis(event)">         
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Currect Answer</label>
                                                            <select name="hindirightoption" id="hindirightoption">
                                                           


                                                            <?php if($row1->hindirightoption=="hindioption1"){ ?><option value="hindioption1" selected="selected">Option1</option><?php }else { ?><option value="hindioption1">Option1</option> <?php } ?> 
                                                            <?php if($row1->hindirightoption=="hindioption2"){ ?><option value="hindioption2" selected="selected">Option2</option><?php }else { ?> <option value="hindioption2">Option2</option>   <?php } ?>     
                                                            <?php if($row1->hindirightoption=="hindioption3"){ ?><option value="engoption3" selected="selected">Option3</option><?php }else { ?> <option value="hindioption3">Option3</option> <?php } ?> 
                                                            <?php if($row1->hindirightoption=="hindioption4"){ ?> <option value="hindioption4" selected="selected">Option4</option><?php }else { ?><option value="hindioption4">Option4</option> <?php } ?> 
                                                        
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div id="enyesno1" class="tab-pane fade" sty  le="padding-top: 10px">
                                                      <div class="form-group">
                                                           <label>
                                                                <input type="radio" name="hinditrueans" id="hinditrueans" value="true" checked="">True
                                                           </label>       
                                                        </div>
                                                        <div class="form-group">
                                                           <label>
                                                                <input type="radio" name="hinditrueans" id="hinditrueans" value="false" checked="">False
                                                           </label>       
                                                        </div>
                                                    </div>
                                                   
                                                 </div>
                                                    </div>
                                                   
                                          </div>
                                        </div>
                                        <input type="hidden" name="todaya" id="todaya" value="<?php echo date('Y/m/d H:i:s'); ?>">
                                        <input type="submit" value="Update" name="update" id="update" class="btn btn-default">
                                        <input type="submit" value="Delete" name="delete" id="delete" class="btn btn-default">
                                        
                                        <?php
                                      }}}
                                        ?>
                    </div> 
                    </form>




                 </div>
                 <!-- /.Row -->
                <!-- /. ROW  -->
				<?php $this->load->view("footer.php"); ?>
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="<?php echo base_url('adminasset/js/jquery-1.10.2.js'); ?>"></script>
    <!-- Bootstrap Js -->
    <script src="<?php echo base_url('adminasset/js/bootstrap.min.js'); ?>"></script>
    <!-- Metis Menu Js -->
    <script src="<?php echo base_url('adminasset/js/jquery.metisMenu.js'); ?>"></script>
    <!-- Morris Chart Js -->
    <script src="<?php echo base_url('adminasset/js/morris/raphael-2.1.0.min.js'); ?>"></script>
    <script src="<?php echo base_url('adminasset/js/morris/morris.js'); ?>"></script>
    <script src="<?php echo base_url('adminasset/js/jquery.metisMenu.js');?>"></script>
    <script src="<?php echo base_url('adminasset/js/dataTables/jquery.dataTables.js');?>"></script>
    <script src="<?php echo base_url('adminasset/js/dataTables/dataTables.bootstrap.js') ?>"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
    <!-- Custom Js -->
    <script src="<?php echo base_url('adminasset/js/custom-scripts.js'); ?>"></script>


</body>

</html>