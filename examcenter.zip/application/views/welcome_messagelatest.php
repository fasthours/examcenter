<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
  <style type="text/css">
body{
  background-image: url('<?php echo base_url('assets/images/back.jpg'); ?>'); background-repeat: no-repeat;
}
/* starting of 1200 px style */

@font-face {
    font-family: "myFirstFont";
    /*src: url('sansation_light.woff');*/
    src:url('<?php echo base_url('assets/fonts/COOPBL.ttf') ?>');
}
@font-face{
  font-family: "mysecondfont";
  src:url('<?php echo base_url('assets/fonts/ufonts.com_arial-narrow.ttf') ?>');
}
@font-face{
  font-family: "mythirdfont";
  src:url('<?php echo base_url('assets/fonts/calibril.ttf') ?>');
}
.comfont{
  z-index: 12;
    font-family: "myFirstFont";
    font-size: 65px;
    font-weight: 10px;
    margin-top: -450px;
    margin-left: 390px;
}

.institute{
  font-family: "mysecondfont";
    z-index: 14;
    font-size: 45px;
    font-weight: normal;
    margin-left: 76%;
    margin-top : -31px;
}

.addressmy{
  font-family: "mythirdfont";
  position: absolute;
    left: 47%;
    top: -5px;
    z-index: 14;
    font-size:20px;
    width: 250px;
    line-height: 20px;
    word-wrap: 10px;     
    
}
.addressup{
  font-family: "mythirdfont";
  position: absolute;
    left: 47%;
    top: 41px;
    z-index: 14;
    font-size:20px;
    width: 250px;
    line-height: 20px;
    word-wrap: 10px;   
}
.examtxt{
    font-family: "mythirdfont";
    position: absolute;
    left: 38%;
    top: 446px;
    z-index: 18;
    font-size:40px;
    color: white;    
    line-height: 20px;
    word-wrap: 10px;  
}


   
.firstlevel{
  z-index: 10;
}
.firstbackground{
  height:110px;
  background-color: #f4f6f9;
}
.secondbackground{
  height:130px;
  margin-top: 5px;
  background-color:#d7dee8;
}
.secondlevel{
  z-index: 20;
}
.roundedsquare{
    border-radius: 25px;
    border: 1px solid blue;    
    margin-top:40px;
    width: 90%;
    background-color: transparent;
}
.thirdlevel{
  z-index: 30;
}
.roundedsquareblackup{
    border-radius: 25px;
    border: 1px solid blue;
    height: 100px;
    margin-top:-401px;
    width: 90%;
    background-color: #4D4D4D;
}
.fourthlevel{
  z-index: 40;
}
.roundedsquaregreenup{
    border-radius: 25px;
    border: 1px solid transparent;
    height:50px;
    margin-top:-100px;
    width: 90%;
    background-color: #92AE1A;
}
.alignment{position:relative;margin-top:-15px;}
    .leftarrow,.rightarrow{width:50%; position:absolute;}
    .rightarrow{right:-10.7%;}
    .leftarrow{left:-10.7%;}

    .rightarrows{
  width: 37%;
 }
 .leftarrows{
  width: 37%;
 }



/* end of 1200px style */





.alignmentimage{
margin: 0 auto;
max-width:1500px;
}

.alignmentnumber{
margin: 0 auto;
margin-top : 280px;

}

   .alignment{
margin: 0 auto;
margin-top:-335px;
max-width:1500px;
}
img.left{
display:block;
float:left;
}
img.right{
display:block;
float:right;
}

/*
@media (max-width: 570px) {
img.left{
float:none;
margin: 0 auto;
}
img.right{
display:block;
float:none;
margin: 0 auto;
}
*/
/*}*/
 .alignmentnumber{position:relative;}
    .leftnumber,.rightnumber{width:50%; position:absolute;font-size: 25px;}
    .rightnumber{right:0;}
    .leftnumber{left:100px;}  

     .panel-transparent {
        background: none;
    }
     .panel-transparent .panel-body{
        background: rgba(46, 51, 56, 0.2)!important;
    }
  </style>



</head>
<body>
  <div class="container-fluid hidden-xs">

   
    <div class="row" style="padding-top:90px">
      <div class="col-lg-12">
        <div class="col-lg-2">
        </div>
        <div class="col-lg-8">

             <div class="panel panel-default panel-transparent" style="border-style: none; z-index: 0">
              <div class="panel-heading" style="background-color: #4D4D4D; overflow: hidden; height: 80px; border-radius: 20px"></div>
              <div class="panel-body" style="background-color: transparent;overflow: hidden; height: 250px;">
                

            <div class="alignmentimage">
           
              <img src="<?php echo base_url("assets/images/banner2.jpg"); ?>" class="right" width="300" height="200">
              <img src="<?php echo base_url("assets/images/bannersir.jpg"); ?>" class="right" width="300" height="200">
              
            </div>  


              </div>
              <div class="panel-footer" style="background-color:black;overflow: hidden; height: 45px;"></div>
            </div>

            <div class="panel" style="border:2px #92AE1A solid; border-radius: 18px; overflow: hidden; height: 45px;z-index: 2; background-color:#92AE1A; margin-top:-400px"></div>
            <div class="panel" style="border:2px #92AE1A solid; border-radius: 12px; overflow: hidden; height: 45px;z-index: 4; background-color:#92AE1A; margin-top:260px"></div>

            <div class="alignment">
              <img src="<?php echo base_url("assets/images/arrow.png"); ?>" class="right" width="150" height="50">
              <img src="<?php echo base_url("assets/images/arrowright.png"); ?>" class="left" width="150" height="50">
              
            </div>  

             <img src="<?php echo base_url("assets/images/logo.png"); ?>" width="250" height="250" style="z-index: 8; margin-left: -160px; margin-top: 80px;">
            <img src="<?php echo base_url("assets/images/JayaName.png"); ?>" width="270" height="250" style="z-index: 10; margin-left: -120px; margin-top: -300px;">
            <div class="comfont">COMPUTER</div>
            <div class="institute">Institute</div>

        <div class="addressmy">H.No. 69, Habibpur V.I.P. Road, Near Tambershwar Mandir, </div>
        <div class="addressup"><font color="white">Dist-Fatehpur - 212601(UP)</font></div>
            <div class="alignmentnumber" style="margin-top: 271px">
             <div class="leftnumber" style="text-align: right"><img src="<?php echo base_url("assets/images/whatsapplogo.png"); ?>" class="image-responsive" width="5%" /> 9839624498</div><div class="rightnumber" style="text-align: center">7704051508</div>
            </div>  

        </div>
        <div class="col-lg-2">
        </div>
      </div>


      <div class="examtxt"><center>Demo Testing Work In Progress</center></div>

    </div>

    <div class="row" style="padding-top:100px">
      <div class="col-lg-4"></div>
      <div class="col-lg-4"><center>
        <div style="background-color: green;padding:10px; width:50%;">STUDENT</div>
        <div style="padding:10px;"></div>
        <div style="border:1px #4D4D4D solid;color:white;width:80%">
          <div class="font-control" style="height:200px;">
            <label style="font-size: 30px; margin-left: -110px;">Enrolment No</label>
            <input style="background-color: #4D4D4D;border: none; width: 70%; margin-left: -65px;" type="text" class="form-control" value="" id="enrolmentno" name="enrolmentno">
            <label style="font-size: 30px; margin-left: -160px;">Password</label>
            <input style="background-color: #4D4D4D;border: none; width: 70%; margin-left: -65px;" type="text" class="form-control" value="" id="enrolmentno" name="enrolmentno">
          </div>
        </div>
        </center>
      </div>
      <div class="col-lg-4" style="height: 300px;">
        
       
        <center><div style="background-color: green;padding:10px; width:50%;">ADMIN</div></center>
        <div style="padding:10px;"></div>
        <div style="border:1px #4D4D4D solid;color:white;width:80%;">
          <div class="font-control" style="height:200px;">
            <label style="font-size: 30px; margin-left: 10px;">Username</label>
            <input style="background-color: #4D4D4D;border: none; width: 70%; margin-left: 15px;" type="text" class="form-control" value="" id="enrolmentno" name="enrolmentno">
            <label style="font-size: 30px; margin-left: 10px;">Password</label>
            <input style="background-color: #4D4D4D;border: none; width: 70%; margin-left: 15px;" type="text" class="form-control" value="" id="enrolmentno" name="enrolmentno">
          </div>
        </div>
        

      </div>
    </div>
    <div class="row" style="background-image: url(<?php echo base_url('assets/images/background.png'); ?>); background-repeat: no-repeat;background-position: 0 0; padding: 10px;">
      <div class="col-lg-2">
      </div>
      <div class="col-lg-2">
      </div>
      <div class="col-lg-2">
      </div>
      <div class="col-lg-2">
      </div>
      <div class="col-lg-2">
          <center>
       
        <div style="padding:10px;"></div>
        <div style="border:1px #4D4D4D solid;color:white;width:80%">
          <img src="" width="150" height="150" class="image-responsive">
        </div>
        </center>
      </div>
      <div class="col-lg-2">

       <center>
       
        <div style="padding:10px;"></div>
        <div style="border:1px #4D4D4D solid;color:white;width:80%">
          <img src="" width="150" height="150" class="image-responsive">
        </div>
        </center>

      </div>

    </div>

  </div>
</body>
</html>