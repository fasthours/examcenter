<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->load->helper('url');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url('assets/css/mycss.css');?>">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script type="text/javascript">
    $(window).scroll(function () {
        var $this = $(this);
        var $nav = $('.navbar-brand');
        
        if ($this.scrollTop() > 100) {
           $nav.addClass('small');
        } else {
           $nav.removeClass('small');
        }

        
         /* Check the location of each desired element */
        $('.hideme').each( function(i){
            
            var bottom_of_object = $(this).offset().top + $(this).outerHeight();
            var bottom_of_window = $(window).scrollTop() + $(window).height();
            
            /* If the object is completely visible in the window, fade it it */
            if( bottom_of_window > bottom_of_object ){
                
                $(this).animate({'opacity':'1'},500);
                    
            }
            
        }); 
    
   


    });







  </script>

  <style type="text/css">
  @font-face {
    font-family: "myFirstFont";
    /*src: url('sansation_light.woff');*/
    src:url('<?php echo base_url('assets/fonts/COOPBL.ttf') ?>');
}
@font-face{
  font-family: "mysecondfont";
  src:url('<?php echo base_url('assets/fonts/ufonts.com_arial-narrow.ttf') ?>');
}
@font-face{
  font-family: "mythirdfont";
  src:url('<?php echo base_url('assets/fonts/calibril.ttf') ?>');
}
    body {
   background-color: #ffffff;   
   background-image: url('<?php echo base_url('assets/images/back1.jpg'); ?>'); background-repeat: no-repeat;

}
.ddback{
  background-image: url('<?php echo base_url('assets/images/background.png'); ?>'); background-repeat: no-repeat;
  background-size: 100% 100%;
}
  </style>
</head>
<body>
<a class="navbar-brand" href="#">Demo Site Created By F.H.Services</a>
	<div class="container first">
		<div class="col-lg-12 headerpart1" >
			<div class="logo"><img src="<?php echo base_url('assets/images/JayaName.png'); ?>" class="image-responsive" width="50%"></div>
      <div class="logo1"><img src="<?php echo base_url('assets/images/logo.png'); ?>" class="image-responsive" width="44%"></div>
			<div class="logopartcom swing">
				COMPUTER
			</div>
		</div>
        <div class="secondbackground">
         
      </div>
		<div class="col-lg-12 headerpart2">
			<div class="roundedsquare">
				<div class="institute">Institute</div>
        <div class="addressmy">H.No. 69, Habibpur V.I.P. Road, Near Tambershwar Mandir, </div>
        <div class="addressup"><font color="white">Dist-Fatehpur - 212601(UP)</font></div>
				<div class="roundedround"></div>
        <div class="backroundedcolor"></div>
				<div class="leftarrow"><img src="<?php echo base_url('assets/images/arrowright.png'); ?>" width="42%"></div>
				<div class="rightarrow"><img src="<?php echo base_url('assets/images/arrow.png'); ?>" width="60%"></div>
        <div class="banner">
          <div class="banner1"><img src="<?php echo base_url('assets/images/banner2.jpg'); ?>" width="340" height="150"></div>
          <div class="banner2"><img src="<?php echo base_url('assets/images/bannersir.jpg'); ?>" width="300" height="150"></div>
        </div>
          <div class="headerfooter alignments"><div class="leftnumber" style="text-align: right"><img src="<?php echo base_url("assets/images/whatsapplogo.png"); ?>" class="image-responsive" width="5%" /> 9839624498</div><div class="rightnumber" style="text-align: center">7704051508</div></div>
            <div class="blackpatch"></div>

			</div>
		</div>
	</div>
  <div class="container">
    <div class="textonlineexam">Online Exam Center</div>
     <div class="studentimg"><img src="<?php echo base_url('assets/images/student.png'); ?>" class="image-responsive" width="150"></div>
    <div class="adminimg"><img src="<?php echo base_url('assets/images/admin.png'); ?>" class="image-responsive" width="150"></div>
    <div class="rectangleadmin">
      <form style="padding: 10px">
        <label style="font-size: 25px; margin-left: 10px; color:white">Enrollment No</label>
        <input style="background-color: #4D4D4D;border: none; width: 80%; margin-left: 20px;" type="text" class="form-control" name="enrollmentno" id="enrollmentno">
         <lable style="font-size: 25px; margin-left: 10px;color:white">Password</lable>
        <input style="background-color: #4D4D4D;border: none; width: 80%; margin-left: 20px;"type="text" class="form-control" name="enrollmentno" id="enrollmentno">
      </form>
    </div>
    <div class="rectanglestudent">
      <form style="padding: 10px">
        <label style="font-size: 25px; margin-left: 10px; color:white">Username</label>
        <input style="background-color: #4D4D4D;border: none; width: 80%; margin-left: 20px;" type="text" class="form-control" name="enrollmentno" id="enrollmentno">
         <lable style="font-size: 25px; margin-left: 10px;color:white">Password</lable>
        <input style="background-color: #4D4D4D;border: none; width: 80%; margin-left: 20px;"type="text" class="form-control" name="enrollmentno" id="enrollmentno">
      </form>
    </div>   
  </div>
  <div class="container-fluid ddback hideme" style="margin-top:85px; height: 400px">
    <div class="col-lg-3"></div>
    <center><div class="col-lg-3 rectangleboss"></div></center>
    <center><div class="col-lg-3 rectangledesign"></div> </center>
    <center><div class="col-lg-3 rectangledevlop"></div> </center>
  </div>
  <div class="container-fluid hideme" style="background-color: #4D4D4D;height: 150px">
  <div class="rectangleccc"></div>
    <div class="rectanglecourse"></div>
    
  </div>
  <div class="container-fluid hideme" style="background-color: #92AE1A;height: 50px">
  
  </div>
</body>
</html>